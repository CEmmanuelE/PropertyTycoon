
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class MenuFrame extends javax.swing.JFrame {

    //Create And Instantialize ButtonGroups
    ButtonGroup boardButtonGroup = new ButtonGroup();
    ButtonGroup GameModeButtonGroup = new ButtonGroup();
    ButtonGroup NumberOfPlayersButtonGroup = new ButtonGroup();
    ButtonGroup NumberOfHumanPlayersButtonGroup = new ButtonGroup();

    //Constractor For Menu Frame -- do Settings For Start Status for Frame
    public MenuFrame() {
        initComponents();
        logo.setBorderPainted(false);
        logo.setContentAreaFilled(false);
        GameModeButtonGroup.add(FullGameRadioButtom);
        GameModeButtonGroup.add(LimitedGameRadioButtom);
        NumberOfPlayersButtonGroup.add(NumberOfPlayersRadioButton2);
        NumberOfPlayersButtonGroup.add(NumberOfPlayersRadioButton3);
        NumberOfPlayersButtonGroup.add(NumberOfPlayersRadioButton4);
        NumberOfPlayersButtonGroup.add(NumberOfPlayersRadioButton5);
        NumberOfPlayersButtonGroup.add(NumberOfPlayersRadioButton6);

        Player6Text.setEnabled(false);
        Player5Text.setEnabled(false);
        Player4Text.setEnabled(false);
        Player3Text.setEnabled(false);

        p6Cat.setEnabled(false);
        p6Goblet.setEnabled(false);
        p6HatStand.setEnabled(false);
        p6SmartPhone.setEnabled(false);
        p6Spoon.setEnabled(false);
        p6boot.setEnabled(false);

        p5Cat.setEnabled(false);
        p5Goblet.setEnabled(false);
        p5HatStand.setEnabled(false);
        p5SmartPhone.setEnabled(false);
        p5Spoon.setEnabled(false);
        p5boot.setEnabled(false);

        p4Cat.setEnabled(false);
        p4Goblet.setEnabled(false);
        p4HatStand.setEnabled(false);
        p4SmartPhone.setEnabled(false);
        p4Spoon.setEnabled(false);
        p4boot.setEnabled(false);

        p3Cat.setEnabled(false);
        p3Goblet.setEnabled(false);
        p3HatStand.setEnabled(false);
        p3SmartPhone.setEnabled(false);
        p3Spoon.setEnabled(false);
        p3boot.setEnabled(false);

        P3IsHumanCheckBox.setEnabled(false);
        P4IsHumanCheckBox.setEnabled(false);
        P5IsHumanCheckBox.setEnabled(false);
        P6IsHumanCheckBox.setEnabled(false);
    }

    //Main Menu
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MenuFrame Menu = new MenuFrame();
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel9 = new javax.swing.JPanel();
        SelectGameModePanel = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        FullGameRadioButtom = new javax.swing.JRadioButton();
        jLabel21 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        LimitedGameRadioButtom = new javax.swing.JRadioButton();
        jLabel24 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        AbrigedModeTime = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        StartButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        NumberOfPlayersRadioButton2 = new javax.swing.JRadioButton();
        NumberOfPlayersRadioButton3 = new javax.swing.JRadioButton();
        NumberOfPlayersRadioButton4 = new javax.swing.JRadioButton();
        NumberOfPlayersRadioButton5 = new javax.swing.JRadioButton();
        NumberOfPlayersRadioButton6 = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        Player1Text = new javax.swing.JTextField();
        p1boot = new javax.swing.JRadioButton();
        jLabel28 = new javax.swing.JLabel();
        p1Cat = new javax.swing.JRadioButton();
        p1SmartPhone = new javax.swing.JRadioButton();
        p1Goblet = new javax.swing.JRadioButton();
        p1Spoon = new javax.swing.JRadioButton();
        p1HatStand = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        Player3Text = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        P3IsHumanCheckBox = new javax.swing.JCheckBox();
        jLabel19 = new javax.swing.JLabel();
        p3boot = new javax.swing.JRadioButton();
        p3Cat = new javax.swing.JRadioButton();
        p3SmartPhone = new javax.swing.JRadioButton();
        p3Goblet = new javax.swing.JRadioButton();
        p3Spoon = new javax.swing.JRadioButton();
        p3HatStand = new javax.swing.JRadioButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        Player5Text = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        P5IsHumanCheckBox = new javax.swing.JCheckBox();
        jLabel27 = new javax.swing.JLabel();
        p5boot = new javax.swing.JRadioButton();
        p5Cat = new javax.swing.JRadioButton();
        p5SmartPhone = new javax.swing.JRadioButton();
        p5Goblet = new javax.swing.JRadioButton();
        p5Spoon = new javax.swing.JRadioButton();
        p5HatStand = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        Player2Text = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        P2IsHumanCheckBox = new javax.swing.JCheckBox();
        jLabel17 = new javax.swing.JLabel();
        p2boot = new javax.swing.JRadioButton();
        p2Cat = new javax.swing.JRadioButton();
        p2SmartPhone = new javax.swing.JRadioButton();
        p2Goblet = new javax.swing.JRadioButton();
        p2Spoon = new javax.swing.JRadioButton();
        p2HatStand = new javax.swing.JRadioButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        Player6Text = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        P6IsHumanCheckBox = new javax.swing.JCheckBox();
        jLabel26 = new javax.swing.JLabel();
        p6boot = new javax.swing.JRadioButton();
        p6Cat = new javax.swing.JRadioButton();
        p6SmartPhone = new javax.swing.JRadioButton();
        p6Goblet = new javax.swing.JRadioButton();
        p6Spoon = new javax.swing.JRadioButton();
        p6HatStand = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        Player4Text = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        P4IsHumanCheckBox = new javax.swing.JCheckBox();
        jLabel18 = new javax.swing.JLabel();
        p4boot = new javax.swing.JRadioButton();
        p4Cat = new javax.swing.JRadioButton();
        p4SmartPhone = new javax.swing.JRadioButton();
        p4Goblet = new javax.swing.JRadioButton();
        p4Spoon = new javax.swing.JRadioButton();
        p4HatStand = new javax.swing.JRadioButton();
        jPanel13 = new javax.swing.JPanel();
        logo = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Property Tycoon");
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(29, 16, 44));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setFocusCycleRoot(false);
        setMinimumSize(new java.awt.Dimension(1158, 464));
        setResizable(false);
        getContentPane().setLayout(new java.awt.CardLayout());

        SelectGameModePanel.setBackground(new java.awt.Color(22, 36, 71));
        SelectGameModePanel.setMaximumSize(new java.awt.Dimension(1158, 464));
        SelectGameModePanel.setMinimumSize(new java.awt.Dimension(1158, 464));
        SelectGameModePanel.setPreferredSize(new java.awt.Dimension(1158, 464));

        jPanel8.setBackground(new java.awt.Color(31, 64, 104));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 255, 255));
        jLabel2.setText("Game Type");

        jPanel10.setBackground(new java.awt.Color(255, 211, 29));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel20.setText("Full Game");

        FullGameRadioButtom.setBackground(new java.awt.Color(255, 211, 29));
        FullGameRadioButtom.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        FullGameRadioButtom.setSelected(true);
        FullGameRadioButtom.setText("Full Game");
        FullGameRadioButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FullGameRadioButtomActionPerformed(evt);
            }
        });

        jLabel21.setText("Standard Property Tycoon ! Play Until one Player emerges victorious.");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(FullGameRadioButtom)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FullGameRadioButtom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(255, 211, 29));

        LimitedGameRadioButtom.setBackground(new java.awt.Color(255, 211, 29));
        LimitedGameRadioButtom.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        LimitedGameRadioButtom.setText("Abriged Mode");
        LimitedGameRadioButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimitedGameRadioButtomActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel24.setText("Abridged Game");

        jLabel22.setText("Same as the full Game. except there's a time limit.");

        jLabel23.setText("Play until times up . the player with most assests wins !");

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel1.setText("Time Limit :");

        AbrigedModeTime.setText("30");
        AbrigedModeTime.setEnabled(false);

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel5.setText("mins");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24)
                    .addComponent(LimitedGameRadioButtom)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AbrigedModeTime, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)))
                .addGap(147, 147, 147))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LimitedGameRadioButtom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(AbrigedModeTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(55, 55, 55))
        );

        StartButton.setFont(new java.awt.Font("Lucida Grande", 0, 36)); // NOI18N
        StartButton.setForeground(new java.awt.Color(204, 0, 51));
        StartButton.setText("Start Game");
        StartButton.setSelected(true);
        StartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StartButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(StartButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(184, 184, 184))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, 178, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        jPanel1.setBackground(new java.awt.Color(228, 63, 90));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Setup Game");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Choose Number Of Players :");

        NumberOfPlayersRadioButton2.setBackground(new java.awt.Color(228, 63, 90));
        NumberOfPlayersRadioButton2.setSelected(true);
        NumberOfPlayersRadioButton2.setText("2");
        NumberOfPlayersRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPlayersRadioButton2ActionPerformed(evt);
            }
        });

        NumberOfPlayersRadioButton3.setBackground(new java.awt.Color(228, 63, 90));
        NumberOfPlayersRadioButton3.setText("3");
        NumberOfPlayersRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPlayersRadioButton3ActionPerformed(evt);
            }
        });

        NumberOfPlayersRadioButton4.setBackground(new java.awt.Color(228, 63, 90));
        NumberOfPlayersRadioButton4.setText("4");
        NumberOfPlayersRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPlayersRadioButton4ActionPerformed(evt);
            }
        });

        NumberOfPlayersRadioButton5.setBackground(new java.awt.Color(228, 63, 90));
        NumberOfPlayersRadioButton5.setText("5");
        NumberOfPlayersRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPlayersRadioButton5ActionPerformed(evt);
            }
        });

        NumberOfPlayersRadioButton6.setBackground(new java.awt.Color(228, 63, 90));
        NumberOfPlayersRadioButton6.setText("6");
        NumberOfPlayersRadioButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPlayersRadioButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(NumberOfPlayersRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(NumberOfPlayersRadioButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(NumberOfPlayersRadioButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(NumberOfPlayersRadioButton5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(NumberOfPlayersRadioButton6)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(NumberOfPlayersRadioButton2)
                    .addComponent(NumberOfPlayersRadioButton3)
                    .addComponent(NumberOfPlayersRadioButton4)
                    .addComponent(NumberOfPlayersRadioButton5)
                    .addComponent(NumberOfPlayersRadioButton6))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 82, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(250, 97));
        jPanel2.setVerifyInputWhenFocusTarget(false);

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel6.setText("Player1 Name :");

        Player1Text.setText("You");

        p1boot.setBackground(new java.awt.Color(255, 82, 0));
        p1boot.setSelected(true);
        p1boot.setText("boot");
        p1boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1bootActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel28.setText("Pieces :");

        p1Cat.setBackground(new java.awt.Color(255, 82, 0));
        p1Cat.setText("Cat");
        p1Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1CatActionPerformed(evt);
            }
        });

        p1SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p1SmartPhone.setText("Phone");
        p1SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1SmartPhoneActionPerformed(evt);
            }
        });

        p1Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p1Goblet.setText("Goblet");
        p1Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1GobletActionPerformed(evt);
            }
        });

        p1Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p1Spoon.setText("Spoon");
        p1Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1SpoonActionPerformed(evt);
            }
        });

        p1HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p1HatStand.setText("Hat Stand");
        p1HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Player1Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addGap(14, 14, 14)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p1Goblet)
                                    .addComponent(p1boot))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p1Cat)
                            .addComponent(p1Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p1HatStand)
                            .addComponent(p1SmartPhone))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(Player1Text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(p1boot)
                            .addComponent(p1Cat)
                            .addComponent(p1SmartPhone))
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(p1HatStand)
                            .addComponent(p1Goblet)
                            .addComponent(p1Spoon))
                        .addContainerGap())))
        );

        jPanel4.setBackground(new java.awt.Color(255, 82, 0));
        jPanel4.setPreferredSize(new java.awt.Dimension(250, 97));
        jPanel4.setVerifyInputWhenFocusTarget(false);

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel8.setText("Player 3 Name :");

        Player3Text.setText("Player 3");

        jLabel14.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel14.setText("Types :");

        P3IsHumanCheckBox.setBackground(new java.awt.Color(255, 82, 0));
        P3IsHumanCheckBox.setText("Is Human");
        P3IsHumanCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                P3IsHumanCheckBoxActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel19.setText("Pieces :");

        p3boot.setBackground(new java.awt.Color(255, 82, 0));
        p3boot.setText("boot");
        p3boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3bootActionPerformed(evt);
            }
        });

        p3Cat.setBackground(new java.awt.Color(255, 82, 0));
        p3Cat.setText("Cat");
        p3Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3CatActionPerformed(evt);
            }
        });

        p3SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p3SmartPhone.setSelected(true);
        p3SmartPhone.setText("Phone");
        p3SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3SmartPhoneActionPerformed(evt);
            }
        });

        p3Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p3Goblet.setText("Goblet");
        p3Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3GobletActionPerformed(evt);
            }
        });

        p3Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p3Spoon.setText("Spoon");
        p3Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3SpoonActionPerformed(evt);
            }
        });

        p3HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p3HatStand.setText("Hat Stand");
        p3HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Player3Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(P3IsHumanCheckBox))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p3boot)
                            .addComponent(p3Goblet))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p3Cat)
                            .addComponent(p3Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p3HatStand)
                            .addComponent(p3SmartPhone))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(Player3Text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(P3IsHumanCheckBox))
                .addGap(1, 1, 1)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(p3boot)
                    .addComponent(p3Cat)
                    .addComponent(p3SmartPhone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p3Goblet)
                    .addComponent(p3Spoon)
                    .addComponent(p3HatStand))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 82, 0));
        jPanel6.setPreferredSize(new java.awt.Dimension(250, 97));
        jPanel6.setVerifyInputWhenFocusTarget(false);

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel10.setText("Player 5 Name :");

        Player5Text.setText("Player 5");

        jLabel15.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel15.setText("Types :");

        P5IsHumanCheckBox.setBackground(new java.awt.Color(255, 82, 0));
        P5IsHumanCheckBox.setText("Is Human");
        P5IsHumanCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                P5IsHumanCheckBoxActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel27.setText("Pieces :");

        p5boot.setBackground(new java.awt.Color(255, 82, 0));
        p5boot.setText("boot");
        p5boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5bootActionPerformed(evt);
            }
        });

        p5Cat.setBackground(new java.awt.Color(255, 82, 0));
        p5Cat.setText("Cat");
        p5Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5CatActionPerformed(evt);
            }
        });

        p5SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p5SmartPhone.setText("Phone");
        p5SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5SmartPhoneActionPerformed(evt);
            }
        });

        p5Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p5Goblet.setText("Goblet");
        p5Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5GobletActionPerformed(evt);
            }
        });

        p5Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p5Spoon.setSelected(true);
        p5Spoon.setText("Spoon");
        p5Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5SpoonActionPerformed(evt);
            }
        });

        p5HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p5HatStand.setText("Hat Stand");
        p5HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Player5Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(P5IsHumanCheckBox))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p5boot)
                            .addComponent(p5Goblet))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p5Cat)
                            .addComponent(p5Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p5HatStand)
                            .addComponent(p5SmartPhone))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(Player5Text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(P5IsHumanCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(p5boot)
                    .addComponent(p5Cat)
                    .addComponent(p5SmartPhone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p5Goblet)
                    .addComponent(p5Spoon)
                    .addComponent(p5HatStand))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 82, 0));
        jPanel3.setPreferredSize(new java.awt.Dimension(250, 97));

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel7.setText("Player 2 Name :");

        Player2Text.setText("Player 2");

        jLabel13.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel13.setText("Types :");

        P2IsHumanCheckBox.setBackground(new java.awt.Color(255, 82, 0));
        P2IsHumanCheckBox.setText("Is Human");
        P2IsHumanCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                P2IsHumanCheckBoxActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel17.setText("Pieces :");

        p2boot.setBackground(new java.awt.Color(255, 82, 0));
        p2boot.setText("boot");
        p2boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2bootActionPerformed(evt);
            }
        });

        p2Cat.setBackground(new java.awt.Color(255, 82, 0));
        p2Cat.setSelected(true);
        p2Cat.setText("Cat");
        p2Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2CatActionPerformed(evt);
            }
        });

        p2SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p2SmartPhone.setText("Phone");
        p2SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2SmartPhoneActionPerformed(evt);
            }
        });

        p2Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p2Goblet.setText("Goblet");
        p2Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2GobletActionPerformed(evt);
            }
        });

        p2Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p2Spoon.setText("Spoon");
        p2Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2SpoonActionPerformed(evt);
            }
        });

        p2HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p2HatStand.setText("Hat Stand");
        p2HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Player2Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(P2IsHumanCheckBox))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p2boot)
                            .addComponent(p2Goblet))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p2Cat)
                            .addComponent(p2Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p2HatStand)
                            .addComponent(p2SmartPhone))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(Player2Text, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(P2IsHumanCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(p2boot)
                    .addComponent(p2Cat)
                    .addComponent(p2SmartPhone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p2Goblet)
                    .addComponent(p2Spoon)
                    .addComponent(p2HatStand))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(255, 82, 0));
        jPanel7.setPreferredSize(new java.awt.Dimension(250, 97));

        jLabel11.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel11.setText("Player 6 Name :");

        Player6Text.setText("Player 6");

        jLabel25.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel25.setText("Types :");

        P6IsHumanCheckBox.setBackground(new java.awt.Color(255, 82, 0));
        P6IsHumanCheckBox.setText("Is Human");
        P6IsHumanCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                P6IsHumanCheckBoxActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel26.setText("Pieces :");

        p6boot.setBackground(new java.awt.Color(255, 82, 0));
        p6boot.setText("boot");
        p6boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6bootActionPerformed(evt);
            }
        });

        p6Cat.setBackground(new java.awt.Color(255, 82, 0));
        p6Cat.setText("Cat");
        p6Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6CatActionPerformed(evt);
            }
        });

        p6SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p6SmartPhone.setText("Phone");
        p6SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6SmartPhoneActionPerformed(evt);
            }
        });

        p6Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p6Goblet.setText("Goblet");
        p6Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6GobletActionPerformed(evt);
            }
        });

        p6Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p6Spoon.setText("Spoon");
        p6Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6SpoonActionPerformed(evt);
            }
        });

        p6HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p6HatStand.setSelected(true);
        p6HatStand.setText("Hat Stand");
        p6HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Player6Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(P6IsHumanCheckBox))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p6boot)
                            .addComponent(p6Goblet))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p6Cat)
                            .addComponent(p6Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p6HatStand)
                            .addComponent(p6SmartPhone))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(Player6Text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(P6IsHumanCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(p6boot)
                    .addComponent(p6Cat)
                    .addComponent(p6SmartPhone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p6Goblet)
                    .addComponent(p6Spoon)
                    .addComponent(p6HatStand))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 82, 0));
        jPanel5.setPreferredSize(new java.awt.Dimension(250, 97));

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel9.setText("Player 4 Name :");

        Player4Text.setText("Player 4");

        jLabel16.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel16.setText("Types :");

        P4IsHumanCheckBox.setBackground(new java.awt.Color(255, 82, 0));
        P4IsHumanCheckBox.setText("Is Human");
        P4IsHumanCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                P4IsHumanCheckBoxActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel18.setText("Pieces :");

        p4boot.setBackground(new java.awt.Color(255, 82, 0));
        p4boot.setText("boot");
        p4boot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4bootActionPerformed(evt);
            }
        });

        p4Cat.setBackground(new java.awt.Color(255, 82, 0));
        p4Cat.setText("Cat");
        p4Cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4CatActionPerformed(evt);
            }
        });

        p4SmartPhone.setBackground(new java.awt.Color(255, 82, 0));
        p4SmartPhone.setText("Phone");
        p4SmartPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4SmartPhoneActionPerformed(evt);
            }
        });

        p4Goblet.setBackground(new java.awt.Color(255, 82, 0));
        p4Goblet.setSelected(true);
        p4Goblet.setText("Goblet");
        p4Goblet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4GobletActionPerformed(evt);
            }
        });

        p4Spoon.setBackground(new java.awt.Color(255, 82, 0));
        p4Spoon.setText("Spoon");
        p4Spoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4SpoonActionPerformed(evt);
            }
        });

        p4HatStand.setBackground(new java.awt.Color(255, 82, 0));
        p4HatStand.setText("Hat Stand");
        p4HatStand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4HatStandActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Player4Text, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(P4IsHumanCheckBox))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p4boot)
                            .addComponent(p4Goblet))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p4Cat)
                            .addComponent(p4Spoon))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p4HatStand)
                            .addComponent(p4SmartPhone))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(Player4Text, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(P4IsHumanCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(p4boot)
                    .addComponent(p4Cat)
                    .addComponent(p4SmartPhone))
                .addGap(3, 3, 3)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p4Goblet)
                    .addComponent(p4Spoon)
                    .addComponent(p4HatStand))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(29, 16, 44));

        logo.setBackground(new java.awt.Color(29, 16, 44));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/header.JPG"))); // NOI18N
        logo.setBorder(null);
        logo.setBorderPainted(false);
        logo.setDefaultCapable(false);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(76, Short.MAX_VALUE)
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 1059, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout SelectGameModePanelLayout = new javax.swing.GroupLayout(SelectGameModePanel);
        SelectGameModePanel.setLayout(SelectGameModePanelLayout);
        SelectGameModePanelLayout.setHorizontalGroup(
            SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SelectGameModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(SelectGameModePanelLayout.createSequentialGroup()
                        .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(SelectGameModePanelLayout.createSequentialGroup()
                                .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 307, Short.MAX_VALUE)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 307, Short.MAX_VALUE)
                                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 307, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)))
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        SelectGameModePanelLayout.setVerticalGroup(
            SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SelectGameModePanelLayout.createSequentialGroup()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(SelectGameModePanelLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 115, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SelectGameModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        getContentPane().add(SelectGameModePanel, "card2");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void FullGameRadioButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FullGameRadioButtomActionPerformed
        AbrigedModeTime.setEnabled(false);
    }//GEN-LAST:event_FullGameRadioButtomActionPerformed

    private void LimitedGameRadioButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimitedGameRadioButtomActionPerformed
        AbrigedModeTime.setEnabled(true);
    }//GEN-LAST:event_LimitedGameRadioButtomActionPerformed

    //Start Button Run Initializer Methood
    private void StartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StartButtonActionPerformed
        Initializer();
    }//GEN-LAST:event_StartButtonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6HatStandActionPerformed
        try {
            CheckTokenPlayer(6, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p6HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5HatStandActionPerformed
        try {
            CheckTokenPlayer(5, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4HatStandActionPerformed
        try {
            CheckTokenPlayer(4, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3HatStandActionPerformed
        try {
            CheckTokenPlayer(3, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2HatStandActionPerformed
        try {
            CheckTokenPlayer(2, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1HatStandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1HatStandActionPerformed
        try {
            CheckTokenPlayer(1, "HatStand");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1HatStandActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6SpoonActionPerformed
        try {
            CheckTokenPlayer(6, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p6SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5SpoonActionPerformed
        try {
            CheckTokenPlayer(5, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4SpoonActionPerformed
        try {
            CheckTokenPlayer(4, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3SpoonActionPerformed
        try {
            CheckTokenPlayer(3, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2SpoonActionPerformed
        try {
            CheckTokenPlayer(2, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1SpoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1SpoonActionPerformed
        try {
            CheckTokenPlayer(1, "Spoon");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1SpoonActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6GobletActionPerformed
        try {
            CheckTokenPlayer(6, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p6GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5GobletActionPerformed
        try {
            CheckTokenPlayer(5, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4GobletActionPerformed
        try {
            CheckTokenPlayer(4, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3GobletActionPerformed
        try {
            CheckTokenPlayer(3, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2GobletActionPerformed
        try {
            CheckTokenPlayer(2, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1GobletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1GobletActionPerformed
        try {
            CheckTokenPlayer(1, "Goblet");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1GobletActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(6, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p6SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(5, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(4, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(3, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(2, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1SmartPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1SmartPhoneActionPerformed
        try {
            CheckTokenPlayer(1, "SmartPhone");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1SmartPhoneActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6bootActionPerformed
        try {
            CheckTokenPlayer(6, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p6bootActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5bootActionPerformed
        try {
            CheckTokenPlayer(5, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5bootActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4bootActionPerformed
        try {
            CheckTokenPlayer(4, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4bootActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3bootActionPerformed
        try {
            CheckTokenPlayer(3, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3bootActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2bootActionPerformed
        try {
            CheckTokenPlayer(2, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2bootActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1bootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1bootActionPerformed
        try {
            CheckTokenPlayer(1, "boot");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1bootActionPerformed

    private void P6IsHumanCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_P6IsHumanCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_P6IsHumanCheckBoxActionPerformed

    private void P5IsHumanCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_P5IsHumanCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_P5IsHumanCheckBoxActionPerformed

    private void P4IsHumanCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_P4IsHumanCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_P4IsHumanCheckBoxActionPerformed

    private void P3IsHumanCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_P3IsHumanCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_P3IsHumanCheckBoxActionPerformed

    private void P2IsHumanCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_P2IsHumanCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_P2IsHumanCheckBoxActionPerformed

    // Enable And Disable element Relate To Selected Player
    private void NumberOfPlayersRadioButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPlayersRadioButton6ActionPerformed

        Player1Text.setEnabled(true);
        Player2Text.setEnabled(true);
        Player3Text.setEnabled(true);
        Player4Text.setEnabled(true);
        Player5Text.setEnabled(true);
        Player6Text.setEnabled(true);

        P3IsHumanCheckBox.setEnabled(true);
        P4IsHumanCheckBox.setEnabled(true);
        P5IsHumanCheckBox.setEnabled(true);
        P6IsHumanCheckBox.setEnabled(true);

        p6Cat.setEnabled(true);
        p6Goblet.setEnabled(true);
        p6HatStand.setEnabled(true);
        p6SmartPhone.setEnabled(true);
        p6Spoon.setEnabled(true);
        p6boot.setEnabled(true);

        p5Cat.setEnabled(true);
        p5Goblet.setEnabled(true);
        p5HatStand.setEnabled(true);
        p5SmartPhone.setEnabled(true);
        p5Spoon.setEnabled(true);
        p5boot.setEnabled(true);

        p4Cat.setEnabled(true);
        p4Goblet.setEnabled(true);
        p4HatStand.setEnabled(true);
        p4SmartPhone.setEnabled(true);
        p4Spoon.setEnabled(true);
        p4boot.setEnabled(true);

        p3Cat.setEnabled(true);
        p3Goblet.setEnabled(true);
        p3HatStand.setEnabled(true);
        p3SmartPhone.setEnabled(true);
        p3Spoon.setEnabled(true);
        p3boot.setEnabled(true);
    }//GEN-LAST:event_NumberOfPlayersRadioButton6ActionPerformed

    // Enable And Disable element Relate To Selected Player
    private void NumberOfPlayersRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPlayersRadioButton5ActionPerformed

        Player1Text.setEnabled(true);
        Player2Text.setEnabled(true);
        Player3Text.setEnabled(true);
        Player4Text.setEnabled(true);
        Player5Text.setEnabled(true);
        Player6Text.setEnabled(false);

        P3IsHumanCheckBox.setEnabled(true);
        P4IsHumanCheckBox.setEnabled(true);
        P5IsHumanCheckBox.setEnabled(true);
        P6IsHumanCheckBox.setEnabled(false);

        p6Cat.setEnabled(false);
        p6Goblet.setEnabled(false);
        p6HatStand.setEnabled(false);
        p6SmartPhone.setEnabled(false);
        p6Spoon.setEnabled(false);
        p6boot.setEnabled(false);

        p5Cat.setEnabled(true);
        p5Goblet.setEnabled(true);
        p5HatStand.setEnabled(true);
        p5SmartPhone.setEnabled(true);
        p5Spoon.setEnabled(true);
        p5boot.setEnabled(true);

        p4Cat.setEnabled(true);
        p4Goblet.setEnabled(true);
        p4HatStand.setEnabled(true);
        p4SmartPhone.setEnabled(true);
        p4Spoon.setEnabled(true);
        p4boot.setEnabled(true);

        p3Cat.setEnabled(true);
        p3Goblet.setEnabled(true);
        p3HatStand.setEnabled(true);
        p3SmartPhone.setEnabled(true);
        p3Spoon.setEnabled(true);
        p3boot.setEnabled(true);
    }//GEN-LAST:event_NumberOfPlayersRadioButton5ActionPerformed

    // Enable And Disable element Relate To Selected Player
    private void NumberOfPlayersRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPlayersRadioButton4ActionPerformed

        Player1Text.setEnabled(true);
        Player2Text.setEnabled(true);
        Player3Text.setEnabled(true);
        Player4Text.setEnabled(true);
        Player5Text.setEnabled(false);
        Player6Text.setEnabled(false);

        P3IsHumanCheckBox.setEnabled(true);
        P4IsHumanCheckBox.setEnabled(true);
        P5IsHumanCheckBox.setEnabled(false);
        P6IsHumanCheckBox.setEnabled(false);

        p6Cat.setEnabled(false);
        p6Goblet.setEnabled(false);
        p6HatStand.setEnabled(false);
        p6SmartPhone.setEnabled(false);
        p6Spoon.setEnabled(false);
        p6boot.setEnabled(false);

        p5Cat.setEnabled(false);
        p5Goblet.setEnabled(false);
        p5HatStand.setEnabled(false);
        p5SmartPhone.setEnabled(false);
        p5Spoon.setEnabled(false);
        p5boot.setEnabled(false);

        p4Cat.setEnabled(true);
        p4Goblet.setEnabled(true);
        p4HatStand.setEnabled(true);
        p4SmartPhone.setEnabled(true);
        p4Spoon.setEnabled(true);
        p4boot.setEnabled(true);

        p3Cat.setEnabled(true);
        p3Goblet.setEnabled(true);
        p3HatStand.setEnabled(true);
        p3SmartPhone.setEnabled(true);
        p3Spoon.setEnabled(true);
        p3boot.setEnabled(true);
    }//GEN-LAST:event_NumberOfPlayersRadioButton4ActionPerformed

    // Enable And Disable element Relate To Selected Player
    private void NumberOfPlayersRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPlayersRadioButton3ActionPerformed

        Player1Text.setEnabled(true);
        Player2Text.setEnabled(true);
        Player3Text.setEnabled(true);
        Player4Text.setEnabled(false);
        Player5Text.setEnabled(false);
        Player6Text.setEnabled(false);

        P3IsHumanCheckBox.setEnabled(true);
        P4IsHumanCheckBox.setEnabled(false);
        P5IsHumanCheckBox.setEnabled(false);
        P6IsHumanCheckBox.setEnabled(false);
        p6Cat.setEnabled(false);
        p6Goblet.setEnabled(false);
        p6HatStand.setEnabled(false);
        p6SmartPhone.setEnabled(false);
        p6Spoon.setEnabled(false);
        p6boot.setEnabled(false);

        p5Cat.setEnabled(false);
        p5Goblet.setEnabled(false);
        p5HatStand.setEnabled(false);
        p5SmartPhone.setEnabled(false);
        p5Spoon.setEnabled(false);
        p5boot.setEnabled(false);

        p4Cat.setEnabled(false);
        p4Goblet.setEnabled(false);
        p4HatStand.setEnabled(false);
        p4SmartPhone.setEnabled(false);
        p4Spoon.setEnabled(false);
        p4boot.setEnabled(false);

        p3Cat.setEnabled(true);
        p3Goblet.setEnabled(true);
        p3HatStand.setEnabled(true);
        p3SmartPhone.setEnabled(true);
        p3Spoon.setEnabled(true);
        p3boot.setEnabled(true);
    }//GEN-LAST:event_NumberOfPlayersRadioButton3ActionPerformed

    // Enable And Disable element Relate To Selected Player
    private void NumberOfPlayersRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPlayersRadioButton2ActionPerformed

        Player1Text.setEnabled(true);
        Player2Text.setEnabled(true);
        Player3Text.setEnabled(false);
        Player4Text.setEnabled(false);
        Player5Text.setEnabled(false);
        Player6Text.setEnabled(false);

        P3IsHumanCheckBox.setEnabled(false);
        P4IsHumanCheckBox.setEnabled(false);
        P5IsHumanCheckBox.setEnabled(false);
        P6IsHumanCheckBox.setEnabled(false);
        p6Cat.setEnabled(false);
        p6Goblet.setEnabled(false);
        p6HatStand.setEnabled(false);
        p6SmartPhone.setEnabled(false);
        p6Spoon.setEnabled(false);
        p6boot.setEnabled(false);

        p5Cat.setEnabled(false);
        p5Goblet.setEnabled(false);
        p5HatStand.setEnabled(false);
        p5SmartPhone.setEnabled(false);
        p5Spoon.setEnabled(false);
        p5boot.setEnabled(false);

        p4Cat.setEnabled(false);
        p4Goblet.setEnabled(false);
        p4HatStand.setEnabled(false);
        p4SmartPhone.setEnabled(false);
        p4Spoon.setEnabled(false);
        p4boot.setEnabled(false);

        p3Cat.setEnabled(false);
        p3Goblet.setEnabled(false);
        p3HatStand.setEnabled(false);
        p3SmartPhone.setEnabled(false);
        p3Spoon.setEnabled(false);
        p3boot.setEnabled(false);
    }//GEN-LAST:event_NumberOfPlayersRadioButton2ActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p6CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6CatActionPerformed
        try {
            CheckTokenPlayer(6, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
    }//GEN-LAST:event_p6CatActionPerformed
    }

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p1CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1CatActionPerformed
        try {
            CheckTokenPlayer(1, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p1CatActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p2CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2CatActionPerformed
        try {
            CheckTokenPlayer(2, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p2CatActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p3CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3CatActionPerformed
        try {
            CheckTokenPlayer(3, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p3CatActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p4CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4CatActionPerformed
        try {
            CheckTokenPlayer(4, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p4CatActionPerformed

    //Listener Pass Player Number And selected Token Name To CheckToken Method
    private void p5CatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5CatActionPerformed
        try {
            CheckTokenPlayer(5, "Cat");
        } catch (NoSuchFieldException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_p5CatActionPerformed

    //This Method Call By Intilaizer Method For Check Number Of Players
    public int CheckNumberOfPlayers() {
        int numberOfPlayers = 0;
        if (NumberOfPlayersRadioButton2.isSelected()) {
            numberOfPlayers = 2;
        }
        if (NumberOfPlayersRadioButton3.isSelected()) {
            numberOfPlayers = 3;
        }
        if (NumberOfPlayersRadioButton4.isSelected()) {
            numberOfPlayers = 4;
        }
        if (NumberOfPlayersRadioButton5.isSelected()) {
            numberOfPlayers = 5;
        }
        if (NumberOfPlayersRadioButton6.isSelected()) {
            numberOfPlayers = 6;
        }
        return numberOfPlayers;
    }

    //This Method Call By Intilaizer Method For Check Tokens
    public String GetPlayertokens(int playerNumber) {
        String choicedToken = "";
        JRadioButton Boot = Awt1.getComponentByName(this, "p" + playerNumber + "boot");
        if (Boot.isSelected()) {
            choicedToken = "boot";
            return choicedToken;
        }
        JRadioButton Spoon = Awt1.getComponentByName(this, "p" + playerNumber + "Spoon");
        if (Spoon.isSelected()) {
            choicedToken = "Spoon";
            return choicedToken;
        }
        JRadioButton HatStand = Awt1.getComponentByName(this, "p" + playerNumber + "HatStand");
        if (HatStand.isSelected()) {
            choicedToken = "HatStand";
            return choicedToken;
        }
        JRadioButton SmartPhone = Awt1.getComponentByName(this, "p" + playerNumber + "SmartPhone");
        if (SmartPhone.isSelected()) {
            choicedToken = "SmartPhone";
            return choicedToken;
        }
        JRadioButton Goblet = Awt1.getComponentByName(this, "p" + playerNumber + "Goblet");
        if (Goblet.isSelected()) {
            choicedToken = "Goblet";
            return choicedToken;
        }
        JRadioButton Cat = Awt1.getComponentByName(this, "p" + playerNumber + "Cat");
        if (Cat.isSelected()) {
            choicedToken = "Cat";
            return choicedToken;
        }
        return choicedToken;
    }

    // Initializer Ckeck The Selected Values Of Player And Hide The Menu Panel And Shown Board Frame
    public void Initializer() {
        GameInitializer initializer = new GameInitializer();
        if (FullGameRadioButtom.isSelected()) {
            initializer.ModeIsClassic = true;
        } else {
            initializer.ModeIsClassic = false;
            initializer.TimeLimit = Integer.parseInt(AbrigedModeTime.getText());
        }
        int numberOfPlayers = 0;
        numberOfPlayers = CheckNumberOfPlayers();
        initializer.NumberOfPlayers = numberOfPlayers;
        Player[] PlayerArray = new Player[numberOfPlayers];

        //Seed Player 1    
        JTextField Name = Awt1.getComponentByName(this, "Player" + 1 + "Text");
        Player player1 = new Player(Name.getText());
        player1.setPlayerName(Name.getText());
        player1.setisLooser(false);
        player1.setcash(0);
        player1.setInJail(false);
        player1.TokenName = GetPlayertokens(1);
        player1.Position = 0;
        player1.setIsHuman(true);
        player1.setPassedGo(true);
        player1.setIsCompleteFirstCirciut(false);
        PlayerArray[0] = player1;
        
        //Seed Players 2 to 6
        for (int i = 2; i <= numberOfPlayers; i++) {
            Name = Awt1.getComponentByName(this, "Player" + i + "Text");
            Player tempplayer = new Player(Name.getText());
            tempplayer.setPlayerName(Name.getText());
            tempplayer.setisLooser(false);
            tempplayer.setcash(0);
            tempplayer.setInJail(false);
            tempplayer.TokenName = GetPlayertokens(i);
            tempplayer.Position = 0;
            JCheckBox humanCheck = Awt1.getComponentByName(this, "P" + i + "IsHumanCheckBox");
            tempplayer.setIsCompleteFirstCirciut(false);
            tempplayer.setIsHuman(humanCheck.isSelected());
            tempplayer.setPassedGo(true);
            PlayerArray[i - 1] = tempplayer;
        }
        
        //Fill Player Array In The initializer
        initializer.PlayerArray = PlayerArray;

        //Instantialize Gmae Board  By Send Initializer To Board Constractor
        try {
            Board board = new Board() {
            };
            this.setVisible(false);
            board.Show(initializer);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Check Selected Token For Any Player
    public void CheckTokenPlayer(int PlayerNumber, String TokenName) throws NoSuchFieldException {

        String beforeTokenName = "";
        int beforPlayerID = 0;

        JRadioButton Boot = Awt1.getComponentByName(this, "p" + PlayerNumber + "boot");
        if (Boot.isSelected() && !"boot".equals(TokenName)) {
            beforeTokenName = "boot";
        }
        JRadioButton Spoon = Awt1.getComponentByName(this, "p" + PlayerNumber + "Spoon");
        if (Spoon.isSelected() && !"Spoon".equals(TokenName)) {
            beforeTokenName = "Spoon";
        }
        JRadioButton HatStand = Awt1.getComponentByName(this, "p" + PlayerNumber + "HatStand");
        if (HatStand.isSelected() && !"HatStand".equals(TokenName)) {
            beforeTokenName = "HatStand";
        }
        JRadioButton SmartPhone = Awt1.getComponentByName(this, "p" + PlayerNumber + "SmartPhone");
        if (SmartPhone.isSelected() && !"SmartPhone".equals(TokenName)) {
            beforeTokenName = "SmartPhone";
        }
        JRadioButton Goblet = Awt1.getComponentByName(this, "p" + PlayerNumber + "Goblet");
        if (Goblet.isSelected() && !"Goblet".equals(TokenName)) {
            beforeTokenName = "Goblet";
        }
        JRadioButton Cat = Awt1.getComponentByName(this, "p" + PlayerNumber + "Cat");
        if (Cat.isSelected() && !"Cat".equals(TokenName)) {
            beforeTokenName = "Cat";
        }
        Boot.setSelected(false);
        Spoon.setSelected(false);
        HatStand.setSelected(false);
        SmartPhone.setSelected(false);
        Goblet.setSelected(false);
        Cat.setSelected(false);

        for (int i = 1; i < 7; i++) {

            if ("boot".equals(TokenName)) {
                JRadioButton BeforeBoot = Awt1.getComponentByName(this, "p" + i + "boot");
                if (BeforeBoot.isSelected()) {
                    beforPlayerID = i;
                }
            }

            if ("Spoon".equals(TokenName)) {
                JRadioButton beforeSpoon = Awt1.getComponentByName(this, "p" + i + "Spoon");
                if (beforeSpoon.isSelected()) {
                    beforPlayerID = i;
                }
            }

            if ("SmartPhone".equals(TokenName)) {
                JRadioButton beforeSmartPhone = Awt1.getComponentByName(this, "p" + i + "SmartPhone");
                if (beforeSmartPhone.isSelected()) {
                    beforPlayerID = i;
                }
            }

            if ("HatStand".equals(TokenName)) {
                JRadioButton beforeHatStand = Awt1.getComponentByName(this, "p" + i + "HatStand");
                if (beforeHatStand.isSelected()) {
                    beforPlayerID = i;
                }
            }
            if ("Goblet".equals(TokenName)) {
                JRadioButton beforeGoblet = Awt1.getComponentByName(this, "p" + i + "Goblet");
                if (beforeGoblet.isSelected()) {
                    beforPlayerID = i;
                }
            }
            if ("Cat".equals(TokenName)) {
                JRadioButton beforeCat = Awt1.getComponentByName(this, "p" + i + "Cat");
                if (beforeCat.isSelected()) {
                    beforPlayerID = i;
                }
            }
        }

        JRadioButton ThisPlayerChoice = Awt1.getComponentByName(this, "p" + PlayerNumber + TokenName);
        ThisPlayerChoice.setSelected(true);
        JRadioButton PastPlayerChoice = Awt1.getComponentByName(this, "p" + beforPlayerID + TokenName);
        PastPlayerChoice.setSelected(false);
        JRadioButton pastPLayerNowChoice = Awt1.getComponentByName(this, "p" + beforPlayerID + beforeTokenName);
        pastPLayerNowChoice.setSelected(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AbrigedModeTime;
    private javax.swing.JRadioButton FullGameRadioButtom;
    private javax.swing.JRadioButton LimitedGameRadioButtom;
    private javax.swing.JRadioButton NumberOfPlayersRadioButton2;
    private javax.swing.JRadioButton NumberOfPlayersRadioButton3;
    private javax.swing.JRadioButton NumberOfPlayersRadioButton4;
    private javax.swing.JRadioButton NumberOfPlayersRadioButton5;
    private javax.swing.JRadioButton NumberOfPlayersRadioButton6;
    private javax.swing.JCheckBox P2IsHumanCheckBox;
    private javax.swing.JCheckBox P3IsHumanCheckBox;
    private javax.swing.JCheckBox P4IsHumanCheckBox;
    private javax.swing.JCheckBox P5IsHumanCheckBox;
    private javax.swing.JCheckBox P6IsHumanCheckBox;
    private javax.swing.JTextField Player1Text;
    private javax.swing.JTextField Player2Text;
    private javax.swing.JTextField Player3Text;
    private javax.swing.JTextField Player4Text;
    private javax.swing.JTextField Player5Text;
    private javax.swing.JTextField Player6Text;
    private javax.swing.JPanel SelectGameModePanel;
    private javax.swing.JButton StartButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton logo;
    private javax.swing.JRadioButton p1Cat;
    private javax.swing.JRadioButton p1Goblet;
    private javax.swing.JRadioButton p1HatStand;
    private javax.swing.JRadioButton p1SmartPhone;
    private javax.swing.JRadioButton p1Spoon;
    private javax.swing.JRadioButton p1boot;
    private javax.swing.JRadioButton p2Cat;
    private javax.swing.JRadioButton p2Goblet;
    private javax.swing.JRadioButton p2HatStand;
    private javax.swing.JRadioButton p2SmartPhone;
    private javax.swing.JRadioButton p2Spoon;
    private javax.swing.JRadioButton p2boot;
    private javax.swing.JRadioButton p3Cat;
    private javax.swing.JRadioButton p3Goblet;
    private javax.swing.JRadioButton p3HatStand;
    private javax.swing.JRadioButton p3SmartPhone;
    private javax.swing.JRadioButton p3Spoon;
    private javax.swing.JRadioButton p3boot;
    private javax.swing.JRadioButton p4Cat;
    private javax.swing.JRadioButton p4Goblet;
    private javax.swing.JRadioButton p4HatStand;
    private javax.swing.JRadioButton p4SmartPhone;
    private javax.swing.JRadioButton p4Spoon;
    private javax.swing.JRadioButton p4boot;
    private javax.swing.JRadioButton p5Cat;
    private javax.swing.JRadioButton p5Goblet;
    private javax.swing.JRadioButton p5HatStand;
    private javax.swing.JRadioButton p5SmartPhone;
    private javax.swing.JRadioButton p5Spoon;
    private javax.swing.JRadioButton p5boot;
    private javax.swing.JRadioButton p6Cat;
    private javax.swing.JRadioButton p6Goblet;
    private javax.swing.JRadioButton p6HatStand;
    private javax.swing.JRadioButton p6SmartPhone;
    private javax.swing.JRadioButton p6Spoon;
    private javax.swing.JRadioButton p6boot;
    // End of variables declaration//GEN-END:variables
}
