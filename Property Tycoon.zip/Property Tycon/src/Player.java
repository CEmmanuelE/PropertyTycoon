
import java.util.ArrayList;

public class Player {

    private String PlayerName;
    public String TokenName;
    private double cash;
    public int Position;
    private boolean IsLooser;
    private boolean IsHuman;
    private boolean IsInJail;
    private boolean inJail;
    private int positionOnGameBoard;
    private boolean passedGo;
    private ArrayList<Entity> ownedProperties;
    private ArrayList<Card> outOfJailCards;
    private int turnsInJail;
    private boolean  IsCompleteFirstCirciut;
    
   
    public Player(String name) {
        this.PlayerName = name;
        this.cash = 1500;
        ownedProperties = new ArrayList<Entity>();
        outOfJailCards = new ArrayList<>();
    }

    public String getPlayerName() {
        return PlayerName;
    }

    public void setPlayerName(String name) {
        this.PlayerName = name;
    }

    public boolean getIsHuman() {
        return IsHuman;
    }

    public void setIsHuman(boolean value) {
        this.IsHuman = value;
    }

    
    public int getPositionOnGameBoard() {
        return positionOnGameBoard;
    }

    public void setPositionOnGameBoard(int positionOnGameBoard) {
		this.positionOnGameBoard += positionOnGameBoard;
		if (this.positionOnGameBoard >= 40) {
			setcash(200);
			setPassedGo(true);
			this.positionOnGameBoard = this.positionOnGameBoard % 40;
		}
	}

    public double getcash() {
        return cash;
    }

    public void setcash(double update) {
        this.cash += update;
    }

    public boolean didPassGo() {
        return passedGo;
    }

    public void setPassedGo(boolean passedGo) {
        this.passedGo = passedGo;
    }

    public int getNumberOfGetOutOfJailCards() {
        return outOfJailCards.size();
    }

    public void addGetOutOfJailCard(Card card) {
        outOfJailCards.add(card);
    }

    public ArrayList<Card> getOutOfJailCards() {
        return outOfJailCards;
    }

    public boolean isLooser() {
        return IsLooser;
    }

    public void setisLooser(boolean IsLooser) {
        this.IsLooser = IsLooser;
    }
    
    public ArrayList<Entity> getOwnedProperties() {
        return ownedProperties;
    }

    public void setOwnedProperties(ArrayList<Entity> ownedProperties) {
        this.ownedProperties = ownedProperties;
    }

    public int getTurnsInJail() {
        return turnsInJail;
    }

    public void setTurnsInJail(int turnsInJail) {
        this.turnsInJail = turnsInJail;
    }

    public boolean isInJail() {
		return inJail;
	}
	
	public void setInJail(boolean inJail) {
		this.inJail = inJail;
	}

    public boolean IsCompleteFirstCirciut() {
        return IsCompleteFirstCirciut;
    }

    public void setIsCompleteFirstCirciut(boolean IsCompleteFirstCirciut) {
        this.IsCompleteFirstCirciut = IsCompleteFirstCirciut;
    }

}
