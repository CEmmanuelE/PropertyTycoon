
public class ChanceCard extends Card {
	
	/**
	 * Constructor for the ChanceCard class
	 * @param id used to set id field
	 */
	public ChanceCard(int id) {
		super(id);
	}

}
