
import java.awt.List;
import java.util.ArrayList;

public class GameInitializer {
   
    public Player[] PlayerArray;
    public String BoardGameName;
    public boolean ModeIsClassic;
    public int NumberOfPlayers;
    public int TimeLimit;
}
