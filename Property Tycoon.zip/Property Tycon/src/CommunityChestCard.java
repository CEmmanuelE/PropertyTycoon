public class CommunityChestCard extends Card {

	/**
	 * Constructor for the CommunityChestCard class
	 * @param id used to set id field
	 */
	public CommunityChestCard(int id) {
		super(id);
	}

}
