
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.time.Duration;
import java.time.Instant;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class Board extends javax.swing.JFrame {

    //difine variabels
    private JFrame boardFrame;
    private JLayeredPane topLeft;
    private JLayeredPane bottomLeft;
    private JLayeredPane topRight;
    private JLayeredPane bottomRight;
    private JLayeredPane left_1;
    private JLayeredPane left_2;
    private JLayeredPane left_3;
    private JLayeredPane left_4;
    private JLayeredPane left_5;
    private JLayeredPane left_6;
    private JLayeredPane left_7;
    private JLayeredPane left_8;
    private JLayeredPane left_9;
    private JLayeredPane top_1;
    private JLayeredPane top_2;
    private JLayeredPane top_3;
    private JLayeredPane top_4;
    private JLayeredPane top_5;
    private JLayeredPane top_6;
    private JLayeredPane top_7;
    private JLayeredPane top_8;
    private JLayeredPane top_9;
    private JLayeredPane right_1;
    private JLayeredPane right_2;
    private JLayeredPane right_3;
    private JLayeredPane right_4;
    private JLayeredPane right_5;
    private JLayeredPane right_6;
    private JLayeredPane right_7;
    private JLayeredPane right_8;
    private JLayeredPane right_9;
    private JLayeredPane bottom_1;
    private JLayeredPane bottom_2;
    private JLayeredPane bottom_3;
    private JLayeredPane bottom_4;
    private JLayeredPane bottom_5;
    private JLayeredPane bottom_6;
    private JLayeredPane bottom_7;
    private JLayeredPane bottom_8;
    private JLayeredPane bottom_9;
    private DeckOfChanceAndCommunityChestCards deck;
    private Entities entities;
    // popup and Opportunity and Luck variables
    private int frameHeight;
    private int frameWidth;
    private JLabel PopUp;
    private JLabel instruction;
    private JButton Opportunity;
    private JButton LuckButton;
    private boolean opportunityCardPicked;
    private JButton Logo;
    //players variables
    private Player[] PlayerArray;
    private ArrayList<Player> players;
    private int playerIndex;
    private double paymentDueAmount;
    private int arrearsIndex;
    private ArrayList<JLayeredPane> playersPanes;
    private ArrayList<JLabel> playerIndicators;
    private JLabel player1;
    private JLabel player2;
    private JLabel player3;
    private JLabel player4;
    private JLabel player5;
    private JLabel player6;
    private JButton addPlayer1;
    private JButton addPlayer2;
    private JButton addPlayer3;
    private JButton addPlayer4;
    private JButton addPlayer5;
    private JButton addPlayer6;
    private JLayeredPane player_1;
    private JLayeredPane player_2;
    private JLayeredPane player_3;
    private JLayeredPane player_4;
    private JLayeredPane player_5;
    private JLayeredPane player_6;
    private JLabel player1nameLabel;
    private JLabel player2nameLabel;
    private JLabel player3nameLabel;
    private JLabel player4nameLabel;
    private JLabel player5nameLabel;
    private JLabel player6nameLabel;
    private JLabel player1balance;
    private JLabel player2balance;
    private JLabel player3balance;
    private JLabel player4balance;
    private JLabel player5balance;
    private JLabel player6balance;
    private JLabel player1token;
    private JLabel player2token;
    private JLabel player3token;
    private JLabel player4token;
    private JLabel player5token;
    private JLabel player6token;
    private JTextField player1name;
    private JLabel player1getOutOfJailLabel;
    private JLabel player2getOutOfJailLabel;
    private JLabel player3getOutOfJailLabel;
    private JLabel player4getOutOfJailLabel;
    private JLabel player5getOutOfJailLabel;
    private JLabel player6getOutOfJailLabel;

    //dice Variables
    private JButton rollTheDice;
    private JLabel dice1;
    private JLabel dice2;
    private int randomDice1;
    private int randomDice2;
    private Random random;
    private int doubleCounter;
    private int tmpPosition;

    //Gamepad and Logger Variables
    private JScrollPane gameLog;
    private JLayeredPane gameConsole;
    private JLabel gamePrompt;
    private JButton useGetOutOfJailCard;
    private JButton dontUseGetOutOfJailCard;
    private JButton pay50toGetOutOfJail;
    private JButton buyProperty;
    private JButton dontBuyProperty;
    private JButton payRent;
    private boolean extraRollNeeded;

    //buttons and labels
    private boolean sentByChanceCard;
    private boolean rentCalculated;
    private JLabel sellGetOutOfJailCard;
    private JButton sellGetOutOfJailCardButton;
    private boolean communityCardPicked;
    private JButton finishTurn;
    private int numberOfHotels;
    private int numberOfHouses;
    private boolean houseOrHotelBought;
    private JTextField cardPrice;
    private JComboBox<String> cardBuyers;
    private DefaultComboBoxModel<String> cardBuyersModel;
    private ArrayList<JLabel> balanceLabels;
    private ArrayList<JLabel> getOutOfJailLabels;
    double rentValue;
    private int ownerIndex;
    private JComboBox<String> buyUnwantedProperty;
    private DefaultComboBoxModel<String> buyUnwantedPropertyModel;
    private JTextField priceOfUnwantedProperty;
    private double valueOfUnwantedProperty;
    private JButton buyUnwantedPropertyButton;
    private JLabel mortgageManagement;
    private JComboBox<String> mortgageComboBox;
    private DefaultComboBoxModel<String> mortgageModel;
    private JButton takeLoan;
    private JButton payLoan;
    private JLabel sellProperty;
    private JComboBox<String> sellPropertyComboBox;
    private DefaultComboBoxModel<String> sellPropertyModel;
    private JComboBox<String> buyer;
    private DefaultComboBoxModel<String> buyerModel;
    private JTextField sellingPrice;
    private JButton sellPropertyButton;
    private JLabel buyBuilding;
    private JComboBox<String> addBuildingTo;
    private DefaultComboBoxModel<String> addBuildingToModel;
    private JButton addHouseButton;
    private JButton addHotelButton;
    private JButton payArrears;
    private JButton retireFromGame;
    private JButton yesButton;
    private JButton noButton;
    private JButton restartGame;
    private JTextArea logText;
    private String log;
    private JLabel buyOwnedProperty;
    private JComboBox<String> ownedProperties;
    private JTextField propertyOwner;
    private JTextField ownedPropertyValue;
    private JButton buyOwnedPropertyButton;
    private DefaultComboBoxModel<String> ownedPropertiesModel;
    private double valueOfOwnedProperty;
    private boolean gotDouble;
    private boolean paymentDue;
    private boolean chanceCardPicked;

    // Board     
    private ArrayList<JLayeredPane> boardPanels;
    private JLabel buildingLabel0;
    private JLabel buildingLabel1;
    private JLabel buildingLabel2;
    private JLabel buildingLabel3;
    private JLabel buildingLabel4;
    private JLabel buildingLabel5;
    private JLabel buildingLabel6;
    private JLabel buildingLabel7;
    private JLabel buildingLabel8;
    private JLabel buildingLabel9;
    private JLabel buildingLabel10;
    private JLabel buildingLabel11;
    private JLabel buildingLabel12;
    private JLabel buildingLabel13;
    private JLabel buildingLabel14;
    private JLabel buildingLabel15;
    private JLabel buildingLabel16;
    private JLabel buildingLabel17;
    private JLabel buildingLabel18;
    private JLabel buildingLabel19;
    private JLabel buildingLabel20;
    private JLabel buildingLabel21;
    private ArrayList<JLabel> buildingLabels;
    private JLabel bottomRightLabel;
    private JLabel bottom1Label;
    private JLabel bottom2Label;
    private JLabel bottom3Label;
    private JLabel bottom4Label;
    private JLabel bottom5Label;
    private JLabel bottom6Label;
    private JLabel bottom7Label;
    private JLabel bottom8Label;
    private JLabel bottom9Label;
    private JLabel bottomLeftLabel;
    private JLabel left1Label;
    private JLabel left2Label;
    private JLabel left3Label;
    private JLabel left4Label;
    private JLabel left5Label;
    private JLabel left6Label;
    private JLabel left7Label;
    private JLabel left8Label;
    private JLabel left9Label;
    private JLabel topLeftLabel;
    private JLabel top1Label;
    private JLabel top2Label;
    private JLabel top3Label;
    private JLabel top4Label;
    private JLabel top5Label;
    private JLabel top6Label;
    private JLabel top7Label;
    private JLabel top8Label;
    private JLabel top9Label;
    private JLabel topRightLabel;
    private JLabel right1Label;
    private JLabel right2Label;
    private JLabel right3Label;
    private JLabel right4Label;
    private JLabel right5Label;
    private JLabel right6Label;
    private JLabel right7Label;
    private JLabel right8Label;
    private JLabel right9Label;
    private Instant start;
    private JButton showInstruction;
    private JButton hideInstruction;
    private JScrollPane howToPlay;
    private JButton BackButton;
    private JButton FinishButton;
    private int TimeLimit;
    private Double ParkingMoney;

    //constractors
    public Board() {
        boardPanels = new ArrayList<JLayeredPane>();
        buildingLabels = new ArrayList<JLabel>();
        start = Instant.now();
    }

    //Show Board After Load
    public void Show(GameInitializer gameInitializer) {

        //instanstialize Board Variables
        TimeLimit = gameInitializer.TimeLimit;
        ParkingMoney = 0.0;
        JFrame boardFrame = new JFrame("Property Tycoon");
        FlowLayout flow = new FlowLayout();
        flow.setHgap(0);
        flow.setVgap(0);
        boardFrame.setLayout(flow);
        boardFrame.getContentPane().setBackground(new Color(131, 248, 244));
        boardFrame.setForeground(new Color(131, 248, 244));
        boardFrame.setBackground(new Color(131, 248, 244));
        boardFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        boardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        boardFrame.setSize(1366, 768);
        boardFrame.setLocationRelativeTo(null);
        boardFrame.setResizable(false);
        boardFrame.setVisible(true);
        boardFrame.getContentPane().setLayout(null);
        frameHeight = boardFrame.getHeight() - 40;
        frameWidth = boardFrame.getWidth();
        random = new Random();
        houseOrHotelBought = false;
        numberOfHotels = 12;
        numberOfHouses = 32;
        playersPanes = new ArrayList<JLayeredPane>();
        entities = new Entities();
        balanceLabels = new ArrayList<JLabel>();

        //instanstialize Players Variables
        players = new ArrayList<Player>();
        playerIndicators = new ArrayList<JLabel>();
        playerIndex = 0;
        getOutOfJailLabels = new ArrayList<JLabel>();

        //instanstialize deck Of Chance and Community Variables
        deck = new DeckOfChanceAndCommunityChestCards();
        sellGetOutOfJailCard = new JLabel("Sell get out of Jail card >>");
        sellGetOutOfJailCard.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 210), 150, 20);
        sellGetOutOfJailCardButton = new JButton("sell");
        sellGetOutOfJailCardButton.setBounds(frameHeight + 400, (int) (frameHeight / 2 + 210), 60, 20);
        sellGetOutOfJailCard.setVisible(false);
        sellGetOutOfJailCardButton.setVisible(false);

        // instantialize and bound board elements
        topLeft = new JLayeredPane();
        topLeft.setBounds(0, 0, (int) (frameHeight / 6.5), (int) (frameHeight / 6.5));
        left_1 = new JLayeredPane();
        left_1.setBounds(0, (int) (frameHeight / 6.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_2 = new JLayeredPane();
        left_2.setBounds(0, (int) (frameHeight / 6.5 * 1.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_3 = new JLayeredPane();
        left_3.setBounds(0, (int) (frameHeight / 6.5 * 2), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_4 = new JLayeredPane();
        left_4.setBounds(0, (int) (frameHeight / 6.5 * 2.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_5 = new JLayeredPane();
        left_5.setBounds(0, (int) (frameHeight / 6.5 * 3), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_6 = new JLayeredPane();
        left_6.setBounds(0, (int) (frameHeight / 6.5 * 3.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_7 = new JLayeredPane();
        left_7.setBounds(0, (int) (frameHeight / 6.5 * 4), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_8 = new JLayeredPane();
        left_8.setBounds(0, (int) (frameHeight / 6.5 * 4.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        left_9 = new JLayeredPane();
        left_9.setBounds(0, (int) (frameHeight / 6.5 * 5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        bottomLeft = new JLayeredPane();
        bottomLeft.setBounds(0, (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5), (int) (frameHeight / 6.5));
        top_1 = new JLayeredPane();
        top_1.setBounds((int) (frameHeight / 6.5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_2 = new JLayeredPane();
        top_2.setBounds((int) (frameHeight / 6.5 * 1.5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_3 = new JLayeredPane();
        top_3.setBounds((int) (frameHeight / 6.5 * 2), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_4 = new JLayeredPane();
        top_4.setBounds((int) (frameHeight / 6.5 * 2.5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_5 = new JLayeredPane();
        top_5.setBounds((int) (frameHeight / 6.5 * 3), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_6 = new JLayeredPane();
        top_6.setBounds((int) (frameHeight / 6.5 * 3.5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_7 = new JLayeredPane();
        top_7.setBounds((int) (frameHeight / 6.5 * 4), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_8 = new JLayeredPane();
        top_8.setBounds((int) (frameHeight / 6.5 * 4.5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        top_9 = new JLayeredPane();
        top_9.setBounds((int) (frameHeight / 6.5 * 5), 0, (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        topRight = new JLayeredPane();
        topRight.setBounds((int) (frameHeight / 6.5 * 5.5), 0, (int) (frameHeight / 6.5), (int) (frameHeight / 6.5));
        right_1 = new JLayeredPane();
        right_1.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_2 = new JLayeredPane();
        right_2.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 1.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_3 = new JLayeredPane();
        right_3.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 2), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_4 = new JLayeredPane();
        right_4.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 2.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_5 = new JLayeredPane();
        right_5.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 3), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_6 = new JLayeredPane();
        right_6.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 3.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_7 = new JLayeredPane();
        right_7.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 4), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_8 = new JLayeredPane();
        right_8.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 4.5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        right_9 = new JLayeredPane();
        right_9.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 5), (int) (frameHeight / 6.5), (int) (frameHeight / 13));
        bottom_1 = new JLayeredPane();
        bottom_1.setBounds((int) (frameHeight / 6.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_2 = new JLayeredPane();
        bottom_2.setBounds((int) (frameHeight / 6.5 * 1.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_3 = new JLayeredPane();
        bottom_3.setBounds((int) (frameHeight / 6.5 * 2), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_4 = new JLayeredPane();
        bottom_4.setBounds((int) (frameHeight / 6.5 * 2.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_5 = new JLayeredPane();
        bottom_5.setBounds((int) (frameHeight / 6.5 * 3), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_6 = new JLayeredPane();
        bottom_6.setBounds((int) (frameHeight / 6.5 * 3.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_7 = new JLayeredPane();
        bottom_7.setBounds((int) (frameHeight / 6.5 * 4), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_8 = new JLayeredPane();
        bottom_8.setBounds((int) (frameHeight / 6.5 * 4.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottom_9 = new JLayeredPane();
        bottom_9.setBounds((int) (frameHeight / 6.5 * 5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 13), (int) (frameHeight / 6.5));
        bottomRight = new JLayeredPane();
        bottomRight.setBounds((int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5 * 5.5), (int) (frameHeight / 6.5), (int) (frameHeight / 6.5));
        PopUp = new JLabel();
        PopUp.setBounds((int) (frameHeight / 6.5 * 1.95), (int) (frameHeight / 6.5 * 1.6), (int) (frameHeight * 0.4), (int) (frameHeight * 0.5));

        //popup Listener and bound -- Every Property On Game Board Shown A different Popup
        PopUp.setVisible(true);
        bottom_9.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/bottom_9.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

        });

        bottom_7.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {

            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource(
                            "resources/bottom_7.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

        });

        bottom_5.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {

            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource(
                            "resources/bottom_5.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

        });

        bottom_4.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource(
                            "resources/bottom_4.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        bottom_2.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource(
                            "resources/bottom_2.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        bottom_1.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/bottom_1.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        left_9.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_9.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        left_8.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_8.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        left_7.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_7.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        left_6.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_6.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        left_5.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_5.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        left_4.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_4.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        left_2.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_2.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        left_1.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/left_1.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        top_1.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_1.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        top_3.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_3.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        top_4.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_4.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        top_5.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_5.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        top_6.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_6.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        top_7.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_7.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        top_8.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_8.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        top_9.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/top_9.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        right_1.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_1.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        right_2.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_2.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        right_4.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_4.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        right_5.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_5.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        right_7.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_7.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }
        });

        right_9.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent arg0) {
            }

            @Override
            public void mouseEntered(MouseEvent arg0) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/right_9.jpg"));
                    PopUp.setIcon(new ImageIcon(img));
                    PopUp.setVisible(true);
                } catch (IOException ex) {
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                PopUp.setVisible(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

        });

        //instatialize and bound bulding cards
        buildingLabel0 = new JLabel();
        buildingLabel1 = new JLabel();
        buildingLabel2 = new JLabel();
        buildingLabel3 = new JLabel();
        buildingLabel4 = new JLabel();
        buildingLabel5 = new JLabel();
        buildingLabel6 = new JLabel();
        buildingLabel7 = new JLabel();
        buildingLabel8 = new JLabel();
        buildingLabel9 = new JLabel();
        buildingLabel10 = new JLabel();
        buildingLabel11 = new JLabel();
        buildingLabel12 = new JLabel();
        buildingLabel13 = new JLabel();
        buildingLabel14 = new JLabel();
        buildingLabel15 = new JLabel();
        buildingLabel16 = new JLabel();
        buildingLabel17 = new JLabel();
        buildingLabel18 = new JLabel();
        buildingLabel19 = new JLabel();
        buildingLabel20 = new JLabel();
        buildingLabel21 = new JLabel();

        buildingLabel0.setBounds((int) (frameHeight / 6.5 * 5) + 1, (int) (frameHeight / 6.5 * 5.5) + 1, 50, 25);
        buildingLabel1.setBounds((int) (frameHeight / 6.5 * 4) + 1, (int) (frameHeight / 6.5 * 5.5) + 1, 50, 25);
        buildingLabel2.setBounds((int) (frameHeight / 6.5 * 2.5) + 1, (int) (frameHeight / 6.5 * 5.5) + 1, 50, 25);
        buildingLabel3.setBounds((int) (frameHeight / 6.5 * 1.5) + 1, (int) (frameHeight / 6.5 * 5.5) + 1, 50, 25);
        buildingLabel4.setBounds((int) (frameHeight / 6.5) + 1, (int) (frameHeight / 6.5 * 5.5) + 1, 50, 25);
        buildingLabel5.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5 * 5) + 4, 25, 50);
        buildingLabel6.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5 * 4) + 4, 25, 50);
        buildingLabel7.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5 * 3.5) + 4, 25, 50);
        buildingLabel8.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5 * 2.5) + 4, 25, 50);
        buildingLabel9.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5 * 1.5) + 4, 25, 50);
        buildingLabel10.setBounds((int) (frameHeight / 6.5) - 26, (int) (frameHeight / 6.5) + 4, 25, 50);
        buildingLabel11.setBounds((int) (frameHeight / 6.5) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel12.setBounds((int) (frameHeight / 6.5 * 2) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel13.setBounds((int) (frameHeight / 6.5 * 2.5) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel14.setBounds((int) (frameHeight / 6.5 * 3.5) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel15.setBounds((int) (frameHeight / 6.5 * 4) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel16.setBounds((int) (frameHeight / 6.5 * 5) + 1, (int) (frameHeight / 6.5) - 26, 50, 25);
        buildingLabel17.setBounds((int) (frameHeight / 6.5 * 5.5) + 1, (int) (frameHeight / 6.5) + 1, 25, 50);
        buildingLabel18.setBounds((int) (frameHeight / 6.5 * 5.5) + 1, (int) (frameHeight / 6.5 * 1.5) + 1, 25, 50);
        buildingLabel19.setBounds((int) (frameHeight / 6.5 * 5.5) + 1, (int) (frameHeight / 6.5 * 2.5) + 1, 25, 50);
        buildingLabel20.setBounds((int) (frameHeight / 6.5 * 5.5) + 1, (int) (frameHeight / 6.5 * 4) + 1, 25, 50);
        buildingLabel21.setBounds((int) (frameHeight / 6.5 * 5.5) + 1, (int) (frameHeight / 6.5 * 5) + 1, 25, 50);

        buildingLabels.add(buildingLabel0);
        buildingLabels.add(buildingLabel1);
        buildingLabels.add(buildingLabel2);
        buildingLabels.add(buildingLabel3);
        buildingLabels.add(buildingLabel4);
        buildingLabels.add(buildingLabel5);
        buildingLabels.add(buildingLabel6);
        buildingLabels.add(buildingLabel7);
        buildingLabels.add(buildingLabel8);
        buildingLabels.add(buildingLabel9);
        buildingLabels.add(buildingLabel10);
        buildingLabels.add(buildingLabel11);
        buildingLabels.add(buildingLabel12);
        buildingLabels.add(buildingLabel13);
        buildingLabels.add(buildingLabel14);
        buildingLabels.add(buildingLabel15);
        buildingLabels.add(buildingLabel16);
        buildingLabels.add(buildingLabel17);
        buildingLabels.add(buildingLabel18);
        buildingLabels.add(buildingLabel19);
        buildingLabels.add(buildingLabel20);
        buildingLabels.add(buildingLabel21);

        Opportunity = new JButton("?");
        Logo = new JButton("?");
        boardPanels.add(bottomRight);
        boardPanels.add(bottom_9);
        boardPanels.add(bottom_8);
        boardPanels.add(bottom_7);
        boardPanels.add(bottom_6);
        boardPanels.add(bottom_5);
        boardPanels.add(bottom_4);
        boardPanels.add(bottom_3);
        boardPanels.add(bottom_2);
        boardPanels.add(bottom_1);
        boardPanels.add(bottomLeft);
        boardPanels.add(left_9);
        boardPanels.add(left_8);
        boardPanels.add(left_7);
        boardPanels.add(left_6);
        boardPanels.add(left_5);
        boardPanels.add(left_4);
        boardPanels.add(left_3);
        boardPanels.add(left_2);
        boardPanels.add(left_1);
        boardPanels.add(topLeft);
        boardPanels.add(top_1);
        boardPanels.add(top_2);
        boardPanels.add(top_3);
        boardPanels.add(top_4);
        boardPanels.add(top_5);
        boardPanels.add(top_6);
        boardPanels.add(top_7);
        boardPanels.add(top_8);
        boardPanels.add(top_9);
        boardPanels.add(topRight);
        boardPanels.add(right_1);
        boardPanels.add(right_2);
        boardPanels.add(right_3);
        boardPanels.add(right_4);
        boardPanels.add(right_5);
        boardPanels.add(right_6);
        boardPanels.add(right_7);
        boardPanels.add(right_8);
        boardPanels.add(right_9);

        bottomRightLabel = new JLabel();
        bottomLeftLabel = new JLabel();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/start.jpg"));
            bottomRightLabel.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottomLeft.jpg"));
            bottomLeftLabel.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        bottom1Label = new JLabel();
        bottom2Label = new JLabel();
        bottom3Label = new JLabel();
        bottom4Label = new JLabel();
        bottom5Label = new JLabel();
        bottom6Label = new JLabel();
        bottom7Label = new JLabel();
        bottom8Label = new JLabel();
        bottom9Label = new JLabel();

        setBottom1Clean();
        setBottom2Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom3.jpg"));
            bottom3Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setBottom4Clean();
        setBottom5Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom6.jpg"));
            bottom6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setBottom7Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom8.jpg"));
            bottom8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setBottom9Clean();
        bottom_1.setLayout(flow);
        bottom_2.setLayout(flow);
        bottom_3.setLayout(flow);
        bottom_4.setLayout(flow);
        bottom_5.setLayout(flow);
        bottom_6.setLayout(flow);
        bottom_7.setLayout(flow);
        bottom_8.setLayout(flow);
        bottom_9.setLayout(flow);
        bottomRight.setLayout(flow);
        bottomLeft.setLayout(flow);
        bottomRight.add(bottomRightLabel);
        bottomLeft.add(bottomLeftLabel);

        bottom_1.add(bottom1Label);
        bottom_2.add(bottom2Label);
        bottom_3.add(bottom3Label);
        bottom_4.add(bottom4Label);
        bottom_5.add(bottom5Label);
        bottom_6.add(bottom6Label);
        bottom_7.add(bottom7Label);
        bottom_8.add(bottom8Label);
        bottom_9.add(bottom9Label);

        left1Label = new JLabel();
        left2Label = new JLabel();
        left3Label = new JLabel();
        left4Label = new JLabel();
        left5Label = new JLabel();
        left6Label = new JLabel();
        left7Label = new JLabel();
        left8Label = new JLabel();
        left9Label = new JLabel();

        setLeft1Clean();
        setLeft2Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left3.jpg"));
            left3Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setLeft4Clean();
        setLeft5Clean();
        setLeft6Clean();
        setLeft7Clean();
        setLeft8Clean();
        setLeft9Clean();

        left_1.setLayout(flow);
        left_2.setLayout(flow);
        left_3.setLayout(flow);
        left_4.setLayout(flow);
        left_5.setLayout(flow);
        left_6.setLayout(flow);
        left_7.setLayout(flow);
        left_8.setLayout(flow);
        left_9.setLayout(flow);
        left_1.add(left1Label);
        left_2.add(left2Label);
        left_3.add(left3Label);
        left_4.add(left4Label);
        left_5.add(left5Label);
        left_6.add(left6Label);
        left_7.add(left7Label);
        left_8.add(left8Label);
        left_9.add(left9Label);

        topLeftLabel = new JLabel();
        top1Label = new JLabel();
        top2Label = new JLabel();
        top3Label = new JLabel();
        top4Label = new JLabel();
        top5Label = new JLabel();
        top6Label = new JLabel();
        top7Label = new JLabel();
        top8Label = new JLabel();
        top9Label = new JLabel();

        topLeft.setLayout(flow);
        top_1.setLayout(flow);
        top_2.setLayout(flow);
        top_3.setLayout(flow);
        top_4.setLayout(flow);
        top_5.setLayout(flow);
        top_6.setLayout(flow);
        top_7.setLayout(flow);
        top_8.setLayout(flow);
        top_9.setLayout(flow);
        topLeft.add(topLeftLabel);
        top_1.add(top1Label);
        top_2.add(top2Label);
        top_3.add(top3Label);
        top_4.add(top4Label);
        top_5.add(top5Label);
        top_6.add(top6Label);
        top_7.add(top7Label);
        top_8.add(top8Label);
        top_9.add(top9Label);

        setTop1Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top2.jpg"));
            top2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        try {
            Image img = ImageIO.read(getClass().getResource("resources/topLeft.jpg"));
            topLeftLabel.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setTop3Clean();
        setTop4Clean();
        setTop5Clean();
        setTop6Clean();
        setTop7Clean();
        setTop8Clean();
        setTop9Clean();
        topRightLabel = new JLabel();
        right1Label = new JLabel();
        right2Label = new JLabel();
        right3Label = new JLabel();
        right4Label = new JLabel();
        right5Label = new JLabel();
        right6Label = new JLabel();
        right7Label = new JLabel();
        right8Label = new JLabel();
        right9Label = new JLabel();

        topRight.setLayout(flow);
        right_1.setLayout(flow);
        right_2.setLayout(flow);
        right_3.setLayout(flow);
        right_4.setLayout(flow);
        right_5.setLayout(flow);
        right_6.setLayout(flow);
        right_7.setLayout(flow);
        right_8.setLayout(flow);
        right_9.setLayout(flow);
        topRight.add(topRightLabel);
        right_1.add(right1Label);
        right_2.add(right2Label);
        right_3.add(right3Label);
        right_4.add(right4Label);
        right_5.add(right5Label);
        right_6.add(right6Label);
        right_7.add(right7Label);
        right_8.add(right8Label);
        right_9.add(right9Label);

        setRight1Clean();
        setRight2Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right3.jpg"));
            right3Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setRight4Clean();
        setRight5Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right6.jpg"));
            right6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setRight7Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right8.jpg"));
            right8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        setRight9Clean();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/topRight.jpg"));
            topRightLabel.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        Opportunity = new JButton();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/chest.jpg"));
            Opportunity.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        Logo = new JButton();
        try {
            Image img = ImageIO.read(getClass().getResource("resources/BoardLogo.png"));
            Logo.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        Logo.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        Logo.setBorderPainted(false);
        Logo.setContentAreaFilled(false);
        Logo.setBounds((int) (frameHeight / 6.5 * 2.28), (int) (frameHeight / 6.5 * 1.125), (int) (frameHeight / 3.33), (int) (frameHeight / 5));
        Logo.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        Opportunity.setBounds((int) (frameHeight / 6.5 * 1.125), (int) (frameHeight / 6.5 * 4), (int) (frameHeight / 3.33), (int) (frameHeight / 5));
        Opportunity.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        Opportunity.setBorderPainted(false);
        Opportunity.setContentAreaFilled(false);
        // Opportunity.setEnabled(false);
        LuckButton = new JButton();
        LuckButton.setBounds((int) (frameHeight / 6.5 * 3.5), (int) (frameHeight / 6.5 * 4), (int) (frameHeight / 3.33), (int) (frameHeight / 5));
        try {
            Image img = ImageIO.read(getClass().getResource("resources/chance.jpg"));
            LuckButton.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        //instantialize and bound players 
        //players come from previouse frame(menu Frame)
        LuckButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        LuckButton.setBorderPainted(false);
        LuckButton.setContentAreaFilled(false);

        addPlayer1 = new JButton();
        addPlayer2 = new JButton();
        addPlayer3 = new JButton();
        addPlayer4 = new JButton();
        addPlayer5 = new JButton();
        addPlayer6 = new JButton();

        player_1 = new JLayeredPane();
        player_1.setBounds(frameHeight + 40, 0, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_1.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        player_2 = new JLayeredPane();
        player_2.setBounds(frameHeight + 42 + (int) (frameHeight / 4), 0, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_2.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        player_3 = new JLayeredPane();
        player_3.setBounds(frameHeight + 44 + (int) (frameHeight / 2), 0, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_3.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        player_4 = new JLayeredPane();
        player_4.setBounds(frameHeight + 40, (int) (frameHeight / 6.5) + 2, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_4.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        player_5 = new JLayeredPane();
        player_5.setBounds(frameHeight + 42 + (int) (frameHeight / 4), (int) (frameHeight / 6.5) + 2, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_5.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        player_6 = new JLayeredPane();
        player_6.setBounds(frameHeight + 44 + (int) (frameHeight / 2), (int) (frameHeight / 6.5) + 2, (int) (frameHeight / 4), (int) (frameHeight / 6.5));
        player_6.setBorder(BorderFactory.createLineBorder(Color.black, 2));

        int playersNumber = gameInitializer.PlayerArray.length;

        player1 = new JLabel();
        player2 = new JLabel();
        player3 = new JLabel();
        player4 = new JLabel();
        player5 = new JLabel();
        player6 = new JLabel();

        for (int i = 1; i < 7; i++) {
            if (i <= playersNumber) {
                if (i == 1) {
                    player1nameLabel = new JLabel();
                    player1balance = new JLabel();
                    player1token = new JLabel();
                    balanceLabels.add(player1balance);
                    player1getOutOfJailLabel = new JLabel();
                    player1nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player1balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player1token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player1.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player1nameLabel.setForeground(Color.RED);
                    player1balance.setForeground(Color.RED);
                    player1nameLabel.setBounds(20, 10, 140, 30);
                    player1balance.setBounds(20, 30, 140, 30);
                    player1token.setBounds(20, 60, 140, 50);
                    player1nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player1balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_1.add(player1nameLabel);
                    player_1.add(player1balance);
                    player_1.add(player1token);

                    boardFrame.getContentPane().add(player_1, -1);
                    playerIndicators.add(player1);
                    playerIndex = 0;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player1);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());

                    player1getOutOfJailLabel.setText("get out of jail cards : " + players.get(0).getNumberOfGetOutOfJailCards());
                    player1getOutOfJailLabel.setBounds(frameHeight + 60, 50, 140, 15);
                    player1getOutOfJailLabel.setFont(new Font("Arial", Font.ITALIC, 12));
                    player1getOutOfJailLabel.setVisible(false);
                    getOutOfJailLabels.add(player1getOutOfJailLabel);

                    playersPanes.add(player_1);
                    player_1.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(1);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(0)
                                    .getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.red));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.red));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.red));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.red));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(0).getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
                if (i == 2) {
                    player2nameLabel = new JLabel();
                    player2balance = new JLabel();
                    player2token = new JLabel();
                    balanceLabels.add(player2balance);
                    player2nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player2balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player2token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player2.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player2nameLabel.setForeground(Color.BLUE);
                    player2balance.setForeground(Color.BLUE);
                    player2nameLabel.setBounds(20, 10, 140, 30);
                    player2balance.setBounds(20, 30, 140, 30);
                    player2token.setBounds(20, 60, 140, 50);
                    player2nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player2balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_2.add(player2nameLabel);
                    player_2.add(player2balance);
                    player_2.add(player2token);
                    boardFrame.getContentPane().add(player_2, -1);
                    playerIndicators.add(player2);
                    playerIndex = 1;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player2);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    playersPanes.add(player_2);
                    player_2.addMouseListener(new MouseListener() {
                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(2);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(1)
                                    .getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.blue));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.blue));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.blue));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.blue));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(1)
                                    .getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
                if (i == 3) {
                    player3nameLabel = new JLabel();
                    player3balance = new JLabel();
                    player3token = new JLabel();
                    balanceLabels.add(player3balance);
                    player3nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player3balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player3token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player3.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player3nameLabel.setForeground(Color.BLACK);
                    player3balance.setForeground(Color.BLACK);
                    player3nameLabel.setBounds(20, 10, 140, 30);
                    player3balance.setBounds(20, 30, 140, 30);
                    player3token.setBounds(20, 60, 140, 50);
                    player3nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player3balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_3.add(player3nameLabel);
                    player_3.add(player3balance);
                    player_3.add(player3token);
                    boardFrame.getContentPane().add(player_3, -1);
                    playerIndicators.add(player3);
                    playerIndex = 2;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player3);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    playersPanes.add(player_3);
                    player_3.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(3);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(2)
                                    .getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.black));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.black));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.black));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.black));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(2).getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
                if (i == 4) {
                    player4nameLabel = new JLabel();
                    player4balance = new JLabel();
                    balanceLabels.add(player4balance);
                    player4token = new JLabel();
                    player4nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player4balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player4token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player4.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player4nameLabel.setForeground(Color.pink);
                    player4balance.setForeground(Color.pink);
                    player4nameLabel.setBounds(20, 10, 140, 30);
                    player4balance.setBounds(20, 30, 140, 30);
                    player4token.setBounds(20, 60, 140, 50);
                    player4nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player4balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_4.add(player4nameLabel);
                    player_4.add(player4balance);
                    player_4.add(player4token);
                    boardFrame.getContentPane().add(player_4, -1);
                    playerIndicators.add(player4);
                    playerIndex = 3;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player4);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    playersPanes.add(player_4);

                    player_4.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(4);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(3).getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.pink));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.pink));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.pink));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.pink));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(3).getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
                if (i == 5) {
                    player5nameLabel = new JLabel();
                    player5balance = new JLabel();
                    player5token = new JLabel();
                    balanceLabels.add(player5balance);
                    player5nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player5balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player5token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player5.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player5nameLabel.setForeground(Color.ORANGE);
                    player5balance.setForeground(Color.ORANGE);
                    player5nameLabel.setBounds(20, 10, 140, 30);
                    player5balance.setBounds(20, 30, 140, 30);
                    player5token.setBounds(20, 60, 140, 50);
                    player5nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player5balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_5.add(player5nameLabel);
                    player_5.add(player5balance);
                    player_5.add(player5token);
                    boardFrame.getContentPane().add(player_5, -1);
                    playerIndicators.add(player5);
                    playerIndex = 4;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player5);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    playersPanes.add(player_5);

                    player_5.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(5);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(4)
                                    .getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.orange));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.orange));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.orange));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.orange));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(4).getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(
                                        BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
                if (i == 6) {
                    player6nameLabel = new JLabel();
                    player6balance = new JLabel();
                    player6token = new JLabel();
                    balanceLabels.add(player6balance);
                    player6nameLabel.setText(gameInitializer.PlayerArray[i - 1].getPlayerName());
                    player6balance.setText("Cash : " + Double.toString(gameInitializer.PlayerArray[i - 1].getcash()));
                    switch (gameInitializer.PlayerArray[i - 1].TokenName) {
                        case "boot":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/boot.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/boot.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Cat":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/cat.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/Cat.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "SmartPhone":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/smartPhone.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/smartPhone.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Goblet":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/goblet.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/goblet.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "Spoon":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/spoon.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/spoon.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                        case "HatStand":
                            player6token.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Content/hatstand.png")));
                            try {
                                Image img = ImageIO.read(getClass().getResource("/Content/hatstand.png"));
                                player6.setIcon(new ImageIcon(img));
                            } catch (IOException ex) {
                            }
                            break;
                    }
                    player6nameLabel.setForeground(Color.magenta);
                    player6balance.setForeground(Color.magenta);
                    player6nameLabel.setBounds(20, 10, 140, 30);
                    player6balance.setBounds(20, 30, 140, 30);
                    player6token.setBounds(20, 60, 140, 50);
                    player6nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                    player6balance.setFont(new Font("Arial", Font.ITALIC, 14));
                    player_6.add(player6nameLabel);
                    player_6.add(player6balance);
                    player_6.add(player6token);
                    boardFrame.getContentPane().add(player_6, -1);
                    playerIndicators.add(player6);
                    playerIndex = 5;
                    playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                    boardFrame.add(player6);
                    players.add(new Player(gameInitializer.PlayerArray[i - 1].getPlayerName()));
                    players.get(i - 1).setIsHuman(gameInitializer.PlayerArray[i - 1].getIsHuman());
                    playersPanes.add(player_6);
                    player_6.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent arg0) {
                            try {
                                ShowPlayerProperties(6);
                            } catch (IOException ex) {
                                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                        @Override
                        public void mouseEntered(MouseEvent arg0) {

                            for (Entity property : players.get(5)
                                    .getOwnedProperties()) {
                                if (property.getPosition() < 10) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.magenta));
                                } else if (property.getPosition() < 20) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 6, Color.magenta));
                                } else if (property.getPosition() < 30) {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(4, 0, 0, 0, Color.magenta));
                                } else {
                                    boardPanels.get(property.getPosition()).setBorder(BorderFactory.createMatteBorder(0, 5, 0, 0, Color.magenta));
                                }
                            }
                        }

                        @Override
                        public void mouseExited(MouseEvent arg0) {
                            for (Entity property : players.get(5).getOwnedProperties()) {
                                boardPanels.get(property.getPosition()).setBorder(
                                        BorderFactory.createEmptyBorder());
                            }
                        }

                        @Override
                        public void mousePressed(MouseEvent arg0) {
                        }

                        @Override
                        public void mouseReleased(MouseEvent arg0) {
                        }
                    });
                }
            }
        }

        //instantialize and bount dice button
        rollTheDice = new JButton();
        rollTheDice.setBounds(frameHeight / 2 - 70, frameHeight / 2 + 40, 140, 40);
        try {
            Image img = ImageIO.read(getClass().getResource("resources/rollthedice.jpg"));
            rollTheDice.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        rollTheDice.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        rollTheDice.setBorderPainted(false);
        rollTheDice.setContentAreaFilled(false);
        rollTheDice.setVisible(false);
        dice1 = new JLabel();
        dice1.setBounds(frameHeight / 2 - 110, frameHeight / 2 - 70, 100, 100);
        try {
            Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
            dice1.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        dice2 = new JLabel();
        dice2.setBounds(frameHeight / 2, frameHeight / 2 - 70, 100, 100);
        try {
            Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
            dice2.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        dice1.setVisible(false);
        dice2.setVisible(false);
        boardFrame.getContentPane().add(rollTheDice);
        boardFrame.getContentPane().add(dice1);
        boardFrame.getContentPane().add(dice2);

        //GamePad And Logger and other buttoms
        gameConsole = new JLayeredPane();
        gamePrompt = new JLabel();
        restartGame = new JButton();
        gamePrompt.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 15), (int) (frameHeight / 4) * 3 - 20, 15);
        pay50toGetOutOfJail = new JButton("pay £50 to get out of Jail");
        pay50toGetOutOfJail.setBounds(frameHeight + 200, (int) (frameHeight / 2 + 60), 230, 20);
        pay50toGetOutOfJail.setVisible(false);
        gamePrompt.setHorizontalAlignment(SwingConstants.CENTER);
        gamePrompt.setForeground(Color.RED);
        useGetOutOfJailCard = new JButton("use the card");
        dontUseGetOutOfJailCard = new JButton("don't use the card");
        useGetOutOfJailCard.setBounds(frameHeight + 150, (int) (frameHeight / 2 + 35), 160, 20);
        dontUseGetOutOfJailCard.setBounds(frameHeight + 320, (int) (frameHeight / 2 + 35), 160, 20);
        useGetOutOfJailCard.setVisible(false);
        dontUseGetOutOfJailCard.setVisible(false);
        buyProperty = new JButton("buy");
        dontBuyProperty = new JButton("don't buy");
        payRent = new JButton("pay rent");
        payArrears = new JButton("pay arrears");
        payArrears.setBounds(frameHeight + 200, (int) (frameHeight / 2 + 60), 230, 20);
        retireFromGame = new JButton("retire from game");
        yesButton = new JButton("yes");
        noButton = new JButton("no");
        yesButton.setVisible(false);
        noButton.setVisible(false);
        yesButton.setBounds(frameHeight + 180, (int) (frameHeight / 2 + 35), 135, 20);
        noButton.setBounds(frameHeight + 325, (int) (frameHeight / 2 + 35), 135, 20);
        retireFromGame.setBounds(frameHeight + 170, (int) (frameHeight / 2 + 35), 290, 20);
        buyProperty.setBounds(frameHeight + 150, (int) (frameHeight / 2 + 35), 160, 20);
        dontBuyProperty.setBounds(frameHeight + 320, (int) (frameHeight / 2 + 35), 160, 20);
        payRent.setBounds(frameHeight + 200, (int) (frameHeight / 2 + 60), 230, 20);
        retireFromGame.setVisible(false);
        buyProperty.setVisible(false);
        dontBuyProperty.setVisible(false);
        payRent.setVisible(false);
        payArrears.setVisible(false);
        logText = new JTextArea();
        logText.setFont(new Font("Arial", Font.BOLD, 12));
        log = "  Game started\n";
        logText.append(log);
        gameLog = new JScrollPane(logText);
        gameConsole.setBounds(frameHeight + 40, (int) (frameHeight / 2), (int) (frameHeight / 4) * 3, (int) (frameHeight / 2.8));
        gameLog.setBounds(frameHeight + 40, (int) (frameHeight / 3.25 + 20), (int) (frameHeight / 4) * 3, (int) (frameHeight / 6.5));
        gameLog.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        Border lined = BorderFactory.createLineBorder(Color.black, 1);
        Border innerGameLog1 = BorderFactory.createTitledBorder(lined, "Game Logs:", 2, 2, new Font("Arial", Font.ITALIC, 12), Color.black);
        Border innerGameConsole1 = BorderFactory.createTitledBorder(lined, "Game Pad:", 2, 2, new Font("Arial", Font.ITALIC, 12), Color.black);
        Border outerBorder = BorderFactory.createEmptyBorder(2, 0, 2, 0);
        gameLog.setBorder(BorderFactory.createCompoundBorder(outerBorder, innerGameLog1));
        gameConsole.setBorder(BorderFactory.createCompoundBorder(outerBorder, innerGameConsole1));
        buyUnwantedProperty = new JComboBox<String>();
        buyUnwantedProperty.setBounds(frameHeight + 150, (int) (frameHeight / 2 + 35), 140, 20);
        buyUnwantedProperty.setVisible(false);
        buyUnwantedPropertyButton = new JButton("buy");
        buyUnwantedPropertyButton.setBounds(frameHeight + 360, (int) (frameHeight / 2 + 35), 120, 20);
        buyUnwantedPropertyButton.setEnabled(false);
        buyUnwantedPropertyButton.setVisible(false);
        priceOfUnwantedProperty = new JTextField();
        priceOfUnwantedProperty.setBounds(frameHeight + 300, (int) (frameHeight / 2 + 35), 45, 20);
        priceOfUnwantedProperty.setVisible(false);
        mortgageManagement = new JLabel("Mortgager");
        mortgageManagement.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 90), 150, 20);
        mortgageComboBox = new JComboBox<String>();
        mortgageComboBox.setBounds(frameHeight + 205, (int) (frameHeight / 2 + 90), 160, 20);
        takeLoan = new JButton("take a loan");
        payLoan = new JButton("pay the loan");
        takeLoan.setBounds(frameHeight + 370, (int) (frameHeight / 2 + 90), 100, 20);
        payLoan.setBounds(frameHeight + 475, (int) (frameHeight / 2 + 90), 105, 20);
        mortgageManagement.setVisible(false);
        mortgageComboBox.setVisible(false);
        takeLoan.setVisible(false);
        payLoan.setVisible(false);
        sellProperty = new JLabel("Sell property >>");
        sellProperty.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 120), 90, 20);
        sellProperty.setVisible(true);
        sellPropertyComboBox = new JComboBox<String>();
        sellPropertyComboBox.setBounds(frameHeight + 155, (int) (frameHeight / 2 + 120), 160, 20);
        buyer = new JComboBox<String>();
        buyer.setBounds(frameHeight + 320, (int) (frameHeight / 2 + 120), 140, 20);
        sellingPrice = new JTextField();
        sellingPrice.setBounds(frameHeight + 465, (int) (frameHeight / 2 + 120), 45, 20);
        sellPropertyButton = new JButton("sell");
        sellPropertyButton.setBounds(frameHeight + 515, (int) (frameHeight / 2 + 120), 60, 20);
        sellProperty.setVisible(false);
        sellPropertyComboBox.setVisible(false);
        buyer.setVisible(false);
        sellingPrice.setVisible(false);
        sellPropertyButton.setVisible(false);
        buyOwnedProperty = new JLabel("Buy property >>");
        ownedProperties = new JComboBox<String>();
        propertyOwner = new JTextField();
        ownedPropertyValue = new JTextField();
        buyOwnedPropertyButton = new JButton("buy");
        buyOwnedProperty.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 150), 110, 20);
        ownedProperties.setBounds(frameHeight + 165, (int) (frameHeight / 2 + 150), 160, 20);
        propertyOwner.setBounds(frameHeight + 330, (int) (frameHeight / 2 + 150), 100, 20);
        ownedPropertyValue.setBounds(frameHeight + 435, (int) (frameHeight / 2 + 150), 45, 20);
        buyOwnedPropertyButton.setBounds(frameHeight + 485, (int) (frameHeight / 2 + 150), 60, 20);
        propertyOwner.setEditable(false);
        ownedPropertyValue.setToolTipText("price");
        buyOwnedProperty.setVisible(false);
        ownedProperties.setVisible(false);
        propertyOwner.setVisible(false);
        ownedPropertyValue.setVisible(false);
        buyOwnedPropertyButton.setVisible(false);
        buyBuilding = new JLabel("Add house or hotel >>");
        addBuildingTo = new JComboBox<String>();
        addHouseButton = new JButton("+ house");
        addHotelButton = new JButton("+ hotel");
        buyBuilding.setBounds(frameHeight + 50, (int) (frameHeight / 2 + 180), 130, 20);
        addBuildingTo.setBounds(frameHeight + 185, (int) (frameHeight / 2 + 180), 200, 20);
        addHouseButton.setBounds(frameHeight + 390, (int) (frameHeight / 2 + 180), 90, 20);
        addHotelButton.setBounds(frameHeight + 485, (int) (frameHeight / 2 + 180), 90, 20);
        buyBuilding.setVisible(false);
        addBuildingTo.setVisible(false);
        addHouseButton.setVisible(false);
        addHotelButton.setVisible(false);

        buyUnwantedProperty.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                priceOfUnwantedProperty.setText("");
                String comboSelection = String.valueOf(buyUnwantedProperty
                        .getSelectedItem());
                System.out.println(comboSelection);
            }
        });

        finishTurn = new JButton();
        finishTurn.setBounds(frameHeight + 60 + (int) (frameHeight / 4), frameHeight - 80, 140, 40);
        try {
            Image img = ImageIO.read(getClass().getResource("resources/finishturn.jpg"));
            finishTurn.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        restartGame.setBounds(frameHeight + 60 + (int) (frameHeight / 4), frameHeight - 70, 140, 20);
        restartGame.setVisible(false);
        try {
            Image img = ImageIO.read(getClass().getResource(
                    "resources/startthegame.jpg"));
            restartGame.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        useGetOutOfJailCard.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (!sentByChanceCard) {
                    if (!players.get(playerIndex).isInJail()
                            && players.get(playerIndex).getPositionOnGameBoard() == 30) {
                        if (doubleCounter == 3 || !gotDouble) {
                            finishTurn.setEnabled(true);
                            log = players.get(playerIndex).getPlayerName() + " used his/her get out of Jail card to avoid going to Jail" + "\n";
                            logText.append(log);
                            adjustPlayerPosition();
                        } else if (gotDouble) {
                            rollTheDice.setEnabled(true);
                        }

                    } else if (!players.get(playerIndex).isInJail() && players.get(playerIndex).getPositionOnGameBoard() != 30) {
                        if (doubleCounter == 3 || !gotDouble) {
                            finishTurn.setEnabled(true);
                        }
                        adjustPlayerPosition();
                        log = players.get(playerIndex).getPlayerName() + " used his/her get out of Jail card to avoid going to Jail" + "\n";
                        logText.append(log);
                    } else {
                        rollTheDice.setEnabled(true);
                        players.get(playerIndex).setInJail(false);
                        players.get(playerIndex).setTurnsInJail(0);
                        pay50toGetOutOfJail.setVisible(false);
                        log = players.get(playerIndex).getPlayerName() + " used his/her get out of Jail card to get out of Jail" + "\n";
                        logText.append(log);
                        extraRollNeeded = false;
                    }
                    buyOrRent();
                } else {
                    log = players.get(playerIndex).getPlayerName() + " used his/her get out of Jail card to avoid going to Jail" + "\n";
                    logText.append(log);
                    sentByChanceCard = false;
                    if (!gotDouble) {
                        finishTurn.setEnabled(true);
                    } else {
                        rollTheDice.setEnabled(true);
                    }
                }
                useGetOutOfJailCard.setVisible(false);
                dontUseGetOutOfJailCard.setVisible(false);
                if (players.get(playerIndex).getOutOfJailCards().get(0) instanceof ChanceCard) {
                    players.get(playerIndex).getOutOfJailCards().remove(0);
                    deck.returnOutOfJailCardChance();
                } else {
                    players.get(playerIndex).getOutOfJailCards().remove(0);
                    deck.returnOutOfJailCardCommunity();
                }

                gamePrompt.setText("");
                getOutOfJailLabels.get(playerIndex).setText("get out of jail cards : " + players.get(playerIndex).getNumberOfGetOutOfJailCards());
                if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                    getOutOfJailLabels.get(playerIndex).setVisible(false);
                }
            }
        });

        dontUseGetOutOfJailCard.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                players.get(playerIndex).setPositionOnGameBoard(10 - players.get(playerIndex).getPositionOnGameBoard());
                players.get(playerIndex).setInJail(true);
                adjustPlayerPosition();
                if (doubleCounter == 3) {
                    log = players.get(playerIndex).getPlayerName() + " went to Jail for rolling 3 doubles " + "\n";
                    logText.append(log);
                } else {
                    log = players.get(playerIndex).getPlayerName() + " went to Jail" + "\n";
                    logText.append(log);
                }
                finishTurn.setEnabled(true);
                gamePrompt.setText("");
                useGetOutOfJailCard.setVisible(false);
                dontUseGetOutOfJailCard.setVisible(false);

            }
        });
        finishTurn.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        finishTurn.setBorderPainted(false);
        finishTurn.setContentAreaFilled(false);
        finishTurn.setEnabled(false);
        finishTurn.setVisible(false);
        showInstruction = new JButton();
        showInstruction.setBounds(frameWidth - 45, 10, 40, 40);
        try {
            Image img = ImageIO.read(getClass().getResource(
                    "resources/instruction.png"));
            showInstruction.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        //Listener Shown Help Panel
        showInstruction.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {

                try {
                    ShowHelp();
                } catch (IOException ex) {
                    Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        // Bound And Listener For Back button
        BackButton = new JButton();
        BackButton.setBounds(frameWidth - 45, 50, 40, 40);
        try {
            Image img = ImageIO.read(getClass().getResource(
                    "resources/back.png"));
            BackButton.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        //Back To Main Menu Game
        BackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                boardFrame.setVisible(false);
                MenuFrame menuFrame = new MenuFrame();
                menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                Color BackgroundColor = new Color(29, 16, 44);
                menuFrame.getContentPane().setBackground(BackgroundColor);

                Dimension d = new Dimension(1158, 551);
                Container c = menuFrame.getContentPane();
                c.setPreferredSize(d);

                menuFrame.setVisible(true);
                menuFrame.pack();
                menuFrame.setLocationRelativeTo(null);
                menuFrame.setResizable(false);
            }
        });

        // Loos Button 
        FinishButton = new JButton();
        FinishButton.setBounds(frameWidth - 45, 90, 40, 40);
        try {
            Image img = ImageIO.read(getClass().getResource(
                    "resources/finish.png"));
            FinishButton.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }

        //Show Hint About Are You Retire And Visible Yes Or No Buttons
        FinishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                gamePrompt.setText("Are you sure you want to retire from the game?");
                yesButton.setVisible(true);
                noButton.setVisible(true);
            }
        });

        // Add elements to Content Pane Of board
        boardFrame.getContentPane().add(finishTurn);
        boardFrame.getContentPane().add(sellGetOutOfJailCard);
        boardFrame.getContentPane().add(sellGetOutOfJailCardButton);
        boardFrame.getContentPane().add(bottomLeft, -1);
        boardFrame.getContentPane().add(topLeft, -1);
        boardFrame.getContentPane().add(left_1, -1);
        boardFrame.getContentPane().add(left_2, -1);
        boardFrame.getContentPane().add(left_3, -1);
        boardFrame.getContentPane().add(left_4, -1);
        boardFrame.getContentPane().add(left_5, -1);
        boardFrame.getContentPane().add(left_6, -1);
        boardFrame.getContentPane().add(left_7, -1);
        boardFrame.getContentPane().add(left_8, -1);
        boardFrame.getContentPane().add(left_9, -1);
        boardFrame.getContentPane().add(top_1, -1);
        boardFrame.getContentPane().add(top_2, -1);
        boardFrame.getContentPane().add(top_3, -1);
        boardFrame.getContentPane().add(top_4, -1);
        boardFrame.getContentPane().add(top_5, -1);
        boardFrame.getContentPane().add(top_6, -1);
        boardFrame.getContentPane().add(top_7, -1);
        boardFrame.getContentPane().add(top_8, -1);
        boardFrame.getContentPane().add(top_9, -1);
        boardFrame.getContentPane().add(topRight, -1);
        boardFrame.getContentPane().add(right_1, -1);
        boardFrame.getContentPane().add(right_2, -1);
        boardFrame.getContentPane().add(right_3, -1);
        boardFrame.getContentPane().add(right_4, -1);
        boardFrame.getContentPane().add(right_5, -1);
        boardFrame.getContentPane().add(right_6, -1);
        boardFrame.getContentPane().add(right_7, -1);
        boardFrame.getContentPane().add(right_8, -1);
        boardFrame.getContentPane().add(right_9, -1);
        boardFrame.getContentPane().add(bottom_1, -1);
        boardFrame.getContentPane().add(bottom_2, -1);
        boardFrame.getContentPane().add(bottom_3, -1);
        boardFrame.getContentPane().add(bottom_4, -1);
        boardFrame.getContentPane().add(bottom_5, -1);
        boardFrame.getContentPane().add(bottom_6, -1);
        boardFrame.getContentPane().add(bottom_7, -1);
        boardFrame.getContentPane().add(bottom_8, -1);
        boardFrame.getContentPane().add(bottom_9, -1);
        boardFrame.getContentPane().add(bottomRight, -1);
        boardFrame.getContentPane().add(PopUp, 2);
        boardFrame.getContentPane().add(Logo, -1);
        boardFrame.getContentPane().add(Opportunity, -1);
        boardFrame.getContentPane().add(LuckButton, -1);
        boardFrame.getContentPane().add(gameLog);
        boardFrame.getContentPane().add(gameConsole);
        boardFrame.getContentPane().add(useGetOutOfJailCard);
        boardFrame.getContentPane().add(dontUseGetOutOfJailCard);
        boardFrame.getContentPane().add(buyProperty);
        boardFrame.getContentPane().add(dontBuyProperty);
        boardFrame.getContentPane().add(payRent);
        boardFrame.getContentPane().add(payArrears);
        boardFrame.getContentPane().add(retireFromGame);
        boardFrame.getContentPane().add(yesButton);
        boardFrame.getContentPane().add(noButton);
        boardFrame.getContentPane().add(restartGame);
        boardFrame.getContentPane().add(buyOwnedProperty);
        boardFrame.getContentPane().add(ownedProperties);
        boardFrame.getContentPane().add(propertyOwner);
        boardFrame.getContentPane().add(ownedPropertyValue);
        boardFrame.getContentPane().add(buyOwnedPropertyButton);
        boardFrame.getContentPane().add(buyUnwantedPropertyButton);
        boardFrame.getContentPane().add(priceOfUnwantedProperty);
        boardFrame.getContentPane().add(buyUnwantedProperty);
        boardFrame.getContentPane().add(Opportunity);
        boardFrame.getContentPane().add(mortgageManagement);
        boardFrame.getContentPane().add(mortgageComboBox);
        boardFrame.getContentPane().add(takeLoan);
        boardFrame.getContentPane().add(payLoan);
        boardFrame.getContentPane().add(sellProperty);
        boardFrame.getContentPane().add(sellPropertyComboBox);
        boardFrame.getContentPane().add(buyer);
        boardFrame.getContentPane().add(sellingPrice);
        boardFrame.getContentPane().add(sellPropertyButton);
        boardFrame.getContentPane().add(addHouseButton);
        boardFrame.getContentPane().add(addHotelButton);
        boardFrame.getContentPane().add(buyBuilding);
        boardFrame.getContentPane().add(addBuildingTo);
        boardFrame.getContentPane().add(buildingLabel0, 2);
        boardFrame.getContentPane().add(buildingLabel1, 2);
        boardFrame.getContentPane().add(buildingLabel2, 2);
        boardFrame.getContentPane().add(buildingLabel3, 2);
        boardFrame.getContentPane().add(buildingLabel4, 2);
        boardFrame.getContentPane().add(buildingLabel5, 2);
        boardFrame.getContentPane().add(buildingLabel6, 2);
        boardFrame.getContentPane().add(buildingLabel7, 2);
        boardFrame.getContentPane().add(buildingLabel8, 2);
        boardFrame.getContentPane().add(buildingLabel9, 2);
        boardFrame.getContentPane().add(buildingLabel10, 2);
        boardFrame.getContentPane().add(buildingLabel11, 2);
        boardFrame.getContentPane().add(buildingLabel12, 2);
        boardFrame.getContentPane().add(buildingLabel13, 2);
        boardFrame.getContentPane().add(buildingLabel14, 2);
        boardFrame.getContentPane().add(buildingLabel15, 2);
        boardFrame.getContentPane().add(buildingLabel16, 2);
        boardFrame.getContentPane().add(buildingLabel17, 2);
        boardFrame.getContentPane().add(buildingLabel18, 2);
        boardFrame.getContentPane().add(buildingLabel19, 2);
        boardFrame.getContentPane().add(buildingLabel20, 2);
        boardFrame.getContentPane().add(buildingLabel21, 2);
        boardFrame.getContentPane().add(showInstruction);
        boardFrame.getContentPane().add(BackButton);
        boardFrame.getContentPane().add(FinishButton);
        boardFrame.getContentPane().add(gamePrompt);
        boardFrame.getContentPane().add(pay50toGetOutOfJail);

        cardBuyers = new JComboBox<String>();
        cardBuyers.setBounds(frameHeight + 205, (int) (frameHeight / 2 + 210), 140, 20);
        cardPrice = new JTextField();
        cardPrice.setBounds(frameHeight + 350, (int) (frameHeight / 2 + 210), 45, 20);
        sellGetOutOfJailCardButton = new JButton("sell");
        sellGetOutOfJailCardButton.setBounds(frameHeight + 400, (int) (frameHeight / 2 + 210), 60, 20);
        playerIndex = 0;

        // dice roll action Listener
        rollTheDice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                gamePrompt.setText("");
                randomDice1 = random.nextInt(6) + 1;
                randomDice2 = random.nextInt(6) + 1;
                System.out.println(randomDice1);
                System.out.println(randomDice2);
                retireFromGame.setVisible(false);
                buyProperty.setEnabled(true);
                buyUnwantedProperty.setVisible(false);
                buyUnwantedPropertyButton.setVisible(false);
                priceOfUnwantedProperty.setVisible(false);
                switch (randomDice1) {
                    case 1:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice1.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 2:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice2.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 3:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice3.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 4:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice4.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 5:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice5.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 6:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
                            dice1.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                }
                switch (randomDice2) {
                    case 1:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice1.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 2:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice2.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 3:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice3.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 4:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice4.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 5:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice5.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                    case 6:
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
                            dice2.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        break;
                }
                System.out.println(extraRollNeeded);
                if (!extraRollNeeded) {
                    if (randomDice1 == randomDice2) {
                        doubleCounter++;
                        gotDouble = true;
                    } else {
                        gotDouble = false;
                    }
                    if (doubleCounter < 3) {
                        players.get(playerIndex).setPositionOnGameBoard(randomDice1 + randomDice2);
                        finishTurn.setEnabled(false);
                    }
                    // three doubles - player goes to the jail
                    if (doubleCounter == 3
                            || players.get(playerIndex).getPositionOnGameBoard() == 30) {
                        // no get out of jail card
                        if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                            finishTurn.setEnabled(true);
                            rollTheDice.setEnabled(false);
                            players.get(playerIndex).setInJail(true);
                            if (doubleCounter < 3) {
                                log = players.get(playerIndex).getPlayerName() + " went to Jail" + "\n";
                                logText.append(log);
                            } else {
                                log = players.get(playerIndex).getPlayerName() + " went to Jail for rolling 3 doubles " + "\n";
                                logText.append(log);
                            }
                            players.get(playerIndex).setPositionOnGameBoard(10 - players.get(playerIndex).getPositionOnGameBoard());
                            adjustPlayerPosition();
                            System.out.println(players.get(playerIndex).getPlayerName() + " " + players.get(playerIndex).getPositionOnGameBoard() + " in Jail: " + players.get(playerIndex).isInJail());
                            doubleCounter = 0;
                        } else {
                            gamePrompt.setText("Do you want to use your get out of jail card?");
                            useGetOutOfJailCard.setVisible(true);
                            dontUseGetOutOfJailCard.setVisible(true);
                            rollTheDice.setEnabled(false);
                            finishTurn.setEnabled(false);
                        }
                    } else {
                        adjustPlayerPosition();
                        System.out.println(players.get(playerIndex).getPlayerName() + " " + players.get(playerIndex).getPositionOnGameBoard());
                        buyOrRent();
                    }
                } else {
                    if (players.get(playerIndex).isInJail()) {
                        if (!(randomDice1 == randomDice2)) {
                            if (players.get(playerIndex).getTurnsInJail() == 1) {
                                log = players.get(playerIndex).getPlayerName() + " has his/her balance deducted by £50 and got out of Jail" + "\n";
                                logText.append(log);
                                players.get(playerIndex).setcash(-50);
                                players.get(playerIndex).setInJail(false);
                                players.get(playerIndex).setTurnsInJail(0);
                                useGetOutOfJailCard.setVisible(false);
                                pay50toGetOutOfJail.setVisible(false);
                                gamePrompt.setText("");
                                balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                            } else {
                                players.get(playerIndex).setTurnsInJail(1);
                                useGetOutOfJailCard.setVisible(false);
                                pay50toGetOutOfJail.setVisible(false);
                                gamePrompt.setText("");
                            }
                            extraRollNeeded = false;
                            rollTheDice.setEnabled(false);
                            finishTurn.setEnabled(true);
                        } else {
                            players.get(playerIndex).setInJail(false);
                            players.get(playerIndex).setTurnsInJail(0);
                            useGetOutOfJailCard.setVisible(false);
                            pay50toGetOutOfJail.setVisible(false);
                            log = players.get(playerIndex).getPlayerName() + " rolled double and got out of Jail" + "\n";
                            logText.append(log);
                            gamePrompt.setText("");
                            extraRollNeeded = false;
                            balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                            doubleCounter = 0;
                            if (getNumberOfHouses() > 0 || getNumberOfHotels() > 0) {
                                generateAddBuildingComboBox();
                            }
                        }
                    } else {
                        rentCalculated = true;
                        rollTheDice.setEnabled(false);
                        if ((players.get(playerIndex).getPositionOnGameBoard() == 12 && entities
                                .getEntities().get(28).getOwner() != null)
                                || (players.get(playerIndex)
                                        .getPositionOnGameBoard() == 28 && entities
                                        .getEntities().get(12).getOwner() != null)
                                || (sentByChanceCard && players
                                        .get(playerIndex)
                                        .getPositionOnGameBoard() == 12)
                                || (sentByChanceCard && players
                                        .get(playerIndex)
                                        .getPositionOnGameBoard() == 28)) {
                            rentValue = 10 * (randomDice1 + randomDice2);
                        } else if (players.get(playerIndex)
                                .getPositionOnGameBoard() == 12
                                && entities.getEntities().get(28).getOwner() == null
                                || players.get(playerIndex)
                                        .getPositionOnGameBoard() == 28
                                && entities.getEntities().get(12).getOwner() == null) {
                            rentValue = 4 * (randomDice1 + randomDice2);
                        }
                        if (rentCalculated) {
                            if (rentValue > players.get(playerIndex)
                                    .getcash()) {
                                gamePrompt.setText("You need money to pay the rent. Sell property, take loan or retire from game");
                                retireFromGame.setVisible(true);
                            } else {
                                payRent.setVisible(true);
                                retireFromGame.setVisible(false);
                            }
                        }

                    }
                }
            }
        });

        //Pay Rent
        payRent.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                sentByChanceCard = false;
                rentCalculated = false;
                extraRollNeeded = false;
                ownerIndex = getPlayerIndex(entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getOwner());
                players.get(playerIndex).setcash(-rentValue);
                players.get(ownerIndex).setcash(rentValue);

                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);

                } else if (gotDouble && doubleCounter < 3) {
                    rollTheDice.setEnabled(true);

                }
                payRent.setVisible(false);
                log = players.get(playerIndex).getPlayerName() + " paid " + rentValue + " rent to " + players.get(
                        getPlayerIndex(entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard())
                                .getOwner())).getPlayerName() + "\n";
                logText.append(log);
                balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                balanceLabels.get(ownerIndex).setText("£" + players.get(ownerIndex).getcash());
                gamePrompt.setText("");
                System.out.println("number of houses: " + entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getNumberOfHouses());
            }
        });

        //Pay 50 £ To Exit Jail Button
        pay50toGetOutOfJail.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                players.get(playerIndex).setcash(-50);
                ParkingMoney = ParkingMoney + 50.0;
                pay50toGetOutOfJail.setVisible(false);
                useGetOutOfJailCard.setVisible(false);
                rollTheDice.setEnabled(true);
                players.get(playerIndex).setInJail(false);
                players.get(playerIndex).setTurnsInJail(0);
                pay50toGetOutOfJail.setVisible(false);
                log = players.get(playerIndex).getPlayerName() + " paid £50 to get out of Jail , This Money Added to Free Parking Cash" + "\n";
                logText.append(log);
                gamePrompt.setText("");
                extraRollNeeded = false;
                balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
            }
        });

        //Use GetOutOfJailCard
        useGetOutOfJailCard.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (!sentByChanceCard) {
                    if (!players.get(playerIndex).isInJail()
                            && players.get(playerIndex)
                                    .getPositionOnGameBoard() == 30) {
                        if (doubleCounter == 3 || !gotDouble) {
                            finishTurn.setEnabled(true);
                            log = players.get(playerIndex).getPlayerName()
                                    + " used his/her get out of Jail card to avoid going to Jail"
                                    + "\n";
                            logText.append(log);
                            adjustPlayerPosition();
                        } else if (gotDouble) {
                            rollTheDice.setEnabled(true);
                        }

                    } else if (!players.get(playerIndex).isInJail()
                            && players.get(playerIndex)
                                    .getPositionOnGameBoard() != 30) {
                        if (doubleCounter == 3 || !gotDouble) {
                            finishTurn.setEnabled(true);
                        }
                        adjustPlayerPosition();
                        log = players.get(playerIndex).getPlayerName()
                                + " used his/her get out of Jail card to avoid going to Jail"
                                + "\n";
                        logText.append(log);
                    } else {
                        rollTheDice.setEnabled(true);
                        players.get(playerIndex).setInJail(false);
                        players.get(playerIndex).setTurnsInJail(0);
                        pay50toGetOutOfJail.setVisible(false);
                        log = players.get(playerIndex).getPlayerName()
                                + " used his/her get out of Jail card to get out of Jail"
                                + "\n";
                        logText.append(log);
                        extraRollNeeded = false;
                    }
                    buyOrRent();
                } else {
                    log = players.get(playerIndex).getPlayerName()
                            + " used his/her get out of Jail card to avoid going to Jail"
                            + "\n";
                    logText.append(log);
                    sentByChanceCard = false;
                    if (!gotDouble) {
                        finishTurn.setEnabled(true);
                    } else {
                        rollTheDice.setEnabled(true);
                    }
                }
                useGetOutOfJailCard.setVisible(false);
                dontUseGetOutOfJailCard.setVisible(false);
                if (players.get(playerIndex).getOutOfJailCards().get(0) instanceof ChanceCard) {
                    players.get(playerIndex).getOutOfJailCards().remove(0);
                    deck.returnOutOfJailCardChance();
                } else {
                    players.get(playerIndex).getOutOfJailCards().remove(0);
                    deck.returnOutOfJailCardCommunity();
                }

                gamePrompt.setText("");
                getOutOfJailLabels.get(playerIndex).setText(
                        "get out of jail cards : "
                        + players.get(playerIndex)
                                .getNumberOfGetOutOfJailCards());
                if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                    getOutOfJailLabels.get(playerIndex).setVisible(false);
                }
            }
        });

        //Dont Use GetOiut Of JailCard
        dontUseGetOutOfJailCard.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                players.get(playerIndex).setPositionOnGameBoard(
                        10 - players.get(playerIndex).getPositionOnGameBoard());
                players.get(playerIndex).setInJail(true);
                adjustPlayerPosition();
                if (doubleCounter == 3) {
                    log = players.get(playerIndex).getPlayerName()
                            + " went to Jail for rolling 3 doubles " + "\n";
                    logText.append(log);
                } else {
                    log = players.get(playerIndex).getPlayerName()
                            + " went to Jail" + "\n";
                    logText.append(log);
                }
                finishTurn.setEnabled(true);
                gamePrompt.setText("");
                useGetOutOfJailCard.setVisible(false);
                dontUseGetOutOfJailCard.setVisible(false);
            }
        });

        //Finosh Turn Buttn
        finishTurn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Game On Check Game Is Finished Or Not
                if (gameOn(gameInitializer.ModeIsClassic)) {
                    // If Player Get Chance Card Clear The Buttond
                    if (chanceCardPicked) {
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/chance.jpg"));
                            LuckButton.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        chanceCardPicked = false;
                    }
                    // If Player Get community Card Clear The Buttond
                    if (communityCardPicked) {
                        try {
                            Image img = ImageIO.read(getClass().getResource("resources/chest.jpg"));
                            Opportunity.setIcon(new ImageIcon(img));
                        } catch (IOException ex) {
                        }
                        communityCardPicked = false;
                    }
                    // Find Player Was must Play // Find Player Must play this turn
                    do {
                        playersPanes.get(playerIndex).setBorder(BorderFactory.createLineBorder(Color.black, 2));
                        playersPanes.get(playerIndex).setBackground(new Color(131, 248, 244));
                        playersPanes.get(playerIndex).setOpaque(true);
                        playerIndex = (playerIndex + 1) % players.size();
                        playersPanes.get(playerIndex).setBorder(BorderFactory.createLineBorder(Color.green, 2));
                        playersPanes.get(playerIndex).setBackground(Color.green);
                        playersPanes.get(playerIndex).setOpaque(true);
                    } while (players.get(playerIndex).isLooser());

                    if (players.get(playerIndex).isInJail()
                            && players.get(playerIndex).getNumberOfGetOutOfJailCards() > 0) {
                        gamePrompt.setText("Use the card, pay £50 or roll the dice to get out of Jail");
                        useGetOutOfJailCard.setVisible(true);
                        pay50toGetOutOfJail.setVisible(true);
                        rollTheDice.setEnabled(true);
                        extraRollNeeded = true;
                    } else if (players.get(playerIndex).isInJail()) {
                        gamePrompt.setText("You need to pay £50 or roll double to get out of Jail");
                        extraRollNeeded = true;
                        rollTheDice.setEnabled(true);
                        pay50toGetOutOfJail.setVisible(true);
                    } else {
                        rollTheDice.setEnabled(true);
                        gamePrompt.setText("");
                    }
                    finishTurn.setEnabled(false);
                    doubleCounter = 0;
                    buyProperty.setEnabled(true);
                    buyUnwantedProperty.setVisible(false);
                    buyUnwantedPropertyButton.setVisible(false);
                    priceOfUnwantedProperty.setVisible(false);
                    if (players.get(playerIndex).getOwnedProperties().size() > 0) {
                        generateMortgageComboBox();
                    } else {
                        mortgageManagement.setVisible(false);
                        mortgageComboBox.setVisible(false);
                        takeLoan.setVisible(false);
                        payLoan.setVisible(false);
                        sellProperty.setVisible(false);
                        sellPropertyComboBox.setVisible(false);
                        buyer.setVisible(false);
                        sellingPrice.setVisible(false);
                        sellPropertyButton.setVisible(false);
                    }
                    if (getNumberOfHouses() > 0 || getNumberOfHotels() > 0
                            && !players.get(playerIndex).isInJail()) {
                        generateAddBuildingComboBox();
                    }
                    houseOrHotelBought = false;
                    if (players.get(playerIndex).getNumberOfGetOutOfJailCards() > 0) {
                        generateSellGetOutOfJailCardComboBox();
                    } else {
                        sellGetOutOfJailCard.setVisible(false);
                        cardBuyers.setVisible(false);
                        cardPrice.setVisible(false);
                        sellGetOutOfJailCardButton.setVisible(false);
                    }
                    generateBuyOwnedPropertyComboBox();
                    if (!gameInitializer.ModeIsClassic) {
                        Instant end = Instant.now();
                        Duration timeElapsed = Duration.between(start, end);

                        log = " Passed Time : " + timeElapsed.getSeconds() / 60 + "minutes and" + timeElapsed.getSeconds() % 60 + " seconds \n";
                        logText.append(log);
                    }
                } else {
                    //Game Finished And Must Be Show Winner Of Game And Visible End Of Game
                    finishTurn.setEnabled(false);
                    finishTurn.setVisible(false);
                    rollTheDice.setEnabled(false);
                    rollTheDice.setVisible(false);
                    int winnerIndex = 0;
                    for (int i = 0; i < players.size(); i++) {
                        if (!players.get(i).isLooser()) {
                            winnerIndex = i;
                        }
                    }
                    log = players.get(winnerIndex).getPlayerName()
                            + " won the game. " + "\n";
                    logText.append(log);
                    balanceLabels.get(winnerIndex).setText("WINNER !!!");
                    restartGame.setVisible(true);

                }
                //play AI
                if (!players.get(playerIndex).getIsHuman()) {
                    playersPanes.get(playerIndex).setBackground(new Color(131, 248, 244));
                    playersPanes.get(playerIndex).setOpaque(true);
                    PlayAI();
                }
            }
        });

        //But Property Button
        buyProperty.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                // setting new owner of a property
                entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .setOwner(players.get(playerIndex));

                // adding property to player's ArrayList of properties
                players.get(playerIndex)
                        .getOwnedProperties()
                        .add(entities.getEntities().get(
                                players.get(playerIndex)
                                        .getPositionOnGameBoard()));

                // deducting the value of the property from player's balance
                players.get(playerIndex).setcash(
                        -entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getCost());

                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                } else if (gotDouble && doubleCounter < 3) {
                    rollTheDice.setEnabled(true);
                }
                buyProperty.setVisible(false);
                dontBuyProperty.setVisible(false);
                log = players.get(playerIndex).getPlayerName()
                        + " has just bought "
                        + entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getName()
                        + "(worth £"
                        + entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getCost()
                        + ")\n";
                logText.append(log);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());

                generateMortgageComboBox();
                if (!houseOrHotelBought
                        && (getNumberOfHotels() > 0 || getNumberOfHouses() > 0)
                        && !players.get(playerIndex).isInJail()) {
                    generateAddBuildingComboBox();
                }
            }
        });

        //Dont Buy Property Button
        dontBuyProperty.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {

                buyProperty.setVisible(false);
                dontBuyProperty.setVisible(false);
                log = players.get(playerIndex).getPlayerName()
                        + " did not buy " + entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getName()
                        + "\n";
                logText.append(log);
                buyUnwantedPropertyModel = new DefaultComboBoxModel<String>();
                for (Player player : players) {
                    if (!player.getPlayerName().equals(
                            players.get(playerIndex).getPlayerName())
                            && !player.isLooser()) {
                        buyUnwantedPropertyModel.addElement(player.getPlayerName());
                    }
                }
                buyUnwantedProperty.setModel(buyUnwantedPropertyModel);
                gamePrompt.setText("Please pick a player (if interested) and enter the amount to be paid for the property");
                buyUnwantedProperty.setVisible(true);
                buyUnwantedPropertyButton.setVisible(true);
                priceOfUnwantedProperty.setVisible(true);
                if (gotDouble && doubleCounter < 3) {
                    rollTheDice.setEnabled(true);
                } else {
                    finishTurn.setEnabled(true);
                }
            }
        });

        //Price Of UnWanted Property
        priceOfUnwantedProperty.getDocument().addDocumentListener(
                new DocumentListener() {
            @Override
            public void changedUpdate(DocumentEvent arg0) {
                checkValue();
            }

            @Override
            public void insertUpdate(DocumentEvent arg0) {
                checkValue();
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {
                checkValue();
            }

            public void checkValue() {
                String value = priceOfUnwantedProperty.getText();
                int tempQty = 0;
                try {
                    tempQty = Integer.parseInt(value);
                } catch (Exception e) {

                }
                if (tempQty > 0
                        && tempQty <= players.get(
                                getPlayerIndex(String
                                        .valueOf(buyUnwantedProperty
                                                .getSelectedItem())))
                                .getcash()) {
                    buyUnwantedPropertyButton.setEnabled(true);
                    valueOfUnwantedProperty = tempQty;
                } else {
                    buyUnwantedPropertyButton.setEnabled(false);
                }
            }
        });

        // buyUnwantedPropertyButton
        buyUnwantedPropertyButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                buyUnwantedProperty.setVisible(false);
                buyUnwantedPropertyButton.setVisible(false);
                priceOfUnwantedProperty.setVisible(false);
                gamePrompt.setText("");
                ownerIndex = getPlayerIndex(String.valueOf(buyUnwantedProperty
                        .getSelectedItem()));
                log = players.get(ownerIndex).getPlayerName()
                        + " has just bought "
                        + entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getName()
                        + "(for £" + valueOfUnwantedProperty + ")\n";
                logText.append(log);
                players.get(ownerIndex).setcash(-valueOfUnwantedProperty);
                balanceLabels.get(ownerIndex).setText("£" + players.get(ownerIndex).getcash());

                entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard()).setOwner(players.get(ownerIndex));

                players.get(ownerIndex)
                        .getOwnedProperties()
                        .add(entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()));

                priceOfUnwantedProperty.setText("");
                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                }
                generateBuyOwnedPropertyComboBox();
            }
        });

        mortgageComboBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                takeLoan.setEnabled(false);
                payLoan.setEnabled(false);
                String comboSelection = String.valueOf(mortgageComboBox
                        .getSelectedItem());
                for (Entity entity : players.get(playerIndex)
                        .getOwnedProperties()) {
                    if (entity.getName().equals(comboSelection)
                            && entity.isMortgaged()
                            && players.get(playerIndex).getcash() >= (entity
                            .getCost() * 0.6)) {
                        payLoan.setEnabled(true);
                        takeLoan.setEnabled(false);
                    } else if (entity.getName().equals(comboSelection)
                            && !entity.isMortgaged()) {
                        payLoan.setEnabled(false);
                        takeLoan.setEnabled(true);
                    }
                }
                sellPropertyComboBox.setSelectedItem(null);
            }
        });

        takeLoan.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                int position = 0;
                boolean mortgaged = true;
                String comboSelection = String.valueOf(mortgageComboBox
                        .getSelectedItem());
                for (Entity anEntity : entities.getEntities()) {
                    if (anEntity.getName().equals(comboSelection)) {
                        anEntity.setMortgaged(true);
                        position = anEntity.getPosition();
                    }
                }
                for (Entity entity : players.get(playerIndex)
                        .getOwnedProperties()) {
                    if (entity.getName().equals(comboSelection)) {
                        entity.setMortgaged(true);
                        players.get(playerIndex).setcash(
                                entity.getCost() * 0.5);
                        log = "  /> " + players.get(playerIndex).getPlayerName()
                                + " entity: " + entity.getName()
                                + " is now mortgaged" + "\n";
                        logText.append(log);
                        balanceLabels.get(playerIndex).setText(
                                "£" + players.get(playerIndex).getcash());
                        mortgageComboBox.setSelectedItem(null);
                        payLoan.setEnabled(false);
                        takeLoan.setEnabled(false);
                        if (entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard())
                                .canBePurchased()
                                && entities
                                        .getEntities()
                                        .get(players.get(playerIndex)
                                                .getPositionOnGameBoard())
                                        .getOwner() == null) {
                            buyProperty.setVisible(false);
                            buyProperty.setEnabled(true);
                            gamePrompt.setText("");
                            dontBuyProperty.setVisible(false);
                            buyOrRent();
                        }
                    }
                }
                if (rentCalculated) {
                    if (rentValue > players.get(playerIndex).getcash()) {
                        gamePrompt
                                .setText("You need money to pay the rent. Sell property, take loan or retire from game");
                    } else {
                        payRent.setVisible(true);
                        retireFromGame.setVisible(false);
                        gamePrompt.setText("");
                    }
                }
                if (paymentDue) {
                    if (paymentDueAmount > players.get(playerIndex)
                            .getcash()) {
                        gamePrompt
                                .setText("you need to pay arrears. Sell or mortgage property or retire from game");
                    } else {
                        payArrears.setVisible(true);
                        retireFromGame.setVisible(false);
                        gamePrompt.setText("");
                    }
                }
                addBuildingTo.setSelectedItem(null);
                if (addHouseButton.isEnabled()) {
                    addHouseButton.setEnabled(false);
                }
                if (addHotelButton.isEnabled()) {
                    addHotelButton.setEnabled(false);
                }
                applyOrRemoveMortgagedLabel(position, mortgaged);
            }

        });

        payLoan.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                int position = 0;
                boolean mortgaged = false;
                String comboSelection = String.valueOf(mortgageComboBox.getSelectedItem());
                for (Entity anEntity : entities.getEntities()) {
                    if (anEntity.getName().equals(comboSelection)) {
                        anEntity.setMortgaged(false);
                        position = anEntity.getPosition();
                    }
                }
                for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
                    if (entity.getName().equals(comboSelection)) {
                        entity.setMortgaged(false);
                        players.get(playerIndex).setcash(-(entity.getCost() * 0.5));
                        log = "  /> " + players.get(playerIndex).getPlayerName()
                                + " entity: " + entity.getName()
                                + "\'s mortgage is now paid" + "\n";
                        logText.append(log);
                        balanceLabels.get(playerIndex).setText(
                                "£" + players.get(playerIndex).getcash());
                        mortgageComboBox.setSelectedItem(null);
                        payLoan.setEnabled(false);
                        takeLoan.setEnabled(false);
                    }
                }
                applyOrRemoveMortgagedLabel(position, mortgaged);
            }

        });

        sellPropertyComboBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String combo = String.valueOf(sellPropertyComboBox
                        .getSelectedItem());
                boolean isMortgaged = false;
                for (Entity entity : entities.getEntities()) {
                    if (entity.getName().equals(combo)) {
                        if (entity.isMortgaged()) {
                            isMortgaged = true;
                        }
                    }
                }
                buyer.setVisible(false);
                sellPropertyButton.setEnabled(true);
                sellingPrice.setVisible(false);

                //sellingPrice.setEnabled(true);
                // sellingPrice.setText("");
            }
        });

        retireFromGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                gamePrompt.setText("Are you sure you want to retire from the game?");
                yesButton.setVisible(true);
                noButton.setVisible(true);
                retireFromGame.setVisible(false);
            }
        });

        noButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                yesButton.setVisible(false);
                noButton.setVisible(false);
                retireFromGame.setVisible(false);
                gamePrompt.setVisible(false);
                if (paymentDue) {
                    gamePrompt
                            .setText("you need to pay arrears. Sell or mortgage property or retire from game");
                    gamePrompt.setVisible(true);
                } else if (rentCalculated) {
                    gamePrompt
                            .setText("You need money to pay the rent. Sell property, take loan or retire from game");
                    gamePrompt.setVisible(true);
                }
            }

        });

        yesButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                log = players.get(playerIndex).getPlayerName()
                        + " retired from the game. " + "\n";
                logText.append(log);
                int numberOfHousesToBeRestored = 0;
                int numberOfHotelsToBeRestored = 0;
                double balanceToBeTransferred = 0;
                yesButton.setVisible(false);
                noButton.setVisible(false);
                retireFromGame.setVisible(false);
                mortgageManagement.setVisible(false);
                mortgageComboBox.setVisible(false);
                takeLoan.setVisible(false);
                payLoan.setVisible(false);
                sellProperty.setVisible(false);
                sellPropertyComboBox.setVisible(false);
                buyer.setVisible(false);
                sellingPrice.setVisible(false);
                sellPropertyButton.setVisible(false);
                sellGetOutOfJailCard.setVisible(false);
                cardBuyers.setVisible(false);
                cardPrice.setVisible(false);
                sellGetOutOfJailCardButton.setVisible(false);
                buyOwnedProperty.setVisible(false);
                ownedProperties.setVisible(false);
                propertyOwner.setVisible(false);
                ownedPropertyValue.setVisible(false);
                buyOwnedPropertyButton.setVisible(false);
                hideAddBuildingComponents();
                if (paymentDue) {
                    System.out.println("hotels: " + getNumberOfHotels());
                    System.out.println("houses: " + getNumberOfHouses());
                    paymentDue = false;
                    if (players.get(playerIndex).getOwnedProperties().size() > 0) {
                        for (Entity entity : entities.getEntities()) {
                            if (entity.getOwner() != null
                                    && entity.getOwner().getPlayerName().equals(players.get(playerIndex).getPlayerName())) {
                                entity.setOwner(null);
                            }
                        }
                        for (Entity property : players.get(playerIndex)
                                .getOwnedProperties()) {
                            if (property.getNumberOfHotels() == 1) {
                                numberOfHotelsToBeRestored++;
                            }
                            if (property.getNumberOfHouses() > 0) {
                                numberOfHousesToBeRestored += property
                                        .getNumberOfHouses();
                            }
                            if (property.getBuildingIndex() != -1) {
                                buildingLabels.get(property.getBuildingIndex())
                                        .setIcon(null);
                            }
                        }
                        setNumberOfHotels(numberOfHotelsToBeRestored);
                        setNumberOfHouses(numberOfHousesToBeRestored);
                        System.out.println("hotels: " + getNumberOfHotels());
                        System.out.println("houses: " + getNumberOfHouses());
                        while (players.get(playerIndex)
                                .getNumberOfGetOutOfJailCards() != 0) {
                            if (players.get(playerIndex).getOutOfJailCards()
                                    .get(0) instanceof ChanceCard) {
                                players.get(playerIndex).getOutOfJailCards()
                                        .remove(0);
                                deck.returnOutOfJailCardChance();
                            } else {
                                players.get(playerIndex).getOutOfJailCards()
                                        .remove(0);
                                deck.returnOutOfJailCardCommunity();
                            }
                        }
                    }
                } else if (rentCalculated) {
                    rentCalculated = false;
                    if (players.get(playerIndex).getcash() > 0) {
                        balanceToBeTransferred = players.get(playerIndex)
                                .getcash();
                    }
                    if (players.get(playerIndex).getOwnedProperties().size() > 0) {
                        for (Entity entity : entities.getEntities()) {
                            if (entity.getOwner() != null
                                    && entity.getOwner().getPlayerName().equals(players.get(playerIndex).getPlayerName())) {
                                entity.setOwner(players.get(ownerIndex));
                            }
                        }
                        for (int i = 0; i < players.get(playerIndex)
                                .getOwnedProperties().size(); i++) {
                            players.get(playerIndex).getOwnedProperties()
                                    .get(i).setOwner(players.get(ownerIndex));
                            players.get(ownerIndex)
                                    .getOwnedProperties()
                                    .add(players.get(playerIndex)
                                            .getOwnedProperties().get(i));
                            if (players.get(playerIndex).getOwnedProperties()
                                    .get(i).isMortgaged()) {
                                balanceToBeTransferred -= (players
                                        .get(playerIndex).getOwnedProperties()
                                        .get(i).getCost() * 0.1);
                            }
                        }
                        for (int i = players.get(playerIndex)
                                .getOwnedProperties().size(); i > 0; i--) {
                            players.get(playerIndex).getOwnedProperties()
                                    .remove(i - 1);
                        }
                    }
                    players.get(ownerIndex).setcash(balanceToBeTransferred);
                    while (players.get(playerIndex).getNumberOfGetOutOfJailCards() != 0) {
                        players.get(ownerIndex).getOutOfJailCards().add(players.get(playerIndex).getOutOfJailCards().remove(0));
                        getOutOfJailLabels.get(ownerIndex).setVisible(true);
                        getOutOfJailLabels.get(ownerIndex).setText(
                                "get out of jail cards : "
                                + players
                                        .get(ownerIndex)
                                        .getNumberOfGetOutOfJailCards());
                    }
                    log = players.get(ownerIndex).getPlayerName()
                            + " acquired all "
                            + players.get(playerIndex).getPlayerName()
                            + "'s properties" + "\n";
                    logText.append(log);
                    balanceLabels.get(ownerIndex).setText(
                            "£" + players.get(ownerIndex).getcash());
                }
                players.get(playerIndex).setisLooser(true);
                balanceLabels.get(playerIndex).setText("retired from game");
                getOutOfJailLabels.get(playerIndex).setVisible(false);
                finishTurn.setEnabled(true);
                gamePrompt.setText("");
                playerIndicators.get(playerIndex).setVisible(false);
            }

        });

        sellingPrice.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void changedUpdate(DocumentEvent arg0) {
                checkValue();
            }

            @Override
            public void insertUpdate(DocumentEvent arg0) {
                checkValue();
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {
                sellPropertyButton.setEnabled(false);
                checkValue();
            }

            public void checkValue() {
                String value = sellingPrice.getText();
                int tempQty = 0;
                try {
                    tempQty = Integer.parseInt(value);
                } catch (Exception e) {
                }
                if (tempQty > 0) {
                    if (entities
                            .getEntities()
                            .get(getEntityPosition(String
                                    .valueOf(sellPropertyComboBox
                                            .getSelectedItem()))).isMortgaged()
                            && tempQty >= (entities
                                    .getEntities()
                                    .get(getEntityPosition(String
                                            .valueOf(sellPropertyComboBox
                                                    .getSelectedItem())))
                                    .getCost() * 0.1)) {
                        sellPropertyButton.setEnabled(true);
                        valueOfUnwantedProperty = tempQty;
                    } else if (!entities
                            .getEntities()
                            .get(getEntityPosition(String
                                    .valueOf(sellPropertyComboBox
                                            .getSelectedItem()))).isMortgaged()) {
                        sellPropertyButton.setEnabled(true);
                        valueOfUnwantedProperty = tempQty;
                    }
                } else {
                    sellPropertyButton.setEnabled(false);
                }
            }
        });

        sellPropertyButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                boolean isMortgaged = false;
                String entityName = String.valueOf(sellPropertyComboBox
                        .getSelectedItem());

                for (int i = 0; i < players.get(playerIndex)
                        .getOwnedProperties().size(); i++) {
                    if (players.get(playerIndex).getOwnedProperties().get(i)
                            .getName().equals(entityName)) {
                        players.get(playerIndex).getOwnedProperties().remove(i);
                        break;
                    }
                }

                int entityPosition = getEntityPosition(entityName);
                entities.getEntities().get(entityPosition)
                        .setOwner(null);

                if (entities.getEntities().get(entityPosition).isMortgaged()) {
                    isMortgaged = true;
                }

                log = players.get(playerIndex).getPlayerName()
                        + " has just sold "
                        + entities.getEntities().get(entityPosition).getName()
                        + " to Bank for £" + entities.getEntities().get(entityPosition).getCost() + ")\n";
                logText.append(log);
                if (isMortgaged) {
                    players.get(playerIndex).setcash(entities.getEntities().get(entityPosition).getCost() * 0.5);
                    entities.getEntities().get(entityPosition).setMortgaged(false);
                    applyOrRemoveMortgagedLabel(entityPosition, false);
                } else {
                    players.get(playerIndex).setcash(entities.getEntities().get(entityPosition).getCost());
                }

                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                if (players.get(playerIndex).getOwnedProperties().size() > 0) {
                    generateMortgageComboBox();
                } else {
                    mortgageManagement.setVisible(false);
                    mortgageComboBox.setVisible(false);
                    takeLoan.setVisible(false);
                    payLoan.setVisible(false);
                    takeLoan.setEnabled(false);
                    payLoan.setEnabled(false);
                    sellProperty.setVisible(false);
                    sellPropertyComboBox.setVisible(false);
                    sellPropertyComboBox.setSelectedItem(null);
                    buyer.setVisible(false);
                    buyer.setSelectedItem(null);
                    sellingPrice.setVisible(false);
                    sellingPrice.setText("");
                    sellPropertyButton.setVisible(false);
                    sellPropertyButton.setEnabled(false);
                }
                if (!houseOrHotelBought
                        && (getNumberOfHouses() > 0 || getNumberOfHotels() > 0)
                        && !players.get(playerIndex).isInJail()) {
                    generateAddBuildingComboBox();
                }
                if (rentCalculated) {
                    if (rentValue > players.get(playerIndex).getcash()) {
                        gamePrompt
                                .setText("You need money to pay the rent. Sell property, take loan or retire from game");
                    } else {
                        payRent.setVisible(true);
                        retireFromGame.setVisible(false);
                    }
                }
                if (paymentDue) {
                    if (paymentDueAmount > players.get(playerIndex)
                            .getcash()) {
                        gamePrompt
                                .setText("you need to pay arrears. Sell or mortgage property or retire from game");
                    } else {
                        payArrears.setVisible(true);
                        retireFromGame.setVisible(false);
                        gamePrompt.setText("");
                    }
                }
                generateBuyOwnedPropertyComboBox();
            }

        });

        addHouseButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                houseOrHotelBought = true;
                setNumberOfHouses(-1);
                double houseCost = 0;
                if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 5) {
                    houseCost = 50;
                } else if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 11) {
                    houseCost = 100;
                } else if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 17) {
                    houseCost = 150;
                } else {
                    houseCost = 200;
                }

                for (Entity entity : players.get(playerIndex)
                        .getOwnedProperties()) {
                    if (entity.getName().equals(
                            String.valueOf(addBuildingTo.getSelectedItem()))) {
                        entity.setNumberOfHouses(1);
                        break;
                    }
                }
                int numberOfHouses = players
                        .get(playerIndex)
                        .getOwnedProperties()
                        .get(getPlayersEntityPosition(String
                                .valueOf(addBuildingTo.getSelectedItem())))
                        .getNumberOfHouses();
                log = "  /> "
                        + players.get(playerIndex).getPlayerName()
                        + " has just bought a house at "
                        + entities
                                .getEntities()
                                .get(getEntityPosition(String
                                        .valueOf(addBuildingTo
                                                .getSelectedItem()))).getName()
                        + "\n";
                logText.append(log);
                players.get(playerIndex).setcash(-houseCost);
                hideAddBuildingComponents();
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                displayProperBuildingLabel(
                        players.get(playerIndex)
                                .getOwnedProperties()
                                .get(getPlayersEntityPosition(String
                                        .valueOf(addBuildingTo
                                                .getSelectedItem())))
                                .getBuildingIndex(), numberOfHouses);
                generateMortgageComboBox();
            }

        });

        addHotelButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                setNumberOfHotels(-1);
                setNumberOfHouses(4);
                houseOrHotelBought = true;
                double hotelCost = 0;
                if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 5) {
                    hotelCost = 50;
                } else if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 11) {
                    hotelCost = 100;
                } else if (entities
                        .getEntities()
                        .get(getEntityPosition(String.valueOf(addBuildingTo
                                .getSelectedItem()))).getBuildingIndex() < 17) {
                    hotelCost = 150;
                } else {
                    hotelCost = 200;
                }
                for (Entity entity : players.get(playerIndex)
                        .getOwnedProperties()) {
                    if (entity.getName().equals(
                            String.valueOf(addBuildingTo.getSelectedItem()))) {
                        entity.setNumberOfHouses(-entity.getNumberOfHouses());
                        entity.setNumberOfHotels(1);
                        break;
                    }
                }
                int numberOfHouses = 0;
                log = ""
                        + players.get(playerIndex).getPlayerName()
                        + " has just bought a hotel at "
                        + entities
                                .getEntities()
                                .get(getEntityPosition(String
                                        .valueOf(addBuildingTo
                                                .getSelectedItem()))).getName()
                        + "\n";
                logText.append(log);
                players.get(playerIndex).setcash(-hotelCost);
                hideAddBuildingComponents();
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                displayProperBuildingLabel(
                        players.get(playerIndex)
                                .getOwnedProperties()
                                .get(getPlayersEntityPosition(String
                                        .valueOf(addBuildingTo
                                                .getSelectedItem())))
                                .getBuildingIndex(), numberOfHouses);
            }
        });

        addBuildingTo.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (addBuildingTo.getSelectedItem() != null) {
                    String entityName = String.valueOf(addBuildingTo
                            .getSelectedItem());
                    String group = "";
                    int entityPosition = 0;
                    int numberOfTheSameGroup = 0;
                    int totalNumberOfHousesInAGroup = 0;
                    int totalNumberOfHotelsInAGroup = 0;
                    boolean canAfford = false;

                    for (Entity entity : entities.getEntities()) {
                        if (entity.getName().equals(entityName)) {
                            group = entity.getGroup();
                            entityPosition = entity.getPosition();
                            break;
                        }
                    }
                    for (Entity anEntity : players.get(playerIndex)
                            .getOwnedProperties()) {
                        if (anEntity.getGroup().equals(group)) {
                            numberOfTheSameGroup++;
                            totalNumberOfHousesInAGroup += anEntity
                                    .getNumberOfHouses();
                            totalNumberOfHotelsInAGroup += anEntity
                                    .getNumberOfHotels();
                        }
                    }
                    if (entityPosition < 10) {
                        if (players.get(playerIndex).getcash() >= 50) {
                            canAfford = true;
                        }
                    } else if (entityPosition < 20) {
                        if (players.get(playerIndex).getcash() >= 100) {
                            canAfford = true;
                        }
                    } else if (entityPosition < 30) {
                        if (players.get(playerIndex).getcash() >= 150) {
                            canAfford = true;
                        }
                    } else {
                        if (players.get(playerIndex).getcash() >= 200) {
                            canAfford = true;
                        }
                    }
                    addHouseButton.setEnabled(false);
                    if (canAfford
                            && !players
                                    .get(playerIndex)
                                    .getOwnedProperties()
                                    .get(getPlayersEntityPosition(String
                                            .valueOf(addBuildingTo
                                                    .getSelectedItem())))
                                    .isMortgaged()) {
                        if (numberOfTheSameGroup == 1) {
                            if (players
                                    .get(playerIndex)
                                    .getOwnedProperties()
                                    .get(getPlayersEntityPosition(String
                                            .valueOf(addBuildingTo
                                                    .getSelectedItem())))
                                    .getNumberOfHouses() == 4
                                    && getNumberOfHotels() > 0) {
                                addHotelButton.setEnabled(true);
                            }
                            if (getNumberOfHouses() > 0) {
                                addHouseButton.setEnabled(true);
                            }
                        } else if (numberOfTheSameGroup == 2) {
                            if (totalNumberOfHousesInAGroup != 0) {
                                if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 0
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 1
                                        && totalNumberOfHousesInAGroup >= 2
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 2
                                        && totalNumberOfHousesInAGroup >= 4
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 3
                                        && totalNumberOfHousesInAGroup >= 6
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 4
                                        && (totalNumberOfHousesInAGroup >= 8 || (totalNumberOfHousesInAGroup >= 4 && totalNumberOfHotelsInAGroup == 1))
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                    if (getNumberOfHotels() > 0) {
                                        addHotelButton.setEnabled(true);
                                    }
                                }
                            } else {
                                if (getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                }
                            }
                        } else if (numberOfTheSameGroup == 3) {
                            if (totalNumberOfHousesInAGroup != 0) {
                                if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 0
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 1
                                        && totalNumberOfHousesInAGroup >= 3
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 2
                                        && totalNumberOfHousesInAGroup >= 6
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 3
                                        && totalNumberOfHousesInAGroup >= 9
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                } else if (players
                                        .get(playerIndex)
                                        .getOwnedProperties()
                                        .get(getPlayersEntityPosition(String
                                                .valueOf(addBuildingTo
                                                        .getSelectedItem())))
                                        .getNumberOfHouses() == 4
                                        && (totalNumberOfHousesInAGroup >= 12
                                        || (totalNumberOfHousesInAGroup >= 8 && totalNumberOfHotelsInAGroup == 1) || (totalNumberOfHousesInAGroup >= 4 && totalNumberOfHotelsInAGroup == 2))
                                        && getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                    if (getNumberOfHotels() > 0) {
                                        addHotelButton.setEnabled(true);
                                    }
                                }
                            } else {
                                if (getNumberOfHouses() > 0) {
                                    addHouseButton.setEnabled(true);
                                }
                            }
                        }
                    }

                    System.out.println("number of total houses in a group: "
                            + totalNumberOfHousesInAGroup);
                    System.out.println("number of the same group: "
                            + numberOfTheSameGroup);
                }
            }

        });

        payArrears.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                payArrears.setVisible(false);
                paymentDue = false;
                switch (arrearsIndex) {
                    case 4:
                        payIncomeTax();
                        break;
                    case 9:
                        followChanceCard9();
                        break;
                    case 10:
                        followChanceCard10();
                        break;
                    case 13:
                        followChanceCard13();
                        break;
                    case 38:
                        payLuxuryTax();
                        break;
                    case 102:
                        followCommunityCard2();
                        break;
                    case 109:
                        followCommunityCard9();
                        break;
                    case 110:
                        followCommunityCard10();
                        break;
                    case 112:
                        followCommunityCard12();
                        break;
                }

                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                } else {
                    rollTheDice.setEnabled(true);
                }
            }
        });

        restartGame.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                boardFrame.setVisible(false);
                      MenuFrame menuFrame = new MenuFrame();
                menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                Color BackgroundColor = new Color(29, 16, 44);
                menuFrame.getContentPane().setBackground(BackgroundColor);

                Dimension d = new Dimension(1158, 551);
                Container c = menuFrame.getContentPane();
                c.setPreferredSize(d);

                menuFrame.setVisible(true);
                menuFrame.pack();
                menuFrame.setLocationRelativeTo(null);
                menuFrame.setResizable(false);

            }
        });

        playersPanes.get(0).setBackground(Color.green);
        playersPanes.get(0).setOpaque(true);
        startNewGame();
    }

    private void setBottom1Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom1.jpg"));
            bottom1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom2Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom2.jpg"));
            bottom2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom4Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom4.jpg"));
            bottom4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom5Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom5.jpg"));
            bottom5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight9Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right9.jpg"));
            right9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight7Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right7.jpg"));
            right7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight5Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right5.jpg"));
            right5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight4Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right4.jpg"));
            right4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight2Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right2.jpg"));
            right2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight1Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right1.jpg"));
            right1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop9Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top9.jpg"));
            top9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop8Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top8.jpg"));
            top8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop7Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top7.jpg"));
            top7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop6Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top6.jpg"));
            top6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop5Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top5.jpg"));
            top5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop4Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top4.jpg"));
            top4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop3Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top3.jpg"));
            top3Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop2Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top2.jpg"));
            top2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop1Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top1.jpg"));
            top1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft1Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left1.jpg"));
            left1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft2Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left2.jpg"));
            left2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft4Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left4.jpg"));
            left4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft5Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left5.jpg"));
            left5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft6Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left6.jpg"));
            left6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft7Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left7.jpg"));
            left7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft8Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left8.jpg"));
            left8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft9Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left9.jpg"));
            left9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom9Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom9.jpg"));
            bottom9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom7Clean() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom7.jpg"));
            bottom7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    //Start Game
    private void startNewGame() {
        gameLog.setVisible(true);
        finishTurn.setVisible(true);
        rollTheDice.setVisible(true);
        dice1.setVisible(true);
        dice2.setVisible(true);

    }

    private void buyOrRent() {
        //Luck Cards
        if (players.get(playerIndex).getPositionOnGameBoard() == 7
                || players.get(playerIndex).getPositionOnGameBoard() == 22
                || players.get(playerIndex).getPositionOnGameBoard() == 36) {
            buyProperty.setVisible(false);
            dontBuyProperty.setVisible(false);
            dealChanceCard();
        }
        //Oppurtunity cards
        if (players.get(playerIndex).getPositionOnGameBoard() == 2
                || players.get(playerIndex).getPositionOnGameBoard() == 17
                || players.get(playerIndex).getPositionOnGameBoard() == 33) {
            dealCommunityCard();
            buyProperty.setVisible(false);
            dontBuyProperty.setVisible(false);
        }

        if (entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .canBePurchased()) {

            if (entities.getEntities()
                    .get(players.get(playerIndex).getPositionOnGameBoard())
                    .getOwner() != null
                    && entities
                            .getEntities()
                            .get(players.get(playerIndex)
                                    .getPositionOnGameBoard()).getOwner()
                            .getPlayerName()
                            .equals(players.get(playerIndex).getPlayerName())) {
                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                }
            } else {
                finishTurn.setEnabled(false);
                // mortgaged
                if (entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .getOwner() != null
                        && !entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getOwner()
                                .getPlayerName()
                                .equals(players.get(playerIndex).getPlayerName())
                        && entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard())
                                .isMortgaged()) {
                    gamePrompt.setText("The property is mortgaged, so there is no need to pay rent");
                    if (!gotDouble || doubleCounter == 3) {
                        finishTurn.setEnabled(true);
                        rollTheDice.setEnabled(false);
                    }
                }

                // unowned property
                if (entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .getOwner() == null) {
                    // sufficient funds to buy
                    if (players.get(playerIndex).IsCompleteFirstCirciut()) {
                        if (entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getCost() <= players
                                        .get(playerIndex).getcash()) {
                            buyProperty.setVisible(true);
                            dontBuyProperty.setVisible(true);
                            rollTheDice.setEnabled(false);
                            // insufficient funds
                        } else {
                            buyProperty.setVisible(true);
                            buyProperty.setEnabled(false);
                            gamePrompt.setText("You don't have enough cash to buy this property. Press don't buy or borrow some money");
                            dontBuyProperty.setVisible(true);
                            rollTheDice.setEnabled(false);
                        }
                    } else {
                        gamePrompt.setText("Complete the first circuit around the board in order to buy a property.");
                        rollTheDice.setEnabled(true);
                        rollTheDice.setEnabled(false);
                        finishTurn.setVisible(true);
                        finishTurn.setEnabled(true);
                    }

                } else if (!entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .getOwner().getPlayerName()
                        .equals(players.get(playerIndex).getPlayerName())
                        && !entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard())
                                .isMortgaged()) {
                    if (!rentCalculated) {
                        calculateRent();
                    }
                    if (rentCalculated) {
                        if (rentValue > players.get(playerIndex).getcash()) {
                            gamePrompt.setText("You need money to pay the rent. Sell property, take loan or retire from game");
                            retireFromGame.setVisible(true);
                        } else {
                            if (players.get(playerIndex)
                                    .getPositionOnGameBoard() != 12
                                    && players.get(playerIndex)
                                            .getPositionOnGameBoard() != 28) {
                                payRent.setVisible(true);
                            }
                        }
                    }
                }
            }

        }
        if (!entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .canBePurchased()) {
            if (!paymentDue) {
                if (!gotDouble || doubleCounter == 3) {
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                }
            } else {
                gamePrompt.setText("you need to pay arrears. Sell or mortgage property or retire from game");
                rollTheDice.setEnabled(false);
                retireFromGame.setVisible(true);
            }
        }
    }

//Show and change Token on board
    private void adjustPlayerPosition() {
        //check player is in jail or not and log it
        //player in jail
        if (!(players.get(playerIndex).getPositionOnGameBoard() == 10)) {
            log = players.get(playerIndex).getPlayerName()
                    + " Go To "
                    + entities
                            .getEntities()
                            .get(players.get(playerIndex)
                                    .getPositionOnGameBoard()).getName() + "\n";
            logText.append(log);
            //Not in jail
        } else {
            if (!players.get(playerIndex).isInJail()) {
                log = players.get(playerIndex).getPlayerName()
                        + " Go To "
                        + entities
                                .getEntities()
                                .get(players.get(playerIndex)
                                        .getPositionOnGameBoard()).getName()
                        + " (just visiting)\n";
                logText.append(log);
            }
        }

        switch (players.get(playerIndex).getPositionOnGameBoard()) {
            case 0:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 1:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 2:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 4.5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 3:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 4) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            //income Tax
            case 4:
                paymentDueAmount = 200;
                if (paymentDueAmount > players.get(playerIndex).getcash()) {
                    gamePrompt.setText("you need to pay arrears. Sell or mortgage property or retire from game");
                    rollTheDice.setEnabled(false);
                    retireFromGame.setVisible(true);
                    paymentDue = true;
                    arrearsIndex = 4;
                } else {
                    payIncomeTax();
                }
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 3.5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 5:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 3) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 6:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 2.5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 7:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 2) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 8:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 1.5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 9:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5) + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 10:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 4, 38, 35);
                break;
            case 11:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 12:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 4.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 13:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 4) + 2 + playerIndex * 3, 38, 35);
                break;
            case 14:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 3.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 15:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 3) + 2 + playerIndex * 3, 38, 35);
                break;
            case 16:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 2.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 17:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 2) + 2 + playerIndex * 3, 38, 35);
                break;
            case 18:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5 * 1.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 19:
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, (int) (frameHeight / 6.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 20:
                if (ParkingMoney == 0) {
                    log = players.get(playerIndex).getPlayerName() + " Free Parking Cash is Empty";
                    logText.append(log);
                } else {
                    players.get(playerIndex).setcash(ParkingMoney);
                    log = players.get(playerIndex).getPlayerName() + " Parking Cash is : " + ParkingMoney + "\n";
                    logText.append(log);
                    ParkingMoney = 0.0;
                    balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                }
                playerIndicators.get(playerIndex).setBounds(20 + playerIndex * 3, 30 + playerIndex * 4, 38, 35);
                break;
            case 21:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 22:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 1.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 23:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 2) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 24:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 2.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 25:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 3) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 26:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 3.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 27:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 4) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 28:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 4.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 29:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 30:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + playerIndex * 3, 20 + playerIndex * 4, 38, 35);
                break;
            case 31:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 32:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 1.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 33:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 2) + 2 + playerIndex * 3, 38, 35);
                break;
            case 34:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 2.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 35:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 3) + 2 + playerIndex * 3, 38, 35);
                break;
            case 36:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 3.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 37:
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 4) + 2 + playerIndex * 3, 38, 35);
                break;

            //Luxury Tax
            case 38:
                paymentDueAmount = 100;
                if (paymentDueAmount > players.get(playerIndex).getcash()) {
                    gamePrompt.setText("you need to pay arrears. Sell or mortgage property or retire from game");
                    rollTheDice.setEnabled(false);
                    retireFromGame.setVisible(true);
                    paymentDue = true;
                    arrearsIndex = 38;
                } else {
                    payLuxuryTax();
                }
                playerIndicators.get(playerIndex).setBounds((int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 4.5) + 2 + playerIndex * 3, 38, 35);
                break;
            case 39:
                playerIndicators.get(playerIndex).setBounds(
                        (int) (frameHeight / 6.5 * 5.5) + 30 + playerIndex * 3, (int) (frameHeight / 6.5 * 5) + 2 + playerIndex * 3, 38, 35);
                break;
        }
        if (players.get(playerIndex).didPassGo()) {
            balanceLabels.get(playerIndex).setText(
                    "£" + players.get(playerIndex).getcash());
            log = players.get(playerIndex).getPlayerName()
                    + " got £200 for passing \"GO\" " + "\n";
            logText.append(log);
            players.get(playerIndex).setPassedGo(false);
            players.get(playerIndex).setIsCompleteFirstCirciut(true);
        }
    }

    private void payIncomeTax() {
        players.get(playerIndex).setcash(-200);
        balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName() + " paid income tax (£200) " + "\n";
        logText.append(log);
    }

    private void payLuxuryTax() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName() + " paid luxury tax (£100) " + "\n";
        logText.append(log);
    }

    private boolean gameOn(boolean IsClassic) {
        //Is Abrigade
        if (!IsClassic) {
            Instant end = Instant.now();
            Duration timeElapsed = Duration.between(start, end);
            if (timeElapsed.getSeconds() > (TimeLimit * 60)) {
                //check turns
                int LastPlayerID = 0;
                for (int i = 0; i < players.size(); i++) {
                    if (!players.get(i).isLooser()) {
                        LastPlayerID = i;
                    }
                }
                if (playerIndex == LastPlayerID) {
                    for (int i = 0; i < players.size(); i++) {
                        if (!players.get(i).isLooser()) {
                            for (int j = 0; j < players.get(i).getOwnedProperties().size(); j++) {
                                if (players.get(i).getOwnedProperties().get(j).isMortgaged()) {
                                    players.get(i).setcash(players.get(i).getOwnedProperties().get(j).getCost() * .5);
                                } else {
                                    players.get(i).setcash(players.get(i).getOwnedProperties().get(j).getCost());
                                    if (players.get(i).getOwnedProperties().get(j).getNumberOfHotels() > 0) {
                                        double hotelCost = 0;
                                        if (entities.getEntities().get(j).getPosition() < 5) {
                                            hotelCost = 50;
                                        } else if (entities.getEntities().get(j).getPosition() < 11) {
                                            hotelCost = 100;
                                        } else if (entities.getEntities().get(j).getPosition() < 17) {
                                            hotelCost = 150;
                                        } else {
                                            hotelCost = 200;
                                        }
                                        players.get(i).setcash(hotelCost);
                                    }
                                    for (int k = 0; k < players.get(i).getOwnedProperties().get(j).getNumberOfHouses(); k++) {
                                        if (players.get(i).getOwnedProperties().get(j).getNumberOfHouses() > 0) {
                                            double houseCost = 0;
                                            if (entities.getEntities().get(j).getPosition() < 5) {
                                                houseCost = 50;
                                            } else if (entities.getEntities().get(j).getPosition() < 11) {
                                                houseCost = 100;
                                            } else if (entities.getEntities().get(j).getPosition() < 17) {
                                                houseCost = 150;
                                            } else {
                                                houseCost = 200;
                                            }
                                            players.get(i).setcash(houseCost);
                                        }
                                    }
                                }
                                players.get(i).getOwnedProperties();
                            }
                        }
                    }
                    finishTurn.setEnabled(false);
                    finishTurn.setVisible(false);

                    int FirstPlayer = 100;
                    int winnerIndex = 0;

                    for (int i = 0; i < players.size(); i++) {
                        if (!players.get(i).isLooser()) {
                            if (FirstPlayer == 100) {
                                FirstPlayer = 101;
                                winnerIndex = i;
                            }
                            if (players.get(i).getcash() > players.get(winnerIndex).getcash()) {
                                winnerIndex = i;
                            }
                        }
                        log = players.get(winnerIndex).getPlayerName()
                                + " won the game. " + "\n";
                        logText.append(log);
                        balanceLabels.get(winnerIndex).setText("WINNER !!!" + players.get(winnerIndex).getcash());
                        restartGame.setVisible(true);
                    }
                } else {
                    return true;
                }
            } else {
                int playersCounter = 0;
                for (Player player : players) {
                    if (!player.isLooser()) {
                        playersCounter++;
                    }
                }
                return (playersCounter >= 2);
            }
        }
        int playersCounter = 0;
        for (Player player : players) {
            if (!player.isLooser()) {
                playersCounter++;
            }
        }
        return (playersCounter >= 2);
    }
// check player Have Property or not Have If Have Show The Related Buttons

    private void generateMortgageComboBox() {
        mortgageModel = new DefaultComboBoxModel<String>();
        for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
            if (entity.getNumberOfHouses() == 0
                    && entity.getNumberOfHotels() == 0) {
                mortgageModel.addElement(entity.getName());
            }
        }
        mortgageComboBox.setModel(mortgageModel);
        mortgageComboBox.setSelectedItem(null);
        sellPropertyModel = new DefaultComboBoxModel<String>();
        for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
            sellPropertyModel.addElement(entity.getName());
        }
        sellPropertyComboBox.setModel(sellPropertyModel);
        mortgageManagement.setVisible(true);
        mortgageComboBox.setVisible(true);
        takeLoan.setVisible(true);
        payLoan.setVisible(true);
        takeLoan.setEnabled(false);
        payLoan.setEnabled(false);
        sellProperty.setVisible(true);
        sellPropertyComboBox.setVisible(true);
        sellPropertyComboBox.setSelectedItem(null);
        sellPropertyButton.setVisible(true);
        sellPropertyButton.setEnabled(false);
    }

    // return number of hotels available in the hotels pool
    public int getNumberOfHotels() {
        return numberOfHotels;
    }

    public void setNumberOfHotels(int update) {
        numberOfHotels += update;
    }

    public int getNumberOfHouses() {
        return numberOfHouses;
    }

    public void setNumberOfHouses(int update) {
        numberOfHouses += update;
    }

    // Check Player Have All Of Current Position Group Property And If Result Is True Enable add buldings Buttons
    private void generateAddBuildingComboBox() {
        Set<String> entitiesNames = new HashSet<String>();
        for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
            if (playerHasAll(entity.getGroup(), players.get(playerIndex)
                    .getPlayerName())
                    || entity.getNumberOfHouses() > 0
                    || hasBuildings(entity.getGroup())) {
                if (entity.getGroup() != "railroads"
                        && entity.getGroup() != "utilities"
                        && entity.getNumberOfHouses() < 5
                        && entity.getNumberOfHotels() < 1) {
                    entitiesNames.add(entity.getName());
                }
            }
        }
        if (entitiesNames.size() > 0) {
            if (getNumberOfHouses() == 0) {
                gamePrompt.setText("There are no houses left to buy...");
            } else if (getNumberOfHotels() == 0) {
                gamePrompt.setText("There are no hotels left to buy...");
            }
            addBuildingToModel = new DefaultComboBoxModel<String>();
            buyBuilding.setVisible(true);
            for (String name : entitiesNames) {
                addBuildingToModel.addElement(name);
            }
            addBuildingTo.setModel(addBuildingToModel);
            addBuildingTo.setVisible(true);
            addBuildingTo.setSelectedItem(null);
            addHouseButton.setVisible(true);
            addHouseButton.setEnabled(false);
            addHotelButton.setVisible(true);
            addHotelButton.setEnabled(false);
        } else {
            hideAddBuildingComponents();
        }
    }

    // Check Group Of Properties
    private boolean playerHasAll(String group, String name) {
        int counter = 0;
        for (Entity entity : entities.getEntities()) {
            if (entity.canBePurchased()) {
                if (entity.getGroup().equals(group)) {
                    if (entity.getOwner() != null
                            && entity.getOwner().getPlayerName().equals(name)) {
                        counter++;
                    }
                }
            }
        }
        if ((group.equals("brown") || group.equals("blue"))) {
            if (counter == 2) {
                return true;
            }

        } else if (!group.equals("brown") || !group.equals("blue")) {
            if (counter == 3) {
                return true;
            }
        }
        return false;
    }

    private void hideAddBuildingComponents() {
        addHotelButton.setEnabled(false);
        addHouseButton.setEnabled(false);
        addHotelButton.setVisible(false);
        addHouseButton.setVisible(false);
        addBuildingTo.setVisible(false);
        buyBuilding.setVisible(false);
    }

    //Check this property hase Any Buldings or not
    private boolean hasBuildings(String group) {
        for (Player player : players) {
            for (Entity entity : player.getOwnedProperties()) {
                if (entity.getGroup().equals(group)) {
                    if (entity.getNumberOfHouses() > 0
                            || entity.getNumberOfHotels() > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void generateBuyOwnedPropertyComboBox() {
        int counter = 0;
        ownedPropertiesModel = new DefaultComboBoxModel<String>();
        for (Entity entity : entities.getEntities()) {
            if (entity.getOwner() != null
                    && !entity.getOwner().getPlayerName()
                            .equals(players.get(playerIndex).getPlayerName())) {
                ownedPropertiesModel.addElement(entity.getName());
                counter++;
            }
        }
        if (counter > 0) {
            ownedProperties.setModel(ownedPropertiesModel);
            ownedProperties.setSelectedItem(null);
            propertyOwner.setText("");
            ownedPropertyValue.setText("");
        } else {
            buyOwnedProperty.setVisible(false);
            ownedProperties.setVisible(false);
            propertyOwner.setVisible(false);
            ownedPropertyValue.setVisible(false);
            buyOwnedPropertyButton.setVisible(false);
        }

    }

    private void generateSellGetOutOfJailCardComboBox() {
        cardBuyersModel = new DefaultComboBoxModel<String>();
        for (int i = 0; i < players.size(); i++) {
            if (i != playerIndex && !players.get(i).isLooser()
                    && players.get(i).getcash() > 0) {
                cardBuyersModel.addElement(players.get(i).getPlayerName());
            }
        }
        cardBuyers.setModel(cardBuyersModel);
        cardPrice.setText("");
        cardBuyers.setSelectedItem(null);
        sellGetOutOfJailCard.setVisible(false);
        cardBuyers.setVisible(true);
        cardPrice.setVisible(true);
        sellGetOutOfJailCardButton.setVisible(true);
        sellGetOutOfJailCardButton.setEnabled(false);
    }

    // Deal a Chance Card
    private void dealChanceCard() {
        chanceCardPicked = true;
        int position = players.get(playerIndex).getPositionOnGameBoard();
        switch (deck.dealChanceCard()) {
            case 0:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance00.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(50);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Bank pays you divided of £50" + "\n";
                logText.append(log);

            case 1:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance01.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(100);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " You have won a lip sync battle. Collect £100" + "\n";
                logText.append(log);

            case 2:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance02.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                position = 39 - position;
                players.get(playerIndex).setPositionOnGameBoard(position);
                adjustPlayerPosition();
                break;
            case 3:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance03.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                if (position > 24) {
                    position = 24 - position + 40;
                    players.get(playerIndex).setcash(200);
                    balanceLabels.get(playerIndex).setText(
                            "£" + players.get(playerIndex).getcash());
                    log = players.get(playerIndex).getPlayerName()
                            + " Advance to Han Xin Gardens. pass GO, collect £200" + "\n";
                    logText.append(log);

                } else {
                    position = 24 - position;
                    log = players.get(playerIndex).getPlayerName()
                            + " Advance to Han Xin Gardens." + "\n";
                    logText.append(log);
                }
                players.get(playerIndex).setPositionOnGameBoard(position);
                adjustPlayerPosition();
                break;
            case 4:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance04.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                if (position == 7) {
                    position = 4;
                } else {
                    position = 40 + 11 - position;
                }
                players.get(playerIndex).setPositionOnGameBoard(position);
                adjustPlayerPosition();
                break;
            case 5:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance05.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(-150);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Pay university fees of £150";
                logText.append(log);
                break;
            case 6:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance06.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }

                if (position > 15) {
                    position = 15 - position + 40;
                    players.get(playerIndex).setcash(200);
                    balanceLabels.get(playerIndex).setText(
                            "£" + players.get(playerIndex).getcash());
                    log = players.get(playerIndex).getPlayerName()
                            + " Take a trip to Hove station. pass GO, collect 200" + "\n";
                    logText.append(log);

                } else {
                    position = 15 - position;
                    log = players.get(playerIndex).getPlayerName()
                            + " Take a trip to Hove station." + "\n";
                    logText.append(log);
                }
                players.get(playerIndex).setPositionOnGameBoard(position);
                adjustPlayerPosition();
                break;
            case 7:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance07.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(150);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Loan matures, collect £150" + "\n";
                logText.append(log);
            case 8:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance08.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                paymentDueAmount = 0;
                for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
                    if (entity.getNumberOfHouses() > 0) {
                        paymentDueAmount += entity.getNumberOfHouses() * 40;
                    }
                    if (entity.getNumberOfHotels() > 0) {
                        paymentDueAmount += 115;
                    }
                }
                if (paymentDueAmount > 0) {
                    if (paymentDueAmount <= players.get(playerIndex).getcash()) {
                        followChanceCard9();
                    } else {
                        paymentDue = true;
                        arrearsIndex = 9;
                    }
                }
                break;
            case 9:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance09.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setPositionOnGameBoard(
                        40 - players.get(playerIndex).getPositionOnGameBoard());
                adjustPlayerPosition();
                break;
            case 10:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance10.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                paymentDueAmount = 0;
                for (Entity entity : players.get(playerIndex).getOwnedProperties()) {
                    if (entity.getNumberOfHouses() > 0) {
                        paymentDueAmount += entity.getNumberOfHouses() * 25;
                    }
                    if (entity.getNumberOfHotels() > 0) {
                        paymentDueAmount += 100;
                    }
                }
                if (paymentDueAmount > 0) {
                    if (paymentDueAmount <= players.get(playerIndex).getcash()) {
                        followChanceCard9();
                    } else {
                        paymentDue = true;
                        arrearsIndex = 9;
                    }
                }
                break;
            case 11:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance11.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setPositionOnGameBoard(-3);
                adjustPlayerPosition();
                break;
            case 12:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance12.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                if (position > 12) {
                    position = 12 - position + 40;
                    players.get(playerIndex).setcash(200);
                    balanceLabels.get(playerIndex).setText(
                            "£" + players.get(playerIndex).getcash());
                    log = players.get(playerIndex).getPlayerName()
                            + " Advance to Skywalker Drive. pass GO, collect £200" + "\n";
                    logText.append(log);

                } else {
                    position = 12 - position;
                    log = players.get(playerIndex).getPlayerName()
                            + " Advance to Skywalker Drive." + "\n";
                    logText.append(log);
                }
                players.get(playerIndex).setPositionOnGameBoard(position);
                adjustPlayerPosition();
                break;
            case 13:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance13.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                    position = 10 - position;
                    players.get(playerIndex).setPositionOnGameBoard(position);
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                    players.get(playerIndex).setInJail(true);
                    log = "  /> " + players.get(playerIndex).getPlayerName()
                            + " went to Jail" + "\n";
                    logText.append(log);
                    adjustPlayerPosition();
                } else {
                    gamePrompt.setText("Do you want to use your get out of jail card?");
                    useGetOutOfJailCard.setVisible(true);
                    dontUseGetOutOfJailCard.setVisible(true);
                    rollTheDice.setEnabled(false);
                    finishTurn.setEnabled(false);
                }

                break;
            case 14:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance14.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(150);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " received £150 from the bank" + "\n";
                logText.append(log);
                break;
            case 15:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance15.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).addGetOutOfJailCard(deck.getChanceCard(6));
                getOutOfJailLabels.get(playerIndex).setText(
                        "get out of jail cards : "
                        + players.get(playerIndex)
                                .getNumberOfGetOutOfJailCards());
                getOutOfJailLabels.get(playerIndex).setVisible(true);

                generateSellGetOutOfJailCardComboBox();

                log = players.get(playerIndex).getPlayerName()
                        + " received get out of Jail card \n";
                logText.append(log);
                break;
        }
    }
    // Deal A COmmunity Card

    private void dealCommunityCard() {
        communityCardPicked = true;
        switch (deck.dealChanceCard()) {
            case 0:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community00.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(100);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " inherit £100" + "\n";
                logText.append(log);
                break;
            case 1:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community01.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(20);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " have won 2nd prize in a beauty contest, collect £20" + "\n";
                logText.append(log);
                break;
            case 2:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community02.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setPositionOnGameBoard(1);
                adjustPlayerPosition();
                break;
            case 3:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community03.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(20);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Student loan refund. Collect £20" + "\n";
                logText.append(log);
                break;
            case 4:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community04.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(200);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Bank error in your favour. Collect £200" + "\n";
                logText.append(log);
                break;
            case 5:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community05.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                int counter = 0;
                players.get(playerIndex).setcash(-100);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Pay bill for text books of £100" + "\n";
                logText.append(log);
                break;
            case 6:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community06.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(-50);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Mega late night taxi bill pay £50" + "\n";
                logText.append(log);
                break;
            case 7:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community07.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setPositionOnGameBoard(
                        40 - players.get(playerIndex).getPositionOnGameBoard());
                adjustPlayerPosition();
                break;
            case 8:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community08.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(50);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " From sale of Bitcoin you get £50" + "\n";
                logText.append(log);
                break;
            case 9:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community09.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(10);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " From sale of Bitcoin you get £50" + "\n";
                logText.append(log);
                break;
            case 10:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community10.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                paymentDueAmount = 50;
                if (players.get(playerIndex).getcash() >= paymentDueAmount) {
                    followCommunityCard10();
                } else {
                    paymentDue = true;
                    arrearsIndex = 110;
                }
                break;
            case 11:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community11.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(100);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Savings bond matures, collect £100" + "\n";
                logText.append(log);
                break;
            case 12:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community12.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                int position = players.get(playerIndex).getPositionOnGameBoard();
                if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                    position = 10 - position;
                    players.get(playerIndex).setPositionOnGameBoard(position);
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                    players.get(playerIndex).setInJail(true);
                    log = players.get(playerIndex).getPlayerName()
                            + " went to Jail" + "\n";
                    logText.append(log);
                    adjustPlayerPosition();
                } else {
                    gamePrompt.setText("Do you want to use your get out of jail card?");
                    useGetOutOfJailCard.setVisible(true);
                    dontUseGetOutOfJailCard.setVisible(true);
                    rollTheDice.setEnabled(false);
                    finishTurn.setEnabled(false);
                }
                break;
            case 13:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community13.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(25);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " Received interest on shares of £25" + "\n";
                logText.append(log);
                break;
            case 14:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community14.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                counter = 0;
                for (int i = 0; i < players.size(); i++) {
                    if (i != playerIndex) {
                        players.get(i).setcash(-10);
                        counter++;
                        balanceLabels.get(i).setText("£" + players.get(i).getcash());
                    }
                }
                players.get(playerIndex).setcash(counter * 10);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " It's your birthday. Collect £10 from each player" + "\n";
                logText.append(log);
                break;
            case 15:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community15.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).addGetOutOfJailCard(deck.getChanceCard(6));
                getOutOfJailLabels.get(playerIndex).setText(
                        "get out of jail cards : "
                        + players.get(playerIndex)
                                .getNumberOfGetOutOfJailCards());
                getOutOfJailLabels.get(playerIndex).setVisible(true);
                generateSellGetOutOfJailCardComboBox();
                log = players.get(playerIndex).getPlayerName()
                        + " received get out of Jail card \n";
                logText.append(log);
                break;
            case 16:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/community16.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                players.get(playerIndex).setcash(100);
                balanceLabels.get(playerIndex).setText(
                        "£" + players.get(playerIndex).getcash());
                log = players.get(playerIndex).getPlayerName()
                        + " has received £100 from holiday fund" + "\n";
                logText.append(log);
        }
    }

    //calculating rent of bulding
    private void calculateRent() {
        ownerIndex = getPlayerIndex(entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .getOwner());
        if (entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .getGroup().equals("utilities")) {
            gamePrompt.setText("Roll the dice to estimate the amount of rent");
            extraRollNeeded = true;
            rollTheDice.setEnabled(true);
            payRent.setVisible(false);
            if (randomDice1 == randomDice2) {
                gotDouble = true;
            }
        }

        if (entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .getNumberOfHotels() == 0
                && !entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .getGroup().equals("utilities")
                && !entities.getEntities()
                        .get(players.get(playerIndex).getPositionOnGameBoard())
                        .getGroup().equals("railroads")) {
            rentValue = entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getRentValues().get(entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getNumberOfHouses());

            if (playerHasAll(
                    entities.getEntities()
                            .get(players.get(playerIndex).getPositionOnGameBoard()).getGroup(), players.get(ownerIndex).getPlayerName())
                    && entities
                            .getEntities()
                            .get(players.get(playerIndex)
                                    .getPositionOnGameBoard())
                            .getNumberOfHotels() == 0
                    && entities
                            .getEntities()
                            .get(players.get(playerIndex)
                                    .getPositionOnGameBoard())
                            .getNumberOfHouses() == 0) {
                rentValue = rentValue * 2;
            }
        } else if (entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .getNumberOfHotels() == 1) {
            rentValue = entities.getEntities()
                    .get(players.get(playerIndex).getPositionOnGameBoard())
                    .getRentValues().get(5);
        } else if (entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .getGroup().equals("railroads")) {
            rentValue = getRailRoadRent(players.get(ownerIndex).getPlayerName());
            if (sentByChanceCard) {
                rentValue *= 2;
            }
        }

        if (players.get(playerIndex).getPositionOnGameBoard() == 12
                || players.get(playerIndex).getPositionOnGameBoard() == 28) {
            rollTheDice.setEnabled(true);
        } else {
            rollTheDice.setEnabled(false);
            rentCalculated = true;
        }
    }

    private void followChanceCard9() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName() + " has spent £"
                + paymentDueAmount + " on general repairs on his properties \n";
        logText.append(log);
    }

    private void followChanceCard10() {
        players.get(playerIndex).setcash(-15);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName()
                + " paid poor tax: £15" + "\n";
        logText.append(log);
    }

    /**
     * when player has sufficient funds, action is taken according to the dealt
     * card
     */
    private void followChanceCard13() {
        for (int i = 0; i < players.size(); i++) {
            if (i != playerIndex) {
                if (!players.get(i).isLooser()) {
                    players.get(i).setcash(50);
                    balanceLabels.get(i).setText(
                            "£" + players.get(i).getcash());
                }
            }
        }
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName()
                + " paid each of other players £50" + "\n";
        logText.append(log);
    }

    /**
     * when player has sufficient funds, action is taken according to the dealt
     * card
     */
    private void followCommunityCard2() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName()
                + " has paid £50 for a doctor fees\n";
        logText.append(log);
    }

    /**
     * when player has sufficient funds, action is taken according to the dealt
     * card
     */
    private void followCommunityCard9() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName()
                + " has paid £100 for hospital fees" + "\n";
        logText.append(log);
    }

    /**
     * when player has sufficient funds, action is taken according to the dealt
     * card
     */
    private void followCommunityCard10() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName()
                + " has paid £50 for school fees" + "\n";
        logText.append(log);
    }

    /**
     * when player has sufficient funds, action is taken according to the dealt
     * card
     */
    private void followCommunityCard12() {
        players.get(playerIndex).setcash(-paymentDueAmount);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());
        log = players.get(playerIndex).getPlayerName() + " has spent £"
                + paymentDueAmount + " on street repairs \n";
        logText.append(log);
    }

    private double getRailRoadRent(String name) {
        int counter = 0;
        double rentValue = 0;
        for (Entity entity : entities.getEntities()) {
            if (entity.getGroup() != null
                    && entity.getGroup().equals("railroads")) {
                if (entity.getOwner() != null
                        && entity.getOwner().getPlayerName().equals(name)) {
                    counter++;
                }
            }
        }
        switch (counter) {
            case 1:
                rentValue = 25;
                break;
            case 2:
                rentValue = 50;
                break;
            case 3:
                rentValue = 100;
                break;
            case 4:
                rentValue = 200;
                break;
        }
        return rentValue;
    }

    // Player Index Shows Who Player Must Play Now And This Method Getter Of ThisnVariable
    private int getPlayerIndex(Player player) {
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getPlayerName().equals(player.getPlayerName())) {
                return i;
            }
        }
        return -1;
    }

    // Player Index Shows Who Player Must Play Now And This Method Getter Of ThisnVariable
    private int getPlayerIndex(String name) {
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getPlayerName().equals(name)) {
                return i;
            }
        }
        return -1;
    }

    private void applyOrRemoveMortgagedLabel(int position, boolean mortgaged) {
        switch (position) {
            case 1:
                if (mortgaged) {
                    setBottom9Mortgaged();
                } else {
                    setBottom9Clean();
                }
                break;
            case 3:
                if (mortgaged) {
                    setBottom7Mortgaged();
                } else {
                    setBottom7Clean();
                }
                break;
            case 5:
                if (mortgaged) {
                    setBottom5Mortgaged();
                } else {
                    setBottom5Clean();
                }
                break;
            case 6:
                if (mortgaged) {
                    setBottom4Mortgaged();
                } else {
                    setBottom4Clean();
                }
                break;
            case 8:
                if (mortgaged) {
                    setBottom2Mortgaged();
                } else {
                    setBottom2Clean();
                }
                break;
            case 9:
                if (mortgaged) {
                    setBottom1Mortgaged();
                } else {
                    setBottom1Clean();
                }
                break;
            case 11:
                if (mortgaged) {
                    setLeft9Mortgaged();
                } else {
                    setLeft9Clean();
                }
                break;
            case 12:
                if (mortgaged) {
                    setLeft8Mortgaged();
                } else {
                    setLeft8Clean();
                }
                break;
            case 13:
                if (mortgaged) {
                    setLeft7Mortgaged();
                } else {
                    setLeft7Clean();
                }
                break;
            case 14:
                if (mortgaged) {
                    setLeft6Mortgaged();
                } else {
                    setLeft6Clean();
                }
                break;
            case 15:
                if (mortgaged) {
                    setLeft5Mortgaged();
                } else {
                    setLeft5Clean();
                }
                break;
            case 16:
                if (mortgaged) {
                    setLeft4Mortgaged();
                } else {
                    setLeft4Clean();
                }
                break;
            case 18:
                if (mortgaged) {
                    setLeft2Mortgaged();
                } else {
                    setLeft2Clean();
                }
                break;
            case 19:
                if (mortgaged) {
                    setLeft1Mortgaged();
                } else {
                    setLeft1Clean();
                }
                break;
            case 21:
                if (mortgaged) {
                    setTop1Mortgaged();
                } else {
                    setTop1Clean();
                }
                break;
            case 23:
                if (mortgaged) {
                    setTop3Mortgaged();
                } else {
                    setTop3Clean();
                }
                break;
            case 24:
                if (mortgaged) {
                    setTop4Mortgaged();
                } else {
                    setTop4Clean();
                }
                break;
            case 25:
                if (mortgaged) {
                    setTop5Mortgaged();
                } else {
                    setTop5Clean();
                }
                break;
            case 26:
                if (mortgaged) {
                    setTop6Mortgaged();
                } else {
                    setTop6Clean();
                }
                break;
            case 27:
                if (mortgaged) {
                    setTop7Mortgaged();
                } else {
                    setTop7Clean();
                }
                break;
            case 28:
                if (mortgaged) {
                    setTop8Mortgaged();
                } else {
                    setTop8Clean();
                }
                break;
            case 29:
                if (mortgaged) {
                    setTop9Mortgaged();
                } else {
                    setTop9Clean();
                }
                break;
            case 31:
                if (mortgaged) {
                    setRight1Mortgaged();
                } else {
                    setRight1Clean();
                }
                break;
            case 32:
                if (mortgaged) {
                    setRight2Mortgaged();
                } else {
                    setRight2Clean();
                }
                break;
            case 34:
                if (mortgaged) {
                    setRight4Mortgaged();
                } else {
                    setRight4Clean();
                }
                break;
            case 35:
                if (mortgaged) {
                    setRight5Mortgaged();
                } else {
                    setRight5Clean();
                }
                break;
            case 37:
                if (mortgaged) {
                    setRight7Mortgaged();
                } else {
                    setRight7Clean();
                }
                break;
            case 39:
                if (mortgaged) {
                    setRight9Mortgaged();
                } else {
                    setRight9Clean();
                }
                break;
        }
    }

    private void setBottom9Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom9Mortgaged.jpg"));
            bottom9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom7Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom7Mortgaged.jpg"));
            bottom7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom5Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom5Mortgaged.jpg"));
            bottom5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom4Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom4Mortgaged.jpg"));
            bottom4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom2Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom2Mortgaged.jpg"));
            bottom2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setBottom1Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/bottom1Mortgaged.jpg"));
            bottom1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft9Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left9Mortgaged.jpg"));
            left9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft8Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left8Mortgaged.jpg"));
            left8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft7Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left7Mortgaged.jpg"));
            left7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft6Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left6Mortgaged.jpg"));
            left6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft5Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left5Mortgaged.jpg"));
            left5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft4Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left4Mortgaged.jpg"));
            left4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft2Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left2Mortgaged.jpg"));
            left2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setLeft1Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/left1Mortgaged.jpg"));
            left1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop1Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top1Mortgaged.jpg"));
            top1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop3Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top3Mortgaged.jpg"));
            top3Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop4Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top4Mortgaged.jpg"));
            top4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop5Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top5Mortgaged.jpg"));
            top5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop6Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top6Mortgaged.jpg"));
            top6Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop7Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top7Mortgaged.jpg"));
            top7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop8Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top8Mortgaged.jpg"));
            top8Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setTop9Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/top9Mortgaged.jpg"));
            top9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight1Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right1Mortgaged.jpg"));
            right1Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight2Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right2Mortgaged.jpg"));
            right2Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight4Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right4Mortgaged.jpg"));
            right4Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight5Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right5Mortgaged.jpg"));
            right5Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight7Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right7Mortgaged.jpg"));
            right7Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void setRight9Mortgaged() {
        try {
            Image img = ImageIO.read(getClass().getResource("resources/right9Mortgaged.jpg"));
            right9Label.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
    }

    private void displayProperBuildingLabel(int buildingIndex,
            int numberOfHouses) {
        if (buildingIndex < 5) {
            switch (numberOfHouses) {
                case 0:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/hotel.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 1:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house1.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 2:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house2.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 3:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house3.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 4:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house4.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 5:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house5.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
            }
        } else if (buildingIndex < 11) {
            switch (numberOfHouses) {
                case 0:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/hotelFlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 1:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house1FlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 2:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house2FlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 3:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house3FlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 4:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house4FlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 5:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house5FlippedRight.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
            }
        } else if (buildingIndex < 17) {
            switch (numberOfHouses) {
                case 0:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/hotelUpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 1:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house1UpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 2:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house2UpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 3:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house3UpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 4:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house4UpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 5:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house5UpsideDown.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
            }
        } else {
            switch (numberOfHouses) {
                case 0:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/hotelFlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 1:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house1FlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 2:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house2FlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 3:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house3FlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 4:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house4FlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
                case 5:
                    try {
                        Image img = ImageIO.read(getClass().getResource(
                                "resources/house5FlippedLeft.png"));
                        buildingLabels.get(buildingIndex).setIcon(
                                new ImageIcon(img));
                    } catch (IOException ex) {
                    }
                    break;
            }
        }
    }

//AI Methods
    private int getEntityPosition(String name) {
        for (Entity entity : entities.getEntities()) {
            if (entity.getName().equals(name)) {
                return entity.getPosition();
            }
        }
        return -1;
    }

    private int getPlayersEntityPosition(String name) {
        for (int i = 0; i < players.get(playerIndex).getOwnedProperties()
                .size(); i++) {
            if (players.get(playerIndex).getOwnedProperties().get(i).getName()
                    .equals(name)) {
                return i;
            }
        }
        return -1;
    }
// AI 

    private void PlayAI() {
        //First Rolling The Dice
        boolean mustFinish = false;
        while (!mustFinish) {
            //check RollTheDice Button 
            if (rollTheDice.isEnabled() && rollTheDice.isVisible()) {
                log = players.get(playerIndex).getPlayerName()
                        + "  ... Rolled The Dice " + "\n";
                logText.append(log);
                RollTheDiceAI();

            }
            if (buyProperty.isVisible() && buyProperty.isEnabled() && players.get(playerIndex).IsCompleteFirstCirciut()) {
                log = players.get(playerIndex).getPlayerName()
                        + " ... Buy a Property " + "\n";
                logText.append(log);
                BuyPropertyByAI();
            }

            if (payRent.isVisible() && payRent.isEnabled()) {
                log = players.get(playerIndex).getPlayerName()
                        + " Is AI ... pay Rent " + "\n";
                logText.append(log);
                PayRentByAI();
            }

            if (finishTurn.isEnabled() && finishTurn.isVisible()) {
                log = players.get(playerIndex).getPlayerName()
                        + "... Finished Turn " + "\n";
                logText.append(log);
                finishTurnAI();
                mustFinish = true;
            }
        }
    }

    private void RollTheDiceAI() {
        gamePrompt.setText("");
        randomDice1 = random.nextInt(6) + 1;
        randomDice2 = random.nextInt(6) + 1;
        System.out.println(randomDice1);
        System.out.println(randomDice2);
        buyProperty.setEnabled(true);
        buyUnwantedProperty.setVisible(false);
        buyUnwantedPropertyButton.setVisible(false);
        priceOfUnwantedProperty.setVisible(false);
        switch (randomDice1) {
            case 1:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice1.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 2:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice2.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 3:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice3.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 4:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice4.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 5:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice5.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 6:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
                    dice1.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
        }
        switch (randomDice2) {
            case 1:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice1.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 2:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice2.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 3:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice3.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 4:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice4.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 5:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice5.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
            case 6:
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/dice6.jpg"));
                    dice2.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                break;
        }
        System.out.println(extraRollNeeded);
        if (!extraRollNeeded) {
            if (randomDice1 == randomDice2) {
                doubleCounter++;
                gotDouble = true;
            } else {
                gotDouble = false;
            }
            if (doubleCounter < 3) {
                players.get(playerIndex).setPositionOnGameBoard(randomDice1 + randomDice2);
                finishTurn.setEnabled(false);
            }
            // three doubles - player goes to the jail
            if (doubleCounter == 3
                    || players.get(playerIndex).getPositionOnGameBoard() == 30) {
                // no get out of jail card
                if (players.get(playerIndex).getNumberOfGetOutOfJailCards() == 0) {
                    finishTurn.setEnabled(true);
                    rollTheDice.setEnabled(false);
                    players.get(playerIndex).setInJail(true);
                    if (doubleCounter < 3) {
                        log = players.get(playerIndex).getPlayerName() + " went to Jail" + "\n";
                        logText.append(log);
                    } else {
                        log = players.get(playerIndex).getPlayerName() + " went to Jail for rolling 3 doubles " + "\n";
                        logText.append(log);
                    }
                    players.get(playerIndex).setPositionOnGameBoard(10 - players.get(playerIndex).getPositionOnGameBoard());
                    adjustPlayerPosition();
                    System.out.println(players.get(playerIndex).getPlayerName() + " " + players.get(playerIndex).getPositionOnGameBoard() + " in Jail: " + players.get(playerIndex).isInJail());
                    doubleCounter = 0;
                } else {
                    gamePrompt.setText("Do you want to use your get out of jail card?");
                    useGetOutOfJailCard.setVisible(true);
                    dontUseGetOutOfJailCard.setVisible(true);
                    rollTheDice.setEnabled(false);
                    finishTurn.setEnabled(false);
                }
            } else {
                adjustPlayerPosition();
                System.out.println(players.get(playerIndex).getPlayerName() + " " + players.get(playerIndex).getPositionOnGameBoard());
                buyOrRent();
            }
        } else {
            if (players.get(playerIndex).isInJail()) {
                if (!(randomDice1 == randomDice2)) {
                    if (players.get(playerIndex).getTurnsInJail() == 1) {
                        log = players.get(playerIndex).getPlayerName() + " has his/her balance deducted by £50 and got out of Jail" + "\n";
                        logText.append(log);
                        players.get(playerIndex).setcash(-50);
                        players.get(playerIndex).setInJail(false);
                        players.get(playerIndex).setTurnsInJail(0);
                        useGetOutOfJailCard.setVisible(false);
                        pay50toGetOutOfJail.setVisible(false);
                        gamePrompt.setText("");
                        balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                    } else {
                        players.get(playerIndex).setTurnsInJail(1);
                        useGetOutOfJailCard.setVisible(false);
                        pay50toGetOutOfJail.setVisible(false);
                        gamePrompt.setText("");
                    }
                    extraRollNeeded = false;
                    rollTheDice.setEnabled(false);
                    finishTurn.setEnabled(true);
                } else {
                    players.get(playerIndex).setInJail(false);
                    players.get(playerIndex).setTurnsInJail(0);
                    useGetOutOfJailCard.setVisible(false);
                    pay50toGetOutOfJail.setVisible(false);
                    log = players.get(playerIndex).getPlayerName() + " rolled double and got out of Jail" + "\n";
                    logText.append(log);
                    gamePrompt.setText("");
                    extraRollNeeded = false;
                    balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
                    doubleCounter = 0;
                    if (getNumberOfHouses() > 0 || getNumberOfHotels() > 0) {
                        generateAddBuildingComboBox();
                    }
                }
            } else {
                rentCalculated = true;
                rollTheDice.setEnabled(false);
                if ((players.get(playerIndex).getPositionOnGameBoard() == 12 && entities
                        .getEntities().get(28).getOwner() != null)
                        || (players.get(playerIndex)
                                .getPositionOnGameBoard() == 28 && entities
                                .getEntities().get(12).getOwner() != null)
                        || (sentByChanceCard && players
                                .get(playerIndex)
                                .getPositionOnGameBoard() == 12)
                        || (sentByChanceCard && players
                                .get(playerIndex)
                                .getPositionOnGameBoard() == 28)) {
                    rentValue = 10 * (randomDice1 + randomDice2);
                } else if (players.get(playerIndex)
                        .getPositionOnGameBoard() == 12
                        && entities.getEntities().get(28).getOwner() == null
                        || players.get(playerIndex)
                                .getPositionOnGameBoard() == 28
                        && entities.getEntities().get(12).getOwner() == null) {
                    rentValue = 4 * (randomDice1 + randomDice2);
                }
                if (rentCalculated) {
                    if (rentValue > players.get(playerIndex)
                            .getcash()) {
                        gamePrompt.setText("You need money to pay the rent. Sell property, take loan or retire from game");
                        retireFromGame.setVisible(true);
                    } else {
                        payRent.setVisible(true);
                        retireFromGame.setVisible(false);
                    }
                }

            }
        }
    }

    private void PayRentByAI() {
        sentByChanceCard = false;
        rentCalculated = false;
        extraRollNeeded = false;
        ownerIndex = getPlayerIndex(entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getOwner());
        players.get(playerIndex).setcash(-rentValue);
        players.get(ownerIndex).setcash(rentValue);

        if (!gotDouble || doubleCounter == 3) {
            finishTurn.setEnabled(true);
            rollTheDice.setEnabled(false);

        } else if (gotDouble && doubleCounter < 3) {
            rollTheDice.setEnabled(true);

        }
        payRent.setVisible(false);
        log = players.get(playerIndex).getPlayerName() + " paid " + rentValue + " rent to " + players.get(
                getPlayerIndex(entities
                        .getEntities()
                        .get(players.get(playerIndex)
                                .getPositionOnGameBoard())
                        .getOwner())).getPlayerName() + "\n";
        logText.append(log);
        balanceLabels.get(playerIndex).setText("£" + players.get(playerIndex).getcash());
        balanceLabels.get(ownerIndex).setText("£" + players.get(ownerIndex).getcash());
        gamePrompt.setText("");
        System.out.println("number of houses: " + entities.getEntities().get(players.get(playerIndex).getPositionOnGameBoard()).getNumberOfHouses());
    }

    private void finishTurnAI() {
        if (true) {
            if (chanceCardPicked) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chance.jpg"));
                    LuckButton.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                chanceCardPicked = false;
            }
            if (communityCardPicked) {
                try {
                    Image img = ImageIO.read(getClass().getResource("resources/chest.jpg"));
                    Opportunity.setIcon(new ImageIcon(img));
                } catch (IOException ex) {
                }
                communityCardPicked = false;
            }
            // Find Player Was must Play // Find Player Must play this turn
            do {
                playersPanes.get(playerIndex).setBorder(BorderFactory.createLineBorder(Color.black, 2));
                playersPanes.get(playerIndex).setBackground(new Color(131, 248, 244));
                playersPanes.get(playerIndex).setOpaque(true);
                playerIndex = (playerIndex + 1) % players.size();
                playersPanes.get(playerIndex).setBorder(BorderFactory.createLineBorder(Color.green, 2));
                playersPanes.get(playerIndex).setBackground(Color.green);
                playersPanes.get(playerIndex).setOpaque(true);
            } while (players.get(playerIndex).isLooser());

            if (players.get(playerIndex).isInJail()
                    && players.get(playerIndex).getNumberOfGetOutOfJailCards() > 0) {
                gamePrompt.setText("Use the card, pay £50 or roll the dice to get out of Jail");
                useGetOutOfJailCard.setVisible(true);
                pay50toGetOutOfJail.setVisible(true);
                rollTheDice.setEnabled(true);
                extraRollNeeded = true;
            } else if (players.get(playerIndex).isInJail()) {
                gamePrompt.setText("You need to pay £50 or roll double to get out of Jail");
                extraRollNeeded = true;
                rollTheDice.setEnabled(true);
                pay50toGetOutOfJail.setVisible(true);
            } else {
                rollTheDice.setEnabled(true);
                gamePrompt.setText("");
            }
            finishTurn.setEnabled(false);
            doubleCounter = 0;
            buyProperty.setEnabled(true);
            buyUnwantedProperty.setVisible(false);
            buyUnwantedPropertyButton.setVisible(false);
            priceOfUnwantedProperty.setVisible(false);
            if (players.get(playerIndex).getOwnedProperties().size() > 0) {
                generateMortgageComboBox();
            } else {
                mortgageManagement.setVisible(false);
                mortgageComboBox.setVisible(false);
                takeLoan.setVisible(false);
                payLoan.setVisible(false);
                sellProperty.setVisible(false);
                sellPropertyComboBox.setVisible(false);
                buyer.setVisible(false);
                sellingPrice.setVisible(false);
                sellPropertyButton.setVisible(false);
            }
            if (getNumberOfHouses() > 0 || getNumberOfHotels() > 0
                    && !players.get(playerIndex).isInJail()) {
                generateAddBuildingComboBox();
            }
            houseOrHotelBought = false;
            if (players.get(playerIndex).getNumberOfGetOutOfJailCards() > 0) {
                generateSellGetOutOfJailCardComboBox();
            } else {
                sellGetOutOfJailCard.setVisible(false);
                cardBuyers.setVisible(false);
                cardPrice.setVisible(false);
                sellGetOutOfJailCardButton.setVisible(false);
            }
            generateBuyOwnedPropertyComboBox();
        } else {
            finishTurn.setEnabled(false);
            finishTurn.setVisible(false);
            int winnerIndex = 0;
            for (int i = 0; i < players.size(); i++) {
                if (!players.get(i).isLooser()) {
                    winnerIndex = i;
                }
            }
            log = players.get(winnerIndex).getPlayerName()
                    + " won the game. " + "\n";
            logText.append(log);
            balanceLabels.get(winnerIndex).setText("WINNER !!!");
            restartGame.setVisible(true);
        }
        //play AI
        if (!players.get(playerIndex).getIsHuman()) {
            log = players.get(playerIndex).getPlayerName()
                    + " Is AI ... Roll The Dice " + "\n";
            logText.append(log);
            RollTheDiceAI();

            if (finishTurn.isEnabled()) {
                log = players.get(playerIndex).getPlayerName()
                        + " Is AI ... Finished Our Turn " + "\n";
                logText.append(log);
            }
        }
    }

    private void BuyPropertyByAI() {
        entities.getEntities()
                .get(players.get(playerIndex).getPositionOnGameBoard())
                .setOwner(players.get(playerIndex));

        // adding property to player's ArrayList of properties
        players.get(playerIndex)
                .getOwnedProperties()
                .add(entities.getEntities().get(
                        players.get(playerIndex)
                                .getPositionOnGameBoard()));

        // deducting the value of the property from player's balance
        players.get(playerIndex).setcash(
                -entities
                        .getEntities()
                        .get(players.get(playerIndex)
                                .getPositionOnGameBoard()).getCost());

        if (!gotDouble || doubleCounter == 3) {
            finishTurn.setEnabled(true);
        } else if (gotDouble && doubleCounter < 3) {
            rollTheDice.setEnabled(true);
        }
        buyProperty.setVisible(false);
        dontBuyProperty.setVisible(false);
        log = players.get(playerIndex).getPlayerName()
                + " has just bought "
                + entities
                        .getEntities()
                        .get(players.get(playerIndex)
                                .getPositionOnGameBoard()).getName()
                + "(worth £"
                + entities
                        .getEntities()
                        .get(players.get(playerIndex)
                                .getPositionOnGameBoard()).getCost()
                + ")\n";
        logText.append(log);
        balanceLabels.get(playerIndex).setText(
                "£" + players.get(playerIndex).getcash());

        generateMortgageComboBox();
        if (!houseOrHotelBought
                && (getNumberOfHotels() > 0 || getNumberOfHouses() > 0)
                && !players.get(playerIndex).isInJail()) {
            generateAddBuildingComboBox();
        }
    }

    private void DontBuyPropertyByAI() {
        buyProperty.setVisible(false);
        dontBuyProperty.setVisible(false);
        log = players.get(playerIndex).getPlayerName()
                + " did not buy "
                + entities
                        .getEntities()
                        .get(players.get(playerIndex)
                                .getPositionOnGameBoard()).getName()
                + "\n";
        logText.append(log);

        buyUnwantedPropertyModel = new DefaultComboBoxModel<String>();
        for (Player player : players) {
            if (!player.getPlayerName().equals(
                    players.get(playerIndex).getPlayerName())
                    && !player.isLooser()) {
                buyUnwantedPropertyModel.addElement(player.getPlayerName());
            }
        }
        buyUnwantedProperty.setModel(buyUnwantedPropertyModel);
        gamePrompt
                .setText("Please pick a name of a player (if interested) and enter the amount to be paid for the property");
        buyUnwantedProperty.setVisible(true);
        buyUnwantedPropertyButton.setVisible(true);
        priceOfUnwantedProperty.setVisible(true);
        if (gotDouble && doubleCounter < 3) {
            rollTheDice.setEnabled(true);
        } else {
            finishTurn.setEnabled(true);
        }
    }

    // this method is back to menu -- hide Game Board and show menu 
    public static void ShowSplash() throws IOException, IOException {
        //create Jframe
        JFrame SplashFrame = new JFrame("Property Tycoon");

        //create Logo Image
        SplashFrame.add(new JLabel(new ImageIcon("src\\Content\\PropertyTyconLogoMedium.png")));
        SplashFrame.setVisible(true);
        Container c = SplashFrame.getContentPane();
        Dimension d = new Dimension(530, 415);
        c.setPreferredSize(d);
        SplashFrame.pack();
        SplashFrame.setLocationRelativeTo(null);
        SplashFrame.setResizable(false);

        JButton btnExit = new JButton("Exit Help");
        btnExit.setBounds(190, 350, 150, 30);
        btnExit.setEnabled(false);
        SplashFrame.add(btnExit);
        btnExit.setEnabled(true);
        btnExit.addActionListener((ActionEvent e) -> {
            SplashFrame.setVisible(false);
        });
    }

    //this Methos Show Which Player Hase which Properties
    private void ShowPlayerProperties(int PlayerSelectedId) throws IOException, IOException {
        JFrame PropertiesListFrame = new JFrame("Player : " + PlayerSelectedId + " Property ");
        PropertiesListFrame.setVisible(true);
        Container c = PropertiesListFrame.getContentPane();
        Dimension d = new Dimension(530, 415);
        c.setPreferredSize(d);
        PropertiesListFrame.pack();
        PropertiesListFrame.setLocationRelativeTo(null);
        PropertiesListFrame.setResizable(false);
        String TempText = "Player " + PlayerSelectedId + " Not have Property";
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setOpaque(false);
        textArea.setBorder(BorderFactory.createEmptyBorder());
        add(textArea, BorderLayout.CENTER);
        if (players.get(PlayerSelectedId - 1).getOwnedProperties().isEmpty()) {
            textArea.setText(TempText);
        } else {
            for (Entity property : players.get(PlayerSelectedId - 1)
                    .getOwnedProperties()) {
                textArea.append(property.getName() + "\n");
            }
        }
        PropertiesListFrame.add(textArea);
    }

    // Show Help
    public static void ShowHelp() throws IOException, IOException {
        // Create and set up the window.  
        final JFrame frame = new JFrame("Property Tycoon Help");
        // Display the window.  
        frame.setSize(1368, 1000);
        frame.setVisible(true);
        JLabel help = new JLabel();
        try {
            Image img = ImageIO.read(MainClass.class.getResource("resources/help2.Png"));
            help.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        Dimension dim = new Dimension(1366, 1932);
        help.setSize(dim);
        JScrollPane scrollableImage = new JScrollPane(help);
        scrollableImage.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        frame.getContentPane().add(scrollableImage);
    }
}
