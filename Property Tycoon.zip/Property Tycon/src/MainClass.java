
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class MainClass {

    //Main Class  = Calling ShowSplash Method     
    public static void main(String[] args) throws IOException {
        ShowSplash();
    }

    //Shown Menu Of Game "Second Page"
    public static void ShowMenu() {
        double widthOfScreen = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double heightOfScreen = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        if (((int) widthOfScreen) == 1366 && ((int) heightOfScreen) == 768) {
            MenuFrame menuFrame = new MenuFrame();
            menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Color BackgroundColor = new Color(29, 16, 44);
            menuFrame.getContentPane().setBackground(BackgroundColor);

            Dimension d = new Dimension(1158, 551);
            Container c = menuFrame.getContentPane();
            c.setPreferredSize(d);

            menuFrame.setVisible(true);
            menuFrame.pack();
            menuFrame.setLocationRelativeTo(null);
            menuFrame.setResizable(false);
        } else {
            ShowResouloutionError();
        }
    }

    //Shown Splash Page "First Page"
    public static void ShowSplash() throws IOException, IOException {
        //create Jframe
        JFrame SplashFrame = new JFrame("Property Tycoon");
        SplashFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Color BackgroundColor = new Color(29, 16, 44);
        SplashFrame.getContentPane().setBackground(BackgroundColor);
        Container c = SplashFrame.getContentPane();
        Dimension d = new Dimension(1158, 551);
        c.setPreferredSize(d);
        SplashFrame.setVisible(true);
        SplashFrame.pack();
        SplashFrame.setLocationRelativeTo(null);
        SplashFrame.setResizable(false);

        //create Progress Bar
        JProgressBar progressBar;
        progressBar = new JProgressBar();
        progressBar.setValue(0);

        //Create  Buttons
        JButton btnStart = new JButton("Start New Game");
        btnStart.setBounds(512, 250, 150, 30);
        btnStart.setEnabled(false);
        btnStart.setVisible(false);

        JButton btnHowToPlay = new JButton("How To Play");
        btnHowToPlay.setBounds(512, 300, 150, 30);
        btnHowToPlay.setEnabled(false);
        btnHowToPlay.setVisible(false);

        JButton btnExit = new JButton("Exit Game");
        btnExit.setBounds(512, 400, 150, 30);
        btnExit.setEnabled(false);
        btnExit.setVisible(false);

        //Create Logo
        JLabel LogoLabel = new JLabel();
        try {
            Image img = ImageIO.read(MainClass.class.getResource("resources/logo.jpg"));
            LogoLabel.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
       
        //Create a Panel to add Buttons And  Logo and ...
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        LogoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(LogoLabel);
        Dimension dim = new Dimension(130, 35);
        btnStart.setMinimumSize(dim);
        btnStart.setMaximumSize(dim);
        btnStart.setPreferredSize(dim);
        btnStart.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnHowToPlay.setMinimumSize(dim);
        btnHowToPlay.setMaximumSize(dim);
        btnHowToPlay.setPreferredSize(dim);
        btnHowToPlay.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnExit.setMinimumSize(dim);
        btnExit.setMaximumSize(dim);
        btnExit.setPreferredSize(dim);
        btnExit.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel CopyRightLabel = new JLabel("Created for Watson Games");
        CopyRightLabel.setForeground(Color.white);
        CopyRightLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

       //Add Butoons and logo to panel
        
        panel.add(btnStart);
        panel.add(Box.createRigidArea(new Dimension(5, 5)));
        panel.add(btnHowToPlay);
        panel.add(Box.createRigidArea(new Dimension(5, 150)));
        panel.add(btnExit);
        panel.add(Box.createRigidArea(new Dimension(5, 5)));
        panel.add(CopyRightLabel);
        panel.setBackground(BackgroundColor);

        // add Panel to Splash Jframe
        SplashFrame.add(panel);
        
        //Add Progress Bar
        SplashFrame.getContentPane().add(progressBar, BorderLayout.SOUTH);
        for (int i = 0; i <= 100; i++) {
            wait(10);
            progressBar.setValue(i);
            progressBar.setStringPainted(true);
        }
        
        btnStart.setEnabled(true);
        btnHowToPlay.setEnabled(true);
        btnExit.setEnabled(true);
        btnStart.setVisible(true);
        btnHowToPlay.setVisible(true);
        btnExit.setVisible(true);
        
        //Buttons ActionListeners
        
        //Listener For Start New Game Button -- Hide The Splash Page And Run Menu 
        btnStart.addActionListener((ActionEvent e) -> {
            SplashFrame.setVisible(false);
            ShowMenu();
        });

        //Listener For How To Play Button -- Show Help Page
        btnHowToPlay.addActionListener((ActionEvent e) -> {
            try {
                ShowHelp();
            } catch (IOException ex) {
                Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

       // Listener For Exit Button -- Exit The Game
        btnExit.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });
    }

    // Shown ResouloutionError For Resoulution below 1366*768
    public static void ShowResouloutionError() {
        //create Jframe
        JFrame ErrorFrame = new JFrame("Property Tycoon");
        ErrorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ErrorFrame.setVisible(true);
        Container c = ErrorFrame.getContentPane();
        Dimension d = new Dimension(600, 100);
        c.setPreferredSize(d);
        ErrorFrame.pack();
        ErrorFrame.setLocationRelativeTo(null);
        ErrorFrame.setResizable(false);
        String TempText = "The game was designed to be played in 1366:768 resolution. for best experience Change the resolution.";
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setOpaque(false);
        textArea.setBorder(BorderFactory.createEmptyBorder());
        textArea.append(TempText);

        // Add Ok Button
        JButton OkBack = new JButton("Ok");
        OkBack.setBounds(300, 60, 50, 50);
        OkBack.setEnabled(true);
        ErrorFrame.add(OkBack);
        ErrorFrame.add(textArea);
        
        // After Show Hint About Resouloution Instantialize Menu Frame and hide Splash and Shown menu
        OkBack.addActionListener((ActionEvent e) -> {
            ErrorFrame.setVisible(false);
            MenuFrame menuFrame = new MenuFrame();
            menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Color BackgroundColor = new Color(29, 16, 44);
            menuFrame.getContentPane().setBackground(BackgroundColor);
            Dimension dim = new Dimension(1158, 551);
            Container con = menuFrame.getContentPane();
            con.setPreferredSize(dim);
            menuFrame.setVisible(true);
            menuFrame.pack();
            menuFrame.setLocationRelativeTo(null);
            menuFrame.setResizable(false);
        });
    }

    //This Method Shown Help Page
    public static void ShowHelp() throws IOException, IOException {
        // Create and set up the window.  
        final JFrame frame = new JFrame("Property Tycoon Help");  
        // Display the window.  
        frame.setSize(1368, 1000);  
        frame.setVisible(true);  
      
        //Create Image Lable
        JLabel help = new JLabel();
        try {
            Image img = ImageIO.read(MainClass.class.getResource(
                    "resources/help1.jpg"));
            help.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
        }
        Dimension dim = new Dimension(1366, 1932);
        help.setSize(dim);  
        
        //Create ScroolBar
        JScrollPane scrollableImage = new JScrollPane(help);  
        scrollableImage.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);  
        frame.getContentPane().add(scrollableImage);  
    }

    //This Method Calling For Make a Wait Time -- called by progress bar
    public static void wait(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
}
